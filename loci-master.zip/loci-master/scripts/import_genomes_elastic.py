from elasticsearch import Elasticsearch, helpers
import gzip

#google cloud
es = Elasticsearch(host="35.202.172.191",port=9200)

assembly_acc_str = "assembly_acc"
seq_type_str = "seq_type"
genomic_accession_str = "genomic_accession"	
start_str = "start"	
end_str = "end"	
strand_str = "strand"
product_accession_str = "product_accession"	
non_redundant_refseq_str = "non_redundant_refseq"	
name_str = "name"	
symbol_str = "symbol"	
locus_tag_str = "locus_tag"	
feature_interval_length_str = "feature_interval_length"	
product_length_str = "product_length"


def import_genomes_elastic(fileName):
	
    with open(fileName) as fp:
        
        for line in fp:
            line = line.strip()
            my_data = eval(line)
            #this will create the index and type if it is not already present
            res = es.index(index="genomes", doc_type='genomes',body=my_data)
            print(res['created'])

#Generator for actions from the cds input file. It is assumed to be in tsv format
#https://stackoverflow.com/questions/231767/what-does-the-yield-keyword-do?rq=1
def tsvFileInputGenerator(file_name,index_name,type_name):
    
    if file_name.endswith(".gz"):
        fp = gzip.open(file_name, 'rb')
    else:
        fp = open(file_name,"r")
    

        
    firstline = fp.readline()
    keys = firstline.strip().split("\t")
    #stripping each element in the list
    keys = map(str.strip,keys)
        

    #indices
    assembly_acc_ind = keys.index(assembly_acc_str)
    seq_type_ind = keys.index(seq_type_str)
    genomic_accession_ind = keys.index(genomic_accession_str)	
    start_ind = keys.index(start_str)
    end_ind = keys.index(end_str)
    strand_ind = keys.index(strand_str)
    product_accession_ind = keys.index(product_accession_str)	
    non_redundant_refseq_ind = keys.index(non_redundant_refseq_str)	
    name_ind = keys.index(name_str)
    symbol_ind = keys.index(symbol_str)
    locus_tag_ind = keys.index(locus_tag_str)	
    feature_interval_length_ind = keys.index(feature_interval_length_str)
    product_length_ind = keys.index(product_length_str)

    for line in fp:
        old_values = line.strip(" \n").split("\t")
        #stripping each element. strips only space and \n. \t is not stripped
        #https://stackoverflow.com/questions/10212445/python-map-list-item-to-function-with-arguments
        values = [p.strip() for p in old_values]

        my_dict = {}
        
        if values[assembly_acc_ind] != "":
            my_dict[assembly_acc_str] =  values[assembly_acc_ind]

        if values[seq_type_ind] != "":
            my_dict[seq_type_str] =  values[seq_type_ind]

        if  values[genomic_accession_ind] != "":
            my_dict[genomic_accession_str] =  values[genomic_accession_ind]

        if values[start_ind] != "":
            my_dict[start_str] =  values[start_ind]

        if values[end_ind] != "":
            my_dict[end_str] =  values[end_ind]

        if values[strand_ind] != "":
            my_dict[strand_str] =  values[strand_ind]

        if values[product_accession_ind] != "":
            my_dict[product_accession_str] =  values[product_accession_ind]

        if values[non_redundant_refseq_ind] != "":
            my_dict[non_redundant_refseq_str] =  values[non_redundant_refseq_ind]

        if values[name_ind] != "":
            my_dict[name_str] =  values[name_ind]

        if values[symbol_ind] != "":
            my_dict[symbol_str] =  values[symbol_ind]

        if values[locus_tag_ind] != "":
            my_dict[locus_tag_str] =  values[locus_tag_ind]

        if values[feature_interval_length_ind] != "":
            my_dict[feature_interval_length_str] =  values[feature_interval_length_ind]

        if values[product_length_ind] != "":
            my_dict[product_length_str] =  values[product_length_ind]

        #action dictionary
        #https://elasticsearch-py.readthedocs.io/en/master/helpers.html
        action = {}
        action["_index"] = index_name
        action["_type"] = type_name
        action["_source"] = my_dict

        yield action


#cs is the chunksize
def import_cds_elastic_bulk(file_name,index_name,type_name,error_file,cs):

    #error file handler
    efh = open(error_file,"w")
    actions = tsvFileInputGenerator(file_name,index_name,type_name)
    success, failed = 0, 0

    # list of errors to be collected is not stats_only
    #errors = []
    stats_only = False

    for ok, item in helpers.streaming_bulk(es, actions,chunk_size=cs):
        # go through request-reponse pairs and detect failures
        if not ok:
            if not stats_only:
                #errors.append(item)
                efh.write(str(item))
            failed += 1
        else:
            success += 1

    efh.close()
    print "Success: " + str(success)
    print "Failed: " + str(failed)

def create_search_strings(in_file,out_file):

    if out_file.endswith(".gz"):
        of = gzip.open(out_file, 'wb')
    else:
        of = open(out_file, 'w')
    of.write("name" + "\t" + "type" + "\t" + "tax_id"+"\n")


    if in_file.endswith(".gz"):
        fp = gzip.open(in_file, 'rb')
    else:
        fp = open(in_file,"r")

    firstline = fp.readline()
    keys = firstline.strip().split("\t")
    #stripping each element in the list
    keys = map(str.strip,keys)

    assembly_acc_ind = keys.index(assembly_acc_str)
    seq_type_ind = keys.index(seq_type_str)
    genomic_accession_ind = keys.index(genomic_accession_str)	
    product_accession_ind = keys.index(product_accession_str)	
    name_ind = keys.index(name_str)
    symbol_ind = keys.index(symbol_str)
    locus_tag_ind = keys.index(locus_tag_str)	
    
    for line in fp:
        old_values = line.strip(" \n").split("\t")
        #stripping each element. strips only space and \n. \t is not stripped
        #https://stackoverflow.com/questions/10212445/python-map-list-item-to-function-with-arguments
        values = [p.strip() for p in old_values]

        if values[name_ind] != "":
            of.write( values[name_ind] + "\t" + "name" + "\t" +  "-1" + "\n")
        
        if values[locus_tag_ind] != "":
            of.write(values[locus_tag_ind] + "\t" + "locus tag" + "\t" +  "-1" + "\n")

        if values[assembly_acc_ind] != "":
            of.write( values[assembly_acc_ind] + "\t" + "assembly accession" + "\t" +  "-1" + "\n")

        if values[seq_type_ind] != "":
            of.write( values[seq_type_ind] + "\t" + "sequence type" + "\t" +  "-1" + "\n")
        if values[genomic_accession_ind] != "":
            of.write( values[genomic_accession_ind] + "\t" + "genomic accession" + "\t" +  "-1" + "\n")
        if values[product_accession_ind] != "":
            of.write( values[product_accession_ind] + "\t" + "product accession" + "\t" +  "-1" + "\n")
        if values[symbol_ind] != "":
            of.write( values[symbol_ind] + "\t" + "symbol" + "\t" +  "-1" + "\n")
        

def search_string_generator(file_name,index_name,type_name):
    
    if file_name.endswith(".gz"):
        fp = gzip.open(file_name, 'rb')
    else:
        fp = open(file_name,"r")
    

        
    firstline = fp.readline()
    keys = firstline.strip().split("\t")
    #stripping each element in the list
    keys = map(str.strip,keys)
        
    for line in fp:
        old_values = line.strip(" \n").split("\t")
        #stripping each element. strips only space and \n. \t is not stripped
        #https://stackoverflow.com/questions/10212445/python-map-list-item-to-function-with-arguments
        values = [p.strip() for p in old_values]

        my_dict = {}
        
        if values[0] != "":
            my_dict["name"] =  values[0]

        if values[1] != "":
            my_dict["type"] =  values[1]

        if  values[2] != "":
            my_dict["tax_id"] =  values[2]

        #action dictionary
        #https://elasticsearch-py.readthedocs.io/en/master/helpers.html
        action = {}
        action["_index"] = index_name
        action["_type"] = type_name
        action["_source"] = my_dict

        yield action


#https://discuss.elastic.co/t/helpers-parallel-bulk-in-python-not-working/39498/3
#cs is the chunksize
def import_search_string_elastic_bulk(file_name,index_name,type_name,error_file,cs,num_threads):

    #error file handler
    efh = open(error_file,"w")
    actions = search_string_generator(file_name,index_name,type_name)
    success, failed = 0, 0

    # list of errors to be collected is not stats_only
    #errors = []
    stats_only = False

    #for ok, item in helpers.streaming_bulk(es, actions,chunk_size=cs):
    for ok, item in helpers.parallel_bulk(es, actions,chunk_size=cs,thread_count=num_threads):
    
        # go through request-reponse pairs and detect failures
        if not ok:
            if not stats_only:
                #errors.append(item)
                efh.write(str(item))
            failed += 1
        else:
            success += 1

    efh.close()
    print "Success: " + str(success)
    print "Failed: " + str(failed)


#import_genomes_elastic("~/projects/data/ncbi/top150/top150.jsonl")

#import_cds_elastic_bulk("~/projects/data/ncbi/test.tsv","cds","cds","~/projects/data/ncbi/test.err",10000)
#import_cds_elastic_bulk("~/projects/data/ncbi/test.tsv.gz","cds","cds","~/projects/data/ncbi/test.err",1000)
#import_cds_elastic_bulk("test.tsv.gz","cds","cds","test.err",10000)
#import_cds_elastic_bulk("~/projects/data/ncbi/test.10k.tsv.gz","test","test","test.err",1000)

#create_search_strings("~/projects/data/ncbi/test.10k.tsv","~/projects/data/ncbi/test.10k.ss.tsv")
#import_search_string_elastic_bulk("~/projects/data/ncbi/test.ss.new.tsv.gz","ss","ss","ss.err",10000)

#create_search_strings("~/projects/data/ncbi/all_refseq_baterial_cds.tsv","~/projects/data/ncbi/all_refseq_baterial_cds.ss.tsv")

import_search_string_elastic_bulk("~/projects/data/ncbi/all_refseq_baterial_cds.ss.new.tsv.gz","ss","ss","ss.err",10000,5)
