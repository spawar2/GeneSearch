'''
This file is the driver for all ETL scripts to upload data into loci
This needs to be automated in a later version of loci
'''
import filter_assemblies as myfilter
import import_genomes as genomes
import import_genes as genes
import prepare_jbrowse_data as jbrowse
import prepare_dashboard as dashboard
import prepare_blast_databases as blast
import script_utils as sutils
import time

'''
#data path where the data is stored to be ingested into Loci
mdp = "/home/mydirectory/projects/data/ncbi/"

#where data needs to be stored in loci
#Make sure the directory exists
ldp = "/home/mydirectory/projects/loci/flaskserver/static/loci_data/genome_data/"

#bin directory of jbrowse
jb_bindir= "/home/mydirectory/projects/loci/flaskserver/static/jbrowse/JBrowse-1.12.1/bin/"

#data directory where jbrowse data will be stored
jb_datadir = "/home/mydirectory/projects/loci/flaskserver/static/jbrowse/JBrowse-1.12.1/loci_jbrowse_data/"

MY_APP_ROOT = "/home/mydirectory/projects/loci/flaskserver"
MY_DATA_ROOT = MY_APP_ROOT + "/static/loci_data"
BLAST_DB_ROOT = MY_DATA_ROOT + "/blastdbs"

ncbi_fasta_url = "https://ftp.ncbi.nlm.nih.gov/blast/db/FASTA/" 
ncbi_nr_url = ncbi_fasta_url + "nr.gz"
ncbi_nt_url = ncbi_fasta_url + "nt.gz"
ncbi_env_nr_url = ncbi_fasta_url + "env_nr.gz"
ncbi_env_nt_url = ncbi_fasta_url + "env_nt.gz"
ncbi_pataa_url =  ncbi_fasta_url + "pataa.gz"
ncbi_patnt_url =  ncbi_fasta_url + "patnt.gz"

#16s rrna downloaded as blast database. need to be converted to fasta and then to loci db
ncbi_db_url = "https://ftp.ncbi.nlm.nih.gov/blast/db/"
ncbi_16smicrobial_url = ncbi_db_url + "16SMicrobial.tar.gz"
'''

### STARTING CODE FOR UPLOADING 10 GENOMES

'''
#renames gff and genome fasta. unzips gff
myfilter.prepare_refseq_assemblies(mdp+"bacteria_top10.txt",mdp+"refseq_subset_download/")


#after running this command, add the "collection" and "privacy" columns manually to the output file
myfilter.make_input_file(mdp+"bacteria_top10.txt",
                ldp + "data",
                ldp+"bacteria_top10_input.txt"
               )


#copies the files into loci directory
myfilter.copy_files_to_loci(ldp+"bacteria_top10_input.txt",mdp+"refseq_subset_download",ldp+"data")



#changes the gff file with new IDs. Currently fasta file is not changed
genomes.preprocess_refseq_files(ldp+"bacteria_top10_input.txt")




#removes the .original files. and creates files named assembly.gff and assembly.fna.gz
genomes.cleanup_refseq_files(ldp+"bacteria_top10_input.txt")


genomes.get_assembly_metadata(ldp+"bacteria_top10_input.txt",
ldp+"bacteria_top10.jsonl",
mdp+ "assembly_summary_refseq.txt",
mdp+"taxonomy/nodes.dmp",
mdp+"/taxonomy/names.dmp"
)


#importing genomes into mongodb
#TODO: need to write a function for this because it is reused for genes, proteins, etc.
#TODO: need to think about upserting because when a new batch of genomes come we want to make sure they are not repeating
#mongod --dbpath loci/ --port 1401 --nojournal
#mongoimport -d omics  -c genomes  --port 1401 --type json  --file bacteria_top10.jsonl --numInsertionWorkers 4


#importing genome_search_strings into mongodb.
#TODO: this function may not be scalable. See how we insert gene and protein search strings. May need to change this in future
genomes.create_search_strings(ldp+"bacteria_top10.jsonl")



#preparing genes and proteins for upload
genomes.process_all_genome_files(ldp+"bacteria_top10.jsonl")



#creating single jsonl for genes an proteins
#find data/  -name "*.genes.jsonl.gz" -exec zcat {} \;  | gzip >  bacteria_top10_genes.jsonl.gz
#find data/  -name "*.proteins.jsonl.gz" -exec zcat {} \; | gzip  > bacteria_top10_proteins.jsonl.gz



#create search strings for genes and proteins
genes.create_gene_search_strings(ldp+"bacteria_top10_genes.jsonl.gz", ldp+"bacteria_top10_genes.ss.jsonl.gz")
genes.create_protein_search_strings(ldp+"bacteria_top10_proteins.jsonl.gz", ldp+"bacteria_top10_proteins.ss.jsonl.gz")



#TODO: need to put this in a python function
#finding unique search strings before uploading to mongo
#zcat bacteria_top10_genes.ss.jsonl.gz | sort | uniq | gzip >  bacteria_top10_genes.ss.uniq.jsonl.gz
#zcat bacteria_top10_proteins.ss.jsonl.gz | sort | uniq | gzip  >  bacteria_top10_proteins.ss.uniq.jsonl.gz

#inserting genes, proteins, and their search strings
#TODO: need to write a function for this because it is reused for genes, proteins, etc.
#TODO: need to think about upserting because when a new batch of genomes come we want to make sure they are not repeating
#mongod --dbpath loci/ --port 1401 --nojournal
#zcat bacteria_top10_genes.jsonl.gz |  mongoimport -d omics  -c genes  --port 1401 --type json  --numInsertionWorkers 4
#zcat bacteria_top10_proteins.jsonl.gz | mongoimport -d omics  -c proteins  --port 1401 --type json   --numInsertionWorkers 4
#zcat bacteria_top10_genes.ss.uniq.jsonl.gz | mongoimport -d omics  -c gene_search_strings  --port 1401 --type json    --numInsertionWorkers 4
#zcat bacteria_top10_proteins.ss.uniq.jsonl.gz | mongoimport -d omics  -c protein_search_strings  --port 1401 --type json    --numInsertionWorkers 4

#Indexing the collections
#TODO: need to put this in a function to automate


#preparing the dashboard
dashboard.prepare_dashboard()

#TODO: need to change this function because the file inside the gz file is still .new.fna.gz
genomes.cleanup_2(ldp+"bacteria_top10.jsonl")


#Prepare jbrowse data
jbrowse.prepare_jbrowse_data(jb_bindir,jb_datadir,ldp+"bacteria_top10.jsonl")

#prepare blast databases
blast.make_blast_databases(ldp+"bacteria_top10.jsonl",BLAST_DB_ROOT)
blast.make_preformatted_databases(BLAST_DB_ROOT)

'''
#download public databases like nr, nt. creates directories if not present
#sutils.download_file(ncbi_nr_url,BLAST_DB_ROOT + "/ncbi_nr/","nr.gz")
#sutils.download_file(ncbi_nt_url,BLAST_DB_ROOT + "/ncbi_nt/","nt.gz")
#sutils.download_file(ncbi_env_nr_url,BLAST_DB_ROOT + "/ncbi_env_nr/","env_nr.gz")
#sutils.download_file(ncbi_env_nt_url,BLAST_DB_ROOT + "/ncbi_env_nt/","env_nt.gz")
#sutils.download_file(ncbi_pataa_url,BLAST_DB_ROOT + "/ncbi_pataa/","pataa.gz")
#sutils.download_file(ncbi_patnt_url,BLAST_DB_ROOT + "/ncbi_patnt/","patnt.gz")
#sutils.download_file(ncbi_16smicrobial_url,BLAST_DB_ROOT + "/ncbi_16smicrobial/","16SMicrobial.tar.gz")




#prepare public blast databases like NCBi nr, nt, etc.
#blast.prepare_public_database("ncbi_nr",BLAST_DB_ROOT + "/ncbi_nr/","nr.gz",BLAST_DB_ROOT + "/ncbi_nr/",'prot')
#blast.prepare_public_database("ncbi_nt",BLAST_DB_ROOT + "/ncbi_nt/","nt.gz",BLAST_DB_ROOT + "/ncbi_nt/",'nucl')
#blast.prepare_public_database("ncbi_env_nr",BLAST_DB_ROOT + "/ncbi_env_nr/","env_nr.gz",BLAST_DB_ROOT + "/ncbi_env_nr/",'prot')
#blast.prepare_public_database("ncbi_env_nt",BLAST_DB_ROOT + "/ncbi_env_nt/","env_nt.gz",BLAST_DB_ROOT + "/ncbi_env_nt/",'nucl')
#blast.prepare_public_database("ncbi_pataa",BLAST_DB_ROOT + "/ncbi_pataa/","pataa.gz",BLAST_DB_ROOT + "/ncbi_pataa/",'prot')
#blast.prepare_public_database("ncbi_patnt",BLAST_DB_ROOT + "/ncbi_patnt/","patnt.gz",BLAST_DB_ROOT + "/ncbi_patnt/",'nucl')

####
#### STARTING CODE FOR UPLOADING 150 GENOMES
####

#copied 150 original genome directories (where i downloaded 100 genomes form ncbi) to mdp directory (see above)
#head -151 assembly_summary_refseq_bacteria_subset.txt > top150.txt

#myfilter.prepare_refseq_assemblies(mdp+"top150.txt",mdp+"refseq_subset_download/")

#input file was just got from previous work
#head -151 assembly_summary_refseq_bacteria_subset_gapp_input.txt > top150_input.txt
#find and replaced the file path column

#myfilter.copy_files_to_loci(ldp+"top150_input.txt",mdp+"refseq_subset_download",ldp+"data")

#genomes.preprocess_refseq_files(ldp+"top150_input.txt")

#genomes.cleanup_refseq_files(ldp+"top150_input.txt")

'''
genomes.get_assembly_metadata(ldp+"top150_input.txt",
ldp+"top150.jsonl",
mdp+ "assembly_summary_refseq.txt",
mdp+"taxonomy/nodes.dmp",
mdp+"/taxonomy/names.dmp"
)
'''

#mongod --config ../loci/database/loci_mongo.config
#mongoimport -d omics  -c genomes  --port 1401 --type json  --file top150.jsonl --numInsertionWorkers 4
#genomes.create_search_strings(ldp+"top150.jsonl")

#genomes.process_all_genome_files(ldp+"top150.jsonl")

#find data/  -name "*.genes.jsonl.gz" -exec zcat {} \;  | gzip > top150_genes.jsonl.gz
#find data/  -name "*.proteins.jsonl.gz" -exec zcat {} \; | gzip  > top150_proteins.jsonl.gz

#genes.create_gene_search_strings(ldp+"top150_genes.jsonl.gz", ldp+"top150_genes.ss.jsonl.gz")
#genes.create_protein_search_strings(ldp+"top150_proteins.jsonl.gz", ldp+"top150_proteins.ss.jsonl.gz")

#zcat top150_genes.ss.jsonl.gz | sort | uniq | gzip >  top150_genes.ss.uniq.jsonl.gz
#zcat top150_proteins.ss.jsonl.gz | sort | uniq | gzip  >  top150_proteins.ss.uniq.jsonl.gz

#zcat top150_genes.jsonl.gz |  mongoimport -d omics  -c genes  --port 1401 --type json  --numInsertionWorkers 4
#zcat top150_proteins.jsonl.gz | mongoimport -d omics  -c proteins  --port 1401 --type json   --numInsertionWorkers 4
#zcat top150_genes.ss.uniq.jsonl.gz | mongoimport -d omics  -c gene_search_strings  --port 1401 --type json    --numInsertionWorkers 4
#zcat top150_proteins.ss.uniq.jsonl.gz | mongoimport -d omics  -c protein_search_strings  --port 1401 --type json    --numInsertionWorkers 4


#indexing need to be done
#db.genes.createIndex({assembly_acc:1})
#db.genes.createIndex({description:1})
#db.genes.createIndex({unique_id:1})
#db.genes.createIndex({biotype:1})
#db.genes.createIndex({collection:1})
#db.genes.createIndex({"lineage.name":1,"lineage.rank":1,"lineage.tax_id":1})


#db.proteins.createIndex({assembly_acc:1})
#db.proteins.createIndex({description:1})
#db.proteins.createIndex({unique_id:1})
#db.proteins.createIndex({collection:1})
#db.proteins.createIndex({"lineage.name":1,"lineage.rank":1,"lineage.tax_id":1})



#dashboard.prepare_dashboard()

#genomes.cleanup_2(ldp+"top150.jsonl")


#jbrowse.prepare_jbrowse_data(jb_bindir,jb_datadir,ldp+"top150.jsonl")

#blast.make_blast_databases(ldp+"top150.jsonl",BLAST_DB_ROOT)
#blast.make_preformatted_databases(ldp + "data",BLAST_DB_ROOT,4,1)


#sutils.download_file(ncbi_nr_url,BLAST_DB_ROOT + "/ncbi_nr/","nr.gz")
#sutils.download_file(ncbi_nt_url,BLAST_DB_ROOT + "/ncbi_nt/","nt.gz")
#sutils.download_file(ncbi_env_nr_url,BLAST_DB_ROOT + "/ncbi_env_nr/","env_nr.gz")
#sutils.download_file(ncbi_env_nt_url,BLAST_DB_ROOT + "/ncbi_env_nt/","env_nt.gz")
#sutils.download_file(ncbi_pataa_url,BLAST_DB_ROOT + "/ncbi_pataa/","pataa.gz")
#sutils.download_file(ncbi_patnt_url,BLAST_DB_ROOT + "/ncbi_patnt/","patnt.gz")
#sutils.download_file(ncbi_16smicrobial_url,BLAST_DB_ROOT + "/ncbi_16smicrobial/","16SMicrobial.tar.gz")



#prepare public blast databases like NCBi nr, nt, etc.
#blast.prepare_public_database("ncbi_nr",BLAST_DB_ROOT + "/ncbi_nr/","nr.gz",BLAST_DB_ROOT + "/ncbi_nr/",'prot')
#blast.prepare_public_database("ncbi_nt",BLAST_DB_ROOT + "/ncbi_nt/","nt.gz",BLAST_DB_ROOT + "/ncbi_nt/",'nucl')
#blast.prepare_public_database("ncbi_env_nr",BLAST_DB_ROOT + "/ncbi_env_nr/","env_nr.gz",BLAST_DB_ROOT + "/ncbi_env_nr/",'prot')
#blast.prepare_public_database("ncbi_env_nt",BLAST_DB_ROOT + "/ncbi_env_nt/","env_nt.gz",BLAST_DB_ROOT + "/ncbi_env_nt/",'nucl')
#blast.prepare_public_database("ncbi_pataa",BLAST_DB_ROOT + "/ncbi_pataa/","pataa.gz",BLAST_DB_ROOT + "/ncbi_pataa/",'prot')
#blast.prepare_public_database("ncbi_patnt",BLAST_DB_ROOT + "/ncbi_patnt/","patnt.gz",BLAST_DB_ROOT + "/ncbi_patnt/",'nucl')
#blast.prepare_16s("ncbi_16smicrobial",BLAST_DB_ROOT + "/ncbi_16smicrobial/","16SMicrobial",BLAST_DB_ROOT + "/ncbi_16smicrobial/",'nucl')


'''
####
#### STARTING CODE FOR ANOTHER TEST
####

#data path where the data is stored to be ingested into Loci
mdp = "/home/mydirectory/projects/data/ncbitest/"

#where data needs to be stored in loci
#Make sure the directory exists
ldp = "/home/mydirectory/projects/data/ncbitest/ldir/"

#bin directory of jbrowse
jb_bindir= "/home/mydirectory/projects/loci/flaskserver/static/jbrowse/JBrowse-1.12.1/bin/"

#data directory where jbrowse data will be stored
jb_datadir = "/home/mydirectory/projects/data/ncbitest/jdir/"

MY_APP_ROOT = "/home/mydirectory/projects/data/ncbitest"
MY_DATA_ROOT = MY_APP_ROOT
BLAST_DB_ROOT = MY_DATA_ROOT + "/bdir"

ncbi_fasta_url = "https://ftp.ncbi.nlm.nih.gov/blast/db/FASTA/" 
ncbi_nr_url = ncbi_fasta_url + "nr.gz"
ncbi_nt_url = ncbi_fasta_url + "nt.gz"
ncbi_env_nr_url = ncbi_fasta_url + "env_nr.gz"
ncbi_env_nt_url = ncbi_fasta_url + "env_nt.gz"
ncbi_pataa_url =  ncbi_fasta_url + "pataa.gz"
ncbi_patnt_url =  ncbi_fasta_url + "patnt.gz"

#16s rrna downloaded as blast database. need to be converted to fasta and then to loci db
ncbi_db_url = "https://ftp.ncbi.nlm.nih.gov/blast/db/"
ncbi_16smicrobial_url = ncbi_db_url + "16SMicrobial.tar.gz"

#download assembly_summary_refseq.txt from ftp://ftp.ncbi.nlm.nih.gov/genomes/refseq/ to ncbitest directory
#i should download the taxonomy database as well but i didnt do it here
'''

'''

myfilter.get_refseq_rank(mdp+ "assembly_summary_refseq.txt",
                 mdp+"assembly_summary_refseq_bacteria.txt",
                "superkingdom",
                "2",
                "/home/mydirectory/projects/data/ncbi/taxonomy/nodes.dmp",
                "/home/mydirectory/projects/data/ncbi/taxonomy/names.dmp")


#got first 10 genomes
#head -11  assembly_summary_refseq_bacteria.txt > assembly_summary_refseq_bacteria_subset.txt


myfilter.download_refseq_assemblies(mdp + "assembly_summary_refseq_bacteria_subset.txt",
                           mdp + "refseq_subset_download"
                          )


myfilter.sanity_check_refseq_downloads(mdp + "assembly_summary_refseq_bacteria_subset.txt",
                          mdp + "refseq_subset_download/"
                         )

#myfilter.prepare_refseq_assemblies(mdp + "assembly_summary_refseq_bacteria_subset.txt",mdp+"refseq_subset_download/")

myfilter.make_input_file(mdp + "assembly_summary_refseq_bacteria_subset.txt",
                ldp+"data",
                mdp + "assembly_summary_refseq_bacteria_subset_gapp_input.txt",
                "NCBI_GENOMES",
                "Public"
               )



#copy input file to ldp
myfilter.copy_files_to_loci(ldp+"assembly_summary_refseq_bacteria_subset_gapp_input.txt",mdp+"refseq_subset_download",ldp+"data")


genomes.preprocess_refseq_files(ldp+"assembly_summary_refseq_bacteria_subset_gapp_input.txt",2)

genomes.cleanup_refseq_files(ldp+"assembly_summary_refseq_bacteria_subset_gapp_input.txt")

genomes.get_assembly_metadata(ldp,
ldp+"assembly_summary_refseq_bacteria_subset_gapp_input.txt",
ldp+"genomes.jsonl"
mdp+ "assembly_summary_refseq.txt",
mdp+"taxonomy/nodes.dmp",
mdp+"/taxonomy/names.dmp",
3
)
'''


#genomes.process_all_genome_files(ldp+"genomes.jsonl",1)

#genomes.merge_files_from_genomes(ldp)
#genomes.create_search_strings(ldp+"genomes.jsonl", ldp+"genomes.ss.jsonl.gz")
#grep -v "\"type\": \"intraspecies_name\"" genomes.ss.uniq.jsonl > common.ss.jsonl
#genomes.create_gene_protein_search_strings(ldp,"50%",3)
#genes.create_gene_search_strings(ldp+"genes.jsonl.gz", ldp+"genes.ss.jsonl.gz")
#genes.create_protein_search_strings(ldp+"proteins.jsonl.gz", ldp+"proteins.ss.jsonl",ldp+"common.ss.jsonl",ldp,2,"50%")

#genomes.cleanup_2(ldp+"genomes.jsonl")

#genomes.create_all_indexes("127.0.0.1",1401,3,1)

#jbrowse.prepare_jbrowse_data(jb_bindir,jb_datadir,ldp+"genomes.jsonl",4)
#blast.make_blast_databases(ldp+"genomes.jsonl",BLAST_DB_ROOT,4)
#blast.sanity_check_blast_dbs(ldp+"genomes.jsonl",BLAST_DB_ROOT,ldp+"blast_sanity.txt")


####
#### STARTING CODE FOR PRIVATE GENOMES
####

#data path where the data is stored to be ingested into Loci
#mdp = "/home/mydirectory/projects/data/privategenomes/"

#where data needs to be stored in loci
#Make sure the directory exists
#ldp = "/home/mydirectory/projects/data/privategenomes/ldir/"

#wget ftp://ftp.ncbi.nih.gov/pub/taxonomy/taxdump.tar.gz
#tar -xvf taxdump.tar.gz
#getting bt genomes
'''
myfilter.get_refseq_rank(mdp+ "assembly_summary_refseq.txt",
                 mdp+"assembly_summary_bt.txt",
                "species",
                "1428",
                mdp+ "taxonomy/nodes.dmp",
                mdp + "taxonomy/names.dmp")

#getting sinosa genomes
myfilter.get_refseq_rank(mdp+ "assembly_summary_refseq.txt",
                 mdp+"assembly_summary_spinosa.txt",
                "species",
                "60894",
                mdp+ "taxonomy/nodes.dmp",
                mdp + "taxonomy/names.dmp")


myfilter.download_refseq_assemblies(mdp + "assembly_summary_btspn.txt",
                           mdp + "original_download",
                           3,
                           10
                          )

myfilter.sanity_check_refseq_downloads(mdp + "assembly_summary_btspn.txt",
                          mdp + "original_download/"
                         )


myfilter.make_private_assemblies(mdp + "assembly_summary_btspn.txt",
mdp+"assembly_summary_btspn_priv.txt",mdp+"original_download",
mdp+"priv_genomes",
3,
None)


myfilter.make_input_file(mdp + "assembly_summary_btspn_priv.txt",
                ldp + "data",
                mdp + "assembly_summary_btspn_input.txt",
                "PRIVATE_Bt",
                "Private"
               )
#manually changed last two genomes to collection PRIVATE_Spinosa


myfilter.copy_files_to_loci(ldp+"assembly_summary_btspn_input.txt",mdp+"priv_genomes",ldp+"data")

genomes.preprocess_refseq_files(ldp+"assembly_summary_btspn_input.txt",3)
genomes.cleanup_refseq_files(ldp+"assembly_summary_btspn_input.txt")

genomes.get_assembly_metadata(ldp,
ldp+"assembly_summary_btspn_input.txt",
ldp+"genomes.jsonl",
mdp+ "assembly_summary_refseq.txt",
mdp+"taxonomy/nodes.dmp",
mdp+"/taxonomy/names.dmp",
3)

genomes.process_all_genome_files(ldp+"genomes.jsonl",3)
genomes.create_search_strings(ldp+"genomes.jsonl", ldp+"genomes.ss.jsonl.gz")
#zcat genomes.ss.jsonl.gz | sort -u > genomes.ss.uniq.jsonl
genomes.merge_files_from_genomes(ldp)
#did not run the function to get gene and protein search strings
genomes.cleanup_2(ldp+"genomes.jsonl")
#getting only the required info
#grep  "\"type\": \"assembly_acc\"" genomes.ss.uniq.jsonl > genomes.ss.uniq.new.jsonl
#grep  "\"type\": \"collection\"" genomes.ss.uniq.jsonl >> genomes.ss.uniq.new.jsonl
#in the input file and the genomes.jsonl file, change the dir to cloud dir /mnt/disks/loc.....
#copied ldir to cloud using filezilla
'''


'''
####
#### STARTING CODE FOR ALL DATA
####

#data path where the data is stored to be ingested into Loci
mdp = "/mnt/disks/locidisk/projects/data/ncbiall/"

#where data needs to be stored in loci
#Make sure the directory exists
ldp = "/mnt/disks/locidisk/projects/loci/flaskserver/static/loci_data/genome_data/"

#bin directory of jbrowse
jb_bindir= "/mnt/disks/locidisk/projects/loci/flaskserver/static/jbrowse/JBrowse-1.12.1/bin/"

#data directory where jbrowse data will be stored
jb_datadir = "/mnt/disks/locidisk/projects/loci/flaskserver/static/jbrowse/JBrowse-1.12.1/loci_jbrowse_data/"

MY_APP_ROOT = "/mnt/disks/locidisk/projects/loci/flaskserver"
MY_DATA_ROOT = MY_APP_ROOT + "/static/loci_data"
BLAST_DB_ROOT = MY_DATA_ROOT + "/blastdbs"

ncbi_fasta_url = "https://ftp.ncbi.nlm.nih.gov/blast/db/FASTA/" 
ncbi_nr_url = ncbi_fasta_url + "nr.gz"
ncbi_nt_url = ncbi_fasta_url + "nt.gz"
ncbi_env_nr_url = ncbi_fasta_url + "env_nr.gz"
ncbi_env_nt_url = ncbi_fasta_url + "env_nt.gz"
ncbi_pataa_url =  ncbi_fasta_url + "pataa.gz"
ncbi_patnt_url =  ncbi_fasta_url + "patnt.gz"

#16s rrna downloaded as blast database. need to be converted to fasta and then to loci db
ncbi_db_url = "https://ftp.ncbi.nlm.nih.gov/blast/db/"
ncbi_16smicrobial_url = ncbi_db_url + "16SMicrobial.tar.gz"

start = time.time()
'''

#download assembly_summary_refseq.txt from ftp://ftp.ncbi.nlm.nih.gov/genomes/refseq/ to mdb directory
#wget ftp://ftp.ncbi.nlm.nih.gov/genomes/refseq/assembly_summary_refseq.txt

#download and untar taxonomy data in mdp/taxonomy directory
#wget ftp://ftp.ncbi.nih.gov/pub/taxonomy/taxdump.tar.gz
#tar -xvf taxdump.tar.gz


'''
myfilter.get_refseq_rank(mdp+ "assembly_summary_refseq.txt",
                 mdp+"assembly_summary_refseq_bacteria.txt",
                "superkingdom",
                "2",
                mdp + "taxonomy/nodes.dmp",
                mdp + "taxonomy/names.dmp")



#make the refseq_download directory before running this function
#48 hrs, 200GB
myfilter.download_refseq_assemblies(mdp + "assembly_summary_refseq_bacteria.txt",
                           mdp + "refseq_download"
                          )

#there were 133030 geomes. 131620 were downloaded in the first try
myfilter.sanity_check_refseq_downloads(mdp + "assembly_summary_refseq_bacteria.txt",
                          mdp + "refseq_download/"
                         )

#stored the output of the previous command in not_downloaded.txt
myfilter.download_refseq_assemblies(mdp + "not_downloaded.txt",
                           mdp + "refseq_download"
                          )

#confirmed all genomes are downloaded
myfilter.sanity_check_refseq_downloads(mdp + "assembly_summary_refseq_bacteria.txt",
                          mdp + "refseq_download/"
                         )

myfilter.prepare_refseq_assemblies(mdp + "assembly_summary_refseq_bacteria.txt",mdp+"refseq_download/")


myfilter.make_input_file(mdp + "assembly_summary_refseq_bacteria.txt",
                ldp + "data",
                mdp + "assembly_summary_refseq_bacteria_input.txt",
                "NCBI_GENOMES",
                "Public"
               )

#copy input file to ldp
#make a dir called data in ldp

myfilter.copy_files_to_loci(ldp+"assembly_summary_refseq_bacteria_input.txt",mdp+"refseq_download",ldp+"data")

#2 hrs
genomes.preprocess_refseq_files(ldp+"assembly_summary_refseq_bacteria_input.txt",2)

genomes.cleanup_refseq_files(ldp+"assembly_summary_refseq_bacteria_input.txt")

#6 hours in one core, 46 minutes in 16 cores (c5.4xlarge). 8 cores good enough?
genomes.get_assembly_metadata(ldp,
ldp+"assembly_summary_refseq_bacteria_input.txt",
ldp+"genomes.jsonl",
mdp+ "assembly_summary_refseq.txt",
mdp+"taxonomy/nodes.dmp",
mdp+"/taxonomy/names.dmp",
16)

#getting random genomes for test purposes
myfilter.filter_assemblies(ldp+"assembly_summary_refseq_bacteria_input.txt",100,133030,ldp+"test_100.txt")
myfilter.filter_assemblies(ldp+"assembly_summary_refseq_bacteria_input.txt",500,133030,ldp+"test_500.txt")


myfilter.copy_files_to_loci(ldp+"test_100.txt",mdp+"refseq_download",ldp+"data")
genomes.preprocess_refseq_files(ldp+"test_100.txt",2)
genomes.cleanup_refseq_files(ldp+"test_100.txt")
print "copied"
genomes.get_assembly_metadata(ldp,
ldp+"test_100.txt",
ldp+"test_100.jsonl",
mdp+ "assembly_summary_refseq.txt",
mdp+"taxonomy/nodes.dmp",
mdp+"/taxonomy/names.dmp",
8
)

genomes.get_assembly_metadata(ldp+"test_500.txt",
ldp+"test_500.jsonl",
mdp+ "assembly_summary_refseq.txt",
mdp+"taxonomy/nodes.dmp",
mdp+"/taxonomy/names.dmp"
)


#this size of ldp+data is ~450GB before processingg all_genome_files because gff filex are unzipped. The original download is only 200GB
#the process_all_genome_files took 48 hours in m5a.2xlarge(8 cores), 24 hours in 16 cores (c5.4xlarge)
#ldp+data is 850G after finishing
#genomes.process_all_genome_files(ldp+"genomes.jsonl",16)

#TODO: need to write a function for sanity check of all genomes are processed properly
#In this round GCF_000011985 had no genes or proteins and it caused issues when creating blastdb


#TODO: need to change this because unique ids are not part of search string anymore
#genomes.create_search_strings(ldp+"genomes.jsonl", ldp+"genomes.ss.jsonl.gz")
#zcat genomes.ss.jsonl.gz | sort -u > genomes.ss.uniq.jsonl
#grep -v "\"type\": \"intraspecies_name\"" genomes.ss.uniq.jsonl > common.ss.jsonl

#TODO: need to change this because unique ids are not part of search string anymore
#genomes.merge_files_from_genomes(ldp)
#genes.jsonl.gz=20G, proteins.jsonl.gz=21G, genes.id.tmp=35G,genes.desc.tmp=23G,genes.biotype.tmp=1G,proteins.id.tmp=36G,proteins.desc.tmp=23G
#took 35 mins

#TODO: need to change this because unique ids are not part of search string anymore
#genomes.create_gene_protein_search_strings(ldp,"75%",16)
#took 25 minutes in 16 cores. c5.4xlarge

genomes.cleanup_2(ldp+"genomes.jsonl")

#copied all directorys in the private genomes data directory into the data dir
#sudo cat ldir/genes.jsonl.gz >> genes.jsonl.gz
#sudo cat ldir/proteins.jsonl.gz >> proteins.jsonl.gz
#sudo cat ldir/genomes.jsonl >> genomes.jsonl
#cat ldir/genes.id.tmp >> genes.ss.uniq.jsonl
#cat ldir/proteins.id.tmp >> proteins.ss.uniq.jsonl
#cat ldir/genomes.ss.uniq.new.jsonl  >> genomes.ss.uniq.jsonl
#tail -n +2 ldir/assembly_summary_btspn_input.txt >> assembly_summary_refseq_bacteria_input.txt 

#mongoimport -d omics  -c genomes  --port 1401 --type json    --numInsertionWorkers 16 --file genomes.jsonl
#mongoimport -d omics  -c genome_search_strings  --port 1401 --type json    --numInsertionWorkers 16 --file genomes.ss.uniq.jsonl
#took 96 minutes with 16 processors (c5.4xlarge) for genes and proteins each. will take double with 8 proccessors. 
#516879034 docs in genes. 507273678 in proteins
#zcat genes.jsonl.gz |  mongoimport -d omics  -c genes  --port 1401 --type json  --numInsertionWorkers 16
#zcat proteins.jsonl.gz |  mongoimport -d omics  -c proteins  --port 1401 --type json  --numInsertionWorkers 16
#took 35 mins each in 16 cores for prot and gene search strings
#mongoimport -d omics  -c gene_search_strings  --port 1401 --type json    --numInsertionWorkers 16 --file genes.ss.uniq.jsonl
#mongoimport -d omics  -c protein_search_strings  --port 1401 --type json    --numInsertionWorkers 16 --file proteins.ss.uniq.jsonl
'''
#even though i tried to parallelize it. it doesnt run any faster cos mongod runs in a single core.
#took 27 hours with 2 cores m5a.large
#genomes.create_all_indexes("127.0.0.1",1401,2,1)

#this took 5-6 hours on 2 cores m5a.large
#dashboard.prepare_dashboard()

#1.5 hours with 16 cores. dont use sudo. sizee of blast dbs after this step is 657gb
#blast.make_blast_databases(ldp+"genomes.jsonl",BLAST_DB_ROOT,16)
#blast.sanity_check_blast_dbs(ldp+"genomes.jsonl",BLAST_DB_ROOT,ldp+"blast_sanity.jsonl")
#found that GCF_000011985 has issues. It had 0 genes and proteins. THis should have been caught before
#worked around it by removing it from genomes.jsonl, mongodb, and assembly_summary_refseq_bacteria_input, ldir+data, blastdbs
#blast.make_preformatted_databases(ldp + "data",BLAST_DB_ROOT,8,1)

#took 30 mins for all downloads
#sutils.download_file(ncbi_nr_url,BLAST_DB_ROOT + "/ncbi_nr/","nr.gz")
#sutils.download_file(ncbi_nt_url,BLAST_DB_ROOT + "/ncbi_nt/","nt.gz")
#sutils.download_file(ncbi_env_nr_url,BLAST_DB_ROOT + "/ncbi_env_nr/","env_nr.gz")
#sutils.download_file(ncbi_env_nt_url,BLAST_DB_ROOT + "/ncbi_env_nt/","env_nt.gz")
#sutils.download_file(ncbi_pataa_url,BLAST_DB_ROOT + "/ncbi_pataa/","pataa.gz")
#sutils.download_file(ncbi_patnt_url,BLAST_DB_ROOT + "/ncbi_patnt/","patnt.gz")
#sutils.download_file(ncbi_16smicrobial_url,BLAST_DB_ROOT + "/ncbi_16smicrobial/","16SMicrobial.tar.gz")

#prepare public blast databases like NCBi nr, nt, etc.
#This took 66 hours on a single processor. It is not parallelized yet. Size of blastdbs/ directory after this is 2.4TB
#TODO: think about using linux cut command pigz. the compressing seems to be the bottleneck not the creation of the blastdb
#blast.prepare_public_database("ncbi_nr",BLAST_DB_ROOT + "/ncbi_nr/","nr.gz",BLAST_DB_ROOT + "/ncbi_nr/",'prot')
#blast.prepare_public_database("ncbi_nt",BLAST_DB_ROOT + "/ncbi_nt/","nt.gz",BLAST_DB_ROOT + "/ncbi_nt/",'nucl')
#blast.prepare_public_database("ncbi_env_nr",BLAST_DB_ROOT + "/ncbi_env_nr/","env_nr.gz",BLAST_DB_ROOT + "/ncbi_env_nr/",'prot')
#blast.prepare_public_database("ncbi_env_nt",BLAST_DB_ROOT + "/ncbi_env_nt/","env_nt.gz",BLAST_DB_ROOT + "/ncbi_env_nt/",'nucl')
#blast.prepare_public_database("ncbi_pataa",BLAST_DB_ROOT + "/ncbi_pataa/","pataa.gz",BLAST_DB_ROOT + "/ncbi_pataa/",'prot')
#blast.prepare_public_database("ncbi_patnt",BLAST_DB_ROOT + "/ncbi_patnt/","patnt.gz",BLAST_DB_ROOT + "/ncbi_patnt/",'nucl')
#blast.prepare_16s("ncbi_16smicrobial",BLAST_DB_ROOT + "/ncbi_16smicrobial/","16SMicrobial",BLAST_DB_ROOT + "/ncbi_16smicrobial/",'nucl')

#took 40 hours with 34 cores. Final hard disk size after this is 9.67TB
#jbrowse.prepare_jbrowse_data(jb_bindir,jb_datadir,ldp+"genomes.jsonl",34)


#end = time.time()
#print end - start





