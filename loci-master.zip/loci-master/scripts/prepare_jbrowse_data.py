#preparing NCBI genome data for JBrowse

import os
import script_utils as sutils
from multiprocessing import Pool


assembly_acc_str = "assembly_acc"
fpath_str = "file_path"

glob_bindir = ""
glob_outroot = ""


#jBrowse bin directory
#bindir = "~/projects/loci/flaskserver/static/jbrowse/JBrowse-1.12.1/bin/"

#data directory
#datadir = "~/projects/loci/flaskserver/static/jbrowse/JBrowse-1.12.1/loci_jbrowse_data/"


# following instructions here: http://jbrowse.org/code/JBrowse-1.12.3/docs/tutorial/
def prepare_refseq(bindir,in_dir,out_dir,assemid):
    command = bindir + "prepare-refseqs.pl --fasta " + in_dir + "/" + assemid + ".fna.gz " + "--out " + out_dir + "/data/" 
    os.system(command)

def flatfile_to_json(bindir,in_dir,out_dir,assemid, tracktype, tracklabel):
    command = bindir + "flatfile-to-json.pl --gff " + in_dir + "/" + assemid + ".gff " + "--out " + out_dir + "/data/" + " --trackType CanvasFeatures --trackLabel "  + tracklabel +  " --type " + tracktype 
    os.system(command)

def generate_names(bindir,out_dir,assemid):
     command =  command = bindir + "generate-names.pl  --out " + out_dir + "/data/"
     os.system(command)

#input_file is the metadata file that you use to import genomes in import_genomes.py
def copy_jbrowse_files(input_file,input_root,output_root):
    with open(input_file) as fp:
        
        for line in fp:
            
            values = eval(line.strip())
            
            ass_acc = values[assembly_acc_str]
            fpath = values[fpath_str]
            
            input_dir = input_root + "/" + ass_acc + "/"
            output_dir = output_root + "/" + ass_acc + "/"

            mkdir_cmd = "mkdir " + output_dir
            cp_genome_cmd = "cp " + input_dir + ass_acc + ".new.fna " + output_dir
            cp_gff_cmd = "cp " + input_dir + ass_acc + ".gff " + output_dir
            cp_protein_cmd = "cp " + input_dir + ass_acc + ".proteins.new.faa " + output_dir 
            cp_cds_cmd = "cp " + input_dir + ass_acc + ".genes.new.fna " + output_dir 

            os.system(mkdir_cmd)
            os.system(cp_genome_cmd)
            os.system(cp_gff_cmd)
            os.system(cp_protein_cmd)
            os.system(cp_cds_cmd)

#prepares all data for jbrowse
#outroot is the root output directory inside jbrowse. Input directories are in the input file
def prepare_jbrowse_data(bindir_loc,outroot_loc,input_file, num_processes):
    
    global glob_bindir
    global glob_outroot

    sutils.create_if_not_exist(outroot_loc)
    
    glob_bindir = bindir_loc
    glob_outroot = outroot_loc
    
    handle_in = sutils.my_get_handle(input_file,"r")
    
    mypool = Pool(num_processes)
    mypool.map(prepare_jbrowse_data_worker, handle_in)
    mypool.close()
    mypool.join()
    
    handle_in.close()


def prepare_jbrowse_data_worker(line):

    values = eval(line.strip())
    
    ass_acc = values[assembly_acc_str]
    in_dir = values[fpath_str]
    
    #creating the output directories
    out_dir = glob_outroot + "/" + ass_acc
    sutils.create_if_not_exist(out_dir)
         
    prepare_refseq(glob_bindir,in_dir,out_dir,ass_acc)
    flatfile_to_json(glob_bindir,in_dir,out_dir,ass_acc, "gene", "genes")
    generate_names(glob_bindir,out_dir,ass_acc)





'''
copy_jbrowse_files("~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input_metadata.txt",
"~/projects/data/ncbi/refseq_subset_download",
datadir
)


#prepare_jbrowse_data(bindir,datadir,"~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input_metadata.txt")


copy_jbrowse_files("/home/mydirectory/projects/data/ncbi/top150/top150.jsonl",
"/home/mydirectory/projects/data/ncbi/refseq_subset_download",
datadir
)

prepare_jbrowse_data(bindir,datadir,"/home/mydirectory/projects/data/ncbi/top150/top150.jsonl")
'''