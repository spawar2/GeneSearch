import  pymongo
from Bio import SeqIO
from Bio.Seq import Seq
import json
import os
import gzip
import script_utils as sutils
from multiprocessing import Pool
import traceback
import json
from subprocess import Popen, PIPE


#my modules
import taxonomy

assembly_acc_str = "assembly_acc"
taxid_str = "tax_id"
intra_str = "intraspecies_name"	
fpath_str = "file_path"
collection_str = "collection"
privacy_str = "privacy"
species_str = "species"
lineage_str = "lineage"

#global variables that are used for multiprocessing functions
assind = -1
taxind = -1
fileind = -1
intraind = -1
collectionind = -1
privacyind = -1
lineage_dict = {}

glob_mongo_host = "127.0.0.1"
glob_mongo_port = 1401



#https://www.ensembl.org/info/website/upload/gff.html
#general gff indices
gff_seqname_index = 0
gff_source_index = 1
gff_feature_type_index =  2
gff_start_index = 3
gff_end_index = 4
gff_score_index = 5
gff_strand_index = 6
gff_frame_index = 7
gff_attributes_index = 8



#for proteins and genes
seq_type_str = "sequence_type"
genomic_accession_str = "genomic_accession"
start_str = "start_position"
end_str = "end_position"
strand_str = "strand"

accession_str = "accession"
description_str = "description"
symbol_str = "symbol"
locus_tag_str = "locus_tag"
unique_id_str = "unique_id"
length_str = "length"

biotype_str = "biotype"


#get all the metadata (e.g. species name, num genes, gc content) needed as input to the database
#nodes file and names file are the nodes.dmp and names.dmp from ncbi taxonomy database
#stores the metadata in jsonline format to be uploaded into mongo
#https://stackoverflow.com/questions/12451431/loading-and-parsing-a-json-file-with-multiple-json-objects-in-python/12451465#12451465
#
def get_assembly_metadata(dir_root, input_file,out_file,ass_report,nodes_file,names_file,num_processes):

	global lineage_dict
	global assind
	global taxind
	global fileind
	global intraind
	global collectionind
	global privacyind


	lineage_dict = taxonomy.getLineage(ass_report,nodes_file,names_file)
	
	fp = sutils.my_get_handle(input_file,"r")
	firstline = fp.readline()
	keys = firstline.strip().split("\t")
	#stripping each element in the list
	keys = map(str.strip,keys)
			
	assind = keys.index(assembly_acc_str)
	taxind = keys.index(taxid_str)
	fileind = keys.index(fpath_str)
	intraind = keys.index(intra_str)
	collectionind = keys.index(collection_str)
	privacyind = keys.index(privacy_str)

	mypool = Pool(num_processes)
	mypool.map(get_assembly_metadata_worker, fp)
	mypool.close()
	mypool.join()

	#concatenating all files
	os.chdir(dir_root)
	cmd = "find . -name *.genome.jsonl | xargs cat > " + out_file
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	fp.close()

	

def get_assembly_metadata_worker(line):
		
	values = line.strip().split("\t")
	#stripping each element
	values = map(str.strip,values)

	ass_acc = values[assind]
	tax_id = values[taxind]
	fpath = values[fileind]
	intra_name = values[intraind]
	collection = values[collectionind]
	privacy = values[privacyind]

	output_file = fpath + "/" + ass_acc + ".genome.jsonl"
	of = sutils.my_get_handle(output_file, 'w')
	
	try:
		species_info = taxonomy.get_rank_info(lineage_dict,tax_id,"species")
	except KeyError:
		#executed when the tax_id is not found
		print tax_id, "  not found. skipping ..."
		return

	species = species_info['name']
		
	#getting number of proteins
	gff_file = fpath + "/" + ass_acc + ".gff"
	gene_info = get_gene_info(gff_file)
	num_genes = gene_info[0]
	num_proteins = gene_info[1]

	#getting size and gc content
	fna_file = fpath + "/" + ass_acc + ".fna.gz"
	my_info = get_gc_and_size(fna_file)
	#converting it to a string with 2 decimal points
	size = format(my_info[0], '.2f')
	gc = format(my_info[1] * 100, '.2f')

	my_dict = {}
	my_dict["assembly_acc"] = ass_acc
	my_dict["tax_id"] = tax_id
	my_dict["intraspecies_name"] = intra_name
	my_dict["species"] = species
	my_dict["num_genes"] = str(num_genes)
	my_dict["num_proteins"] = str(num_proteins)
	my_dict["size"] = size
	my_dict["gc"] = gc
	my_dict["lineage"] = lineage_dict[tax_id]
	my_dict["file_path"] = fpath
	my_dict["collection"] = collection
	my_dict["privacy"] = privacy

	of.write(json.dumps(my_dict) + "\n")
	of.close()



#gets number of genes, proteins
def get_gene_info(gff_file):

	num_proteins = 0
	num_genes = 0
	with open(gff_file) as fp:
		for line in fp:
			if "gene_biotype=protein_coding" in line:
				num_proteins = num_proteins + 1
			
			values = line.strip().split("\t")
			#stripping each element
			values = map(str.strip,values)

			#Making sure it is not a comment line or anything else
			if len(values) == 9:
				if values[2] == "gene":
					num_genes = num_genes + 1

			
	
	return [num_genes,num_proteins]

def get_gc_and_size(fasta_file):
	
	size = 0.0
	a_count = 0.0
	t_count = 0.0
	g_count = 0.0
	c_count = 0.0

	if fasta_file.endswith(".gz"):
		handle = gzip.open(fasta_file,"r")
	else:
		handle = open(fasta_file,"r")

	for record in SeqIO.parse(handle, "fasta"):
		#converting the sequence object to upper case so the count method can be used properly
		my_dna = record.seq.upper()
		size = size + len(my_dna)
		a_count = a_count + my_dna.count("A")
		t_count = t_count + my_dna.count("T")
		g_count = g_count + my_dna.count("G")
		c_count = c_count + my_dna.count("C")

	#getting size in mb
	size = size/1000000
	gc = (g_count + c_count)/(a_count +  t_count + g_count +  c_count)

	return([size,gc])




def importGenomes(fileName):

	client = MongoClient("localhost",27017)
	
	#this will create the db and collection if it is not already present	
	db = client.omics
	collection = db.genomes
	

	with open(fileName) as fp:

		for line in fp:
			line = line.strip()
			my_data = json.loads(line)
			#removing file path because it doesnt jhave to be in the database
			my_data.pop(fpath_str)
			ins_id = 	collection.insert_one(my_data).inserted_id
			print(ins_id)
	

#creates a collection with search strings for each genus, species, etc.  for use in the app.
def create_search_strings(file_name,out_dir):

	my_out = out_dir + "genomes.ss.jsonl.gz"
	of = sutils.my_get_handle(my_out, 'w')
	in_handle = sutils.my_get_handle(file_name,"r")

	for line in in_handle:
		line = line.strip()
		my_data = json.loads(line)

		#a document for accession
		acc_doc = {}
		acc_doc["name"] = my_data["assembly_acc"]
		acc_doc["type"] = "assembly_acc"
		acc_doc["tax_id"] = ""
		
		of.write(json.dumps(acc_doc) + "\n")

		#a document for intraspecies name
		intra_doc = {}
		intra_doc["name"] = my_data["intraspecies_name"]
		intra_doc["type"] = "intraspecies_name"
		intra_doc["tax_id"] = ""

		of.write(json.dumps(intra_doc) + "\n")

		#a document for genome collection
		coll_doc = {}
		coll_doc["name"] = my_data["collection"]
		coll_doc["type"] = "collection"
		coll_doc["tax_id"] = ""

		of.write(json.dumps(coll_doc) + "\n")
		
		lineage = my_data["lineage"]
		for item in lineage:
			#dont allow any "no rank" entries
			if item["rank"] != "no rank":
				#renaming "rank" to "type"
				item["type"] = item.pop("rank")
				of.write(json.dumps(item) + "\n")
				
	in_handle.close()
	of.close()

	#getting unique search strings
	uniq_file = out_dir + "genomes.ss.uniq.jsonl"
	command = "zcat " + my_out  + " | sort -u > " + uniq_file
	Popen(command, stdin=PIPE, stdout=PIPE,shell=True).wait()

	#getting search strings that are common for genomes, genes, and proteins. this will be added to genes and proteins search strings
	command = "grep -v \'\"type\": \"intraspecies_name\"\' " + uniq_file + " > " + out_dir + "common.ss.jsonl"
	Popen(command, stdin=PIPE, stdout=PIPE,shell=True).wait()

#https://www.ensembl.org/info/website/upload/gff.html
def get_gff_dict(file_name):

	gff_dict = {}
	
	with open(file_name) as fp:
		for line in fp:
			
			#if it is not a comment line
			if(not line.startswith("#")):
				words = line.strip().split("\t")

				region = words[0]
				attributes = words[8]

				#if it is a region
				if words[2] == "region":
					
					gff_dict[region] = {}
					gff_dict[region]["region"] = line

				#if it is a gene
				#pseudogenes are not stored
				elif words[2] == "gene":
					#getting the gene ID
					gene_id = find_between(attributes,"ID=",";")
					gff_dict[region][gene_id] = {}
					gff_dict[region][gene_id]["gene"] = line
				else:
					feature_id = find_between(attributes,"ID=",";")
					parent_id = find_between(attributes,"Parent=",";")
					#only the children of genes are stored
					#there are some lines of type "exon" whose parents are rna. they are not added here. pseudogenes are also not added
					if parent_id in gff_dict[region]:
						gff_dict[region][parent_id][feature_id] = line

	return gff_dict

#https://stackoverflow.com/questions/3368969/find-string-between-two-substrings
def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

#gets fasta sequnces and jsonl for genes and proteins in all genomes
#adds mylocidb attribute to gene, protein and genome fasta files
def process_all_genome_files(in_file,num_processes):

	handle_in = sutils.my_get_handle(in_file,"r")

	mypool = Pool(num_processes)
	mypool.map(process_all_genome_files_worker, handle_in)
	mypool.close()
	mypool.join()

	handle_in.close()

def process_all_genome_files_worker(line):
	
	line = line.strip()
	my_data = json.loads(line)
	
	#getting file path
	fpath = my_data[fpath_str]
	
	assembly_acc = my_data[assembly_acc_str]
	gff_file = fpath + "/" + assembly_acc + ".gff"
	
	genome_file = fpath + "/" + assembly_acc + ".fna.gz"
	genome_file_out = fpath + "/" + assembly_acc + ".new.fna.gz"
	
	protein_fasta_out = fpath + "/" + assembly_acc + ".proteins.faa.gz"
	gene_fasta_out = fpath + "/" + assembly_acc + ".genes.fna.gz"
	
	protein_jsonl_out = fpath + "/" + assembly_acc + ".proteins.jsonl.gz"
	gene_jsonl_out = fpath + "/" + assembly_acc + ".genes.jsonl.gz"

	error_file = fpath + "/" + assembly_acc + ".err.txt.gz"
	
	print assembly_acc

	try:
		#add MyLociAttributes to genome files
		process_fasta(genome_file,genome_file_out,assembly_acc)
		get_genes_proteins_info(my_data,gff_file,genome_file_out,protein_fasta_out,gene_fasta_out,protein_jsonl_out,gene_jsonl_out,error_file)
	except Exception as ex:
		print "Unknown Error: " + assembly_acc



#gets fasta sequences and jsonl for genes and proteins in a single genome
def get_genes_proteins_info(assembly_dict,gff_file_name,genome_fasta,protein_out_file,gene_out_file,proteins_jsonl,genes_jsonl,error_file):
	
	gof = sutils.my_get_handle(gene_out_file, 'w')
	pof = sutils.my_get_handle(protein_out_file,'w')
	pjson = sutils.my_get_handle(proteins_jsonl,'w')
	gjson = sutils.my_get_handle(genes_jsonl,'w')
	eof = sutils.my_get_handle(error_file,'w')

	fasta_dict = load_genome_fasta(genome_fasta)
	gff_dict = get_gff_dict(gff_file_name)

	assembly_acc = assembly_dict[assembly_acc_str]

	#these are used as search strings for live search
	protein_ids_dict = {}
	protein_desc_dict = {}

	gene_ids_dict = {}
	gene_desc_dict = {}
	gene_biotype_dict = {}


	for region in gff_dict:

		region_line = gff_dict[region]["region"]
		region_words = region_line.split("\t")

		#for all genes in the region
		for gene in gff_dict[region]:
			if gene != "region":

				gene_line =  gff_dict[region][gene]["gene"]
				gene_words = gene_line.split("\t")
				gene_biotype = get_feature_attribute(gene_words,"gene_biotype")
				gene_partial =  get_feature_attribute(gene_words,"partial")
				gene_id = get_feature_attribute(gene_words,"ID")
				gene_desc = ""
				gene_transl_except = ""
				gene_exception = ""


				#if it is a protein coding gene, at least one product must be printed in the protein fasta file
				num_printed_products  = 0

				for feature in gff_dict[region][gene]:

					if(feature != "gene"):
						#it is a child of a gene

						feat_line = gff_dict[region][gene][feature]
						feat_words = feat_line.split("\t")
						feat_type = feat_words[2]

						gene_transl_except = get_feature_attribute(feat_words,"transl_except")
						gene_exception = get_feature_attribute(feat_words,"exception")
						
						#getting product description to set it to gene description
						gene_desc = get_feature_attribute(feat_words,"product")


						if feat_type ==  "CDS":
							if(gene_biotype != "pseudogene"):
								if gene_partial != "true":
									if gene_transl_except == "":
										if gene_exception == "":
											try:
												write_protein_fasta(assembly_acc,region_words,feat_words,pof,fasta_dict)
											except:
												eof.write(get_feature_attribute(feat_words,"ID") + "\n")
											else:
												write_protein_jsonl(assembly_dict,region_words,gene_words,feat_words,pjson)
												num_printed_products =  num_printed_products +  1

												#using dict to store unique descriptions
												protein_id = get_feature_attribute(feat_words,"ID")
												protein_id = protein_id.replace("cds","protein")
												protein_ids_dict[protein_id] = 0
												
												protein_desc = get_feature_attribute(feat_words,"product")
												protein_desc_dict[protein_desc] = 0

									
								#TODO need to handle partial cds
								#make sure cds=true parameter should not be set for the translate function here
								'''
								else:
									
								'''
				
				#not writing if it is a pseudogene or partial gene
				if gene_biotype != "pseudogene" and gene_partial != "true" and gene_transl_except == "" and gene_exception == "":
					try:
						#if it is a protein coding gene, print it only if at least one of its product is printed in the protein file
						if gene_biotype == "protein_coding":
							if num_printed_products > 0:
								write_gene_fasta(assembly_acc,region_words,gene_words,gene_desc,gof,fasta_dict)
						else:
							write_gene_fasta(assembly_acc,region_words,gene_words,gene_desc,gof,fasta_dict)

					except:
						eof.write(get_feature_attribute(gene_words,"ID") + "\n")
					else:
						write_genes_jsonl(assembly_dict,region_words,gene_words,gene_desc,gjson)

						#using the dict to store unique descriptions
						gene_desc_dict[gene_desc] = 0
						gene_biotype_dict[gene_biotype] = 0
						gene_ids_dict[gene_id] = 0



	#writing files necessary for search strings
	write_search_string_files(assembly_dict,gene_ids_dict,gene_desc_dict,gene_biotype_dict,protein_ids_dict,protein_desc_dict)

	gof.close()
	pof.close()
	pjson.close()
	gjson.close()
	eof.close()


#writing files required for search strings
def write_search_string_files(assembly_dict,gene_ids_dict,gene_desc_dict,gene_biotype_dict,protein_ids_dict,protein_desc_dict):
	
	fpath = assembly_dict[fpath_str]
	
	assembly_acc = assembly_dict[assembly_acc_str]

	gidf = sutils.my_get_handle(fpath + "/" + assembly_acc + ".genes.id.gz","w")
	gdescf = sutils.my_get_handle(fpath + "/" + assembly_acc + ".genes.desc.gz","w")
	gbiof = sutils.my_get_handle(fpath + "/" + assembly_acc + ".genes.biotype.gz","w")

	pidf = sutils.my_get_handle(fpath + "/" + assembly_acc + ".proteins.id.gz","w")
	pdescf = sutils.my_get_handle(fpath + "/" + assembly_acc + ".proteins.desc.gz","w")

	for gid in gene_ids_dict:
		gidf.write(json.dumps(create_doc_dict(gid,"unique_id","")) + "\n")

	for gdesc in gene_desc_dict:
		gdescf.write(json.dumps(create_doc_dict(gdesc,"description","")) + "\n")

	for gbio in gene_biotype_dict:
		gbiof.write(json.dumps(create_doc_dict(gbio,"biotype","")) + "\n")

	
	for pid in protein_ids_dict:
		pidf.write(json.dumps(create_doc_dict(pid,"unique_id","")) + "\n")
	
	for pdesc in protein_desc_dict:
		pdescf.write(json.dumps(create_doc_dict(pdesc,"description","")) + "\n")
	

	gidf.close()
	gdescf.close()
	gbiof.close()
	pidf.close()
	pdescf.close()
	

def create_doc_dict(myname,mytype,tax_id):
	name_doc = {}
	name_doc["name"] = myname
	name_doc["type"] = mytype
	name_doc["tax_id"] = tax_id

	return name_doc




def write_genes_jsonl(assembly_dict,region_words,gene_words,gene_desc,out_file_handle):

	genes_dict = {}

	seq_type = get_feature_attribute(region_words,"genome")
	genomic_accession = gene_words[gff_seqname_index]
	start = gene_words[gff_start_index]
	end = gene_words[gff_end_index]
	strand = gene_words[gff_strand_index]

	description = gene_desc
	symbol = get_feature_attribute(gene_words,"gene")

	locus_tag = get_feature_attribute(gene_words,"locus_tag")
	biotype = get_feature_attribute(gene_words,"gene_biotype")

	length = (int (end) - int(start)) + 1

	unique_id =  get_feature_attribute(gene_words,"ID")
	accession = unique_id

	genes_dict[seq_type_str] = seq_type
	genes_dict[genomic_accession_str] = genomic_accession
	genes_dict[start_str] = start
	genes_dict[end_str] = end
	genes_dict[strand_str] = strand
	genes_dict[accession_str] = accession
	genes_dict[description_str] = description
	genes_dict[symbol_str] = symbol
	genes_dict[locus_tag_str] = locus_tag
	genes_dict[length_str] = length
	genes_dict[unique_id_str] = unique_id
	genes_dict[biotype_str] = biotype

	genes_dict[assembly_acc_str] = assembly_dict[assembly_acc_str]
	genes_dict[species_str] = assembly_dict[species_str]
	genes_dict[taxid_str] =  assembly_dict[taxid_str]
	genes_dict[lineage_str] =  assembly_dict[lineage_str]
	genes_dict[privacy_str] =  assembly_dict[privacy_str]
	genes_dict[collection_str] =  assembly_dict[collection_str]
 

	out_file_handle.write(json.dumps(genes_dict) + "\n")

def write_protein_jsonl(assembly_dict,region_words,gene_words,cds_words,out_file_handle):

	cds_dict = {}

	seq_type = get_feature_attribute(region_words,"genome")
	genomic_accession = cds_words[gff_seqname_index]
	start = cds_words[gff_start_index]
	end = cds_words[gff_end_index]
	strand = cds_words[gff_strand_index]

	accession = get_feature_attribute(cds_words,"Name")
	description = get_feature_attribute(cds_words,"product")
	symbol = get_feature_attribute(cds_words,"gene")

	locus_tag = get_feature_attribute(gene_words,"locus_tag")

	length = (int (end) - int(start))/3

	unique_id =  get_feature_attribute(cds_words,"ID")
	#replacing cds with protien
	unique_id = unique_id.replace("cds","protein")
	
	cds_dict[seq_type_str] = seq_type
	cds_dict[genomic_accession_str] = genomic_accession
	cds_dict[start_str] = start
	cds_dict[end_str] = end
	cds_dict[strand_str] = strand
	cds_dict[accession_str] = accession
	cds_dict[description_str] = description
	cds_dict[symbol_str] = symbol
	cds_dict[locus_tag_str] = locus_tag
	cds_dict[length_str] = length
	cds_dict[unique_id_str] = unique_id

	cds_dict[assembly_acc_str] = assembly_dict[assembly_acc_str]
	cds_dict[species_str] = assembly_dict[species_str]
	cds_dict[taxid_str] =  assembly_dict[taxid_str]
	cds_dict[lineage_str] =  assembly_dict[lineage_str]
	cds_dict[privacy_str] =  assembly_dict[privacy_str]
	cds_dict[collection_str] =  assembly_dict[collection_str]
 

	out_file_handle.write(json.dumps(cds_dict) + "\n")



	
	'''
	header = ["assembly_acc",seq_type_str,genomic_accession_str,start_str,end_str,strand_str,product_accession_str,
        "non_redundant_refseq",name_str,symbol_str,locus_tag_str,feature_interval_length_str,product_length_str,species_str,
        tax_id_str,lineage_str,privacy_str,collection_str]
	'''

#Note, if you are going to use this dont strip the line because it uses "\n" as marker
#split the line before sending it into this function
def get_feature_attribute(words,attribute):
	attributes = words[gff_attributes_index]
	attribute_str = attribute + "="
	attribute = find_between(attributes,attribute_str,";")

	if attribute == "":
		attribute = find_between(attributes,attribute_str,"\n")
	
	return attribute
	

def write_protein_fasta(assembly_acc,region_words,cds_words,out_file_handle,fasta_dict):

	region_length = int(region_words[gff_end_index])
	
	region = cds_words[0]
	start = int(cds_words[3])
	end = int(cds_words[4])
	strand = cds_words[6]
						
	feature_id = get_feature_attribute(cds_words,"ID")
	# replcing cds with protein
	feature_id = feature_id.replace("cds","protein")

	product_desc = get_feature_attribute(cds_words,"product")
	transl_table = int(get_feature_attribute(cds_words,"transl_table"))
	feature_parent = get_feature_attribute(cds_words,"Parent")
	
	loci_attributes = sutils.create_protein_loci_attributes(assembly_acc,feature_parent,True)

	
	try:
		
		my_seq = ""
		my_prot_seq = ""
		
		#in circular dna feature end can be greater than the sequence length
		if(end > region_length):
		
			my_seq = fasta_dict[region][start-1:region_length] + fasta_dict[region][0:end - region_length]
		
		else:
			my_seq = fasta_dict[region][start-1:end]

		if strand == "+":
			my_prot_seq = str(my_seq.translate(table=transl_table,cds=True))
		else:
			my_prot_seq = str(my_seq.reverse_complement().translate(table=transl_table,cds=True))

		#fasta header. Contains locidb is set to assembly accession
		out_file_handle.write(">" + feature_id + "\t" + product_desc+ "\t" + loci_attributes + "\n")
		out_file_handle.write( my_prot_seq + "\n")
			
	except:
		raise


def write_gene_fasta(assembly_acc,region_words,gene_words,gene_desc,out_file_handle,fasta_dict):

	region_length = int(region_words[gff_end_index])

	gene_region = gene_words[0]
	gene_start = int(gene_words[3])
	gene_end = int(gene_words[4])
	gene_strand = gene_words[6]
	gene_id = get_feature_attribute(gene_words,"ID")


	loci_attributes = sutils.create_gene_loci_attributes(assembly_acc,True)
	
	try:

		str_seq = ""

		#in circular dna feature end can be greater than the sequence length
		if(gene_end > region_length):
			#print str(end - region_length)
			my_seq = fasta_dict[gene_region][gene_start-1:region_length] + fasta_dict[gene_region][0:gene_end - region_length]
		else:
			my_seq = fasta_dict[gene_region][gene_start-1:gene_end]

		if gene_strand ==  "+":
			str_seq = str(my_seq)
		else:
			str_seq = str(my_seq.reverse_complement())
		
		out_file_handle.write(">" + gene_id + "\t" + gene_desc + "\t" +loci_attributes + "\n")
		out_file_handle.write(str_seq + "\n")

	except:
		raise
					


def load_genome_fasta (fasta_file):

	if fasta_file.endswith(".gz"):
		handle = gzip.open(fasta_file,"r")
	else:
		handle = open(fasta_file,"r")
	
	fasta_dict = {}
	for record in SeqIO.parse(handle, "fasta"):
		fasta_dict[record.id] = record.seq
	
	return fasta_dict

#processes a fasta file and adds mylocidb attribute to its description
#NOTE: keep an eye on this function. it might be slow because its reading genomes into memory
def process_fasta(in_file,out_file,assembly_acc):

	handle = sutils.my_get_handle(in_file,"r")

	out = sutils.my_get_handle(out_file,"w")


	for record in SeqIO.parse(handle, "fasta"):
		#split on whitespace
		words = record.description.split(None,1)
		if len(words) > 1:
			id = words[0]
			desc = words[1]
		else:
			id = words[0]
			desc = "N/A"

		loci_attributes = sutils.create_genome_loci_attributes(assembly_acc,True)
		record.description = id + "\t" + desc + "\t" + loci_attributes
		SeqIO.write(record,out,"fasta")
	
	out.close()
	handle.close()




#pre processes gff files for loci
# currently adds the assembly accession to all features in the gff file
# can add further preprocessing here later
def pre_process_gff(in_file,out_file,assembly_acc):
	
	in_handle = sutils.my_get_handle(in_file,"r")
	out_handle = sutils.my_get_handle(out_file,"w")
	
	for line in in_handle:
		#if it is a comment line just print the line
		if line.startswith("#"):
			out_handle.write(line)
		else:
			#not stripping the line because get_feature_attribute needs the \n to be intact
			words = line.split("\t")
			attributes = words[gff_attributes_index]

			#printing attributes before changing
			#print attributes

			my_id = get_feature_attribute(words,"ID")
			my_parent = get_feature_attribute(words,"Parent")

			#if there is an ID attribute
			if my_id != "":
				new_id = assembly_acc + "_" + my_id
				
				#giving it a new ID
				attributes = attributes.replace("ID="+my_id+";","ID="+new_id+";")

			#if there is a Parent attribute
			if my_parent != "":
				new_parent = assembly_acc + "_" + my_parent

				#giving a new parent name
				attributes = attributes.replace("Parent="+my_parent+";","Parent="+new_parent+";")

			#printing attributes after changing
			#print attributes

			words[gff_attributes_index] = attributes
			out_handle.write("\t".join(words))
			
			
	
	out_handle.close()
	in_handle.close()


#gff file is unzipped here because jbrowse requires unzipped gff
#i have not yet found a way to use compressed gff with jbrowse
def preprocess_refseq_files(in_file,num_processes):
	
	handle_in = sutils.my_get_handle(in_file,"r")
	
	firstline = handle_in.readline()
	keys = firstline.strip().split("\t")
	#stripping each element in the list
	keys = map(str.strip,keys)
			
	global assind
	global fileind

	#assigning the indices here. will be used in the worker
	assind = keys.index(assembly_acc_str)
	fileind = keys.index(fpath_str)
	
	mypool = Pool(num_processes)
	mypool.map(preprocess_refseq_files_worker, handle_in)
	mypool.close()
	mypool.join()

	#reassigning them to -1
	assind = -1
	fileind = -1
	
	handle_in.close()

#worker for multi processing
def preprocess_refseq_files_worker(line):

	words = line.strip().split("\t")
	#these indicies were originally assigned in the the function that calls pool.map
	assembly = words[assind]
	file_path = words[fileind]
	gff_in = file_path + "/" + assembly + ".gff.gz"
	gff_out = file_path + "/" + assembly + ".gff"
	
	pre_process_gff(gff_in,gff_out,assembly)


def cleanup_refseq_files(in_file):
	
	handle_in = sutils.my_get_handle(in_file,"r")
	
	firstline = handle_in.readline()
	keys = firstline.strip().split("\t")
	#stripping each element in the list
	keys = map(str.strip,keys)
			
	assind = keys.index(assembly_acc_str)
	fileind = keys.index(fpath_str)

	for line in handle_in:
		words = line.strip().split("\t")
		assembly = words[assind]
		file_path = words[fileind]

		gff_file = file_path + "/" + assembly + ".gff.gz"

		
		command1 = "rm " + gff_file
		
		os.system(command1)
		
	handle_in.close()

#cleanup before preparing jbrowse and blast databases
def cleanup_2(input_file,ldp):

	
	in_handle = sutils.my_get_handle(input_file,"r")

	for line in in_handle:
		values = json.loads(line.strip())
		
		fpath = values[fpath_str]
		assembly_acc = values[assembly_acc_str]

		in_fna = fpath + "/" + assembly_acc + ".new.fna.gz"
		out_fna = fpath + "/" + assembly_acc + ".fna.gz"
		
		command1 = "mv " + in_fna + " " + out_fna
		#print command1
		Popen(command1, stdin=PIPE, stdout=PIPE,shell=True).wait()

	#removing temp files in ldp
	os.chdir(ldp)
	print "Cleaning up temporary files ..."
	cmd = "rm *.tmp"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()


#merges files and creates search strings
def merge_files_from_genomes(root_dir):
	os.chdir(root_dir)
	
	print "Merging gene files ..."
	cmd = "find data/ -name *.genes.jsonl.gz | xargs cat > genes.jsonl.gz"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	print "Merging protein files ..."
	cmd = "find data/ -name *.proteins.jsonl.gz | xargs cat > proteins.jsonl.gz"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	print "Merging gene ids ..."
	cmd = "find data/ -name *.genes.id.gz | xargs zcat > genes.id.tmp"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	print "Merging gene descriptions ..."
	cmd = "find data/ -name *.genes.desc.gz | xargs zcat > genes.desc.tmp"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	print "Merging biotypes"
	cmd = "find data/ -name *.genes.biotype.gz | xargs zcat > genes.biotype.tmp"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	print "Merging protein ids ..."
	cmd = "find data/ -name *.proteins.id.gz | xargs zcat > proteins.id.tmp"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	print "Merging protein descriptions ..."
	cmd = "find data/ -name *.proteins.desc.gz | xargs zcat > proteins.desc.tmp"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()


def create_gene_protein_search_strings(root_dir,sort_perc,num_processors):
	
	os.chdir(root_dir)
	
	
	print "Finding unique gene descriptions ..."
	cmd = "sort -u -S " + sort_perc + " --parallel " + str(num_processors) + " -o " + "genes.desc.uniq.tmp genes.desc.tmp"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	print "Finding unique gene biotypes ..."
	cmd = "sort -u -S " + sort_perc + " --parallel " + str(num_processors) + " -o " + "genes.biotype.uniq.tmp genes.biotype.tmp"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	print "Concatenating gene files .."
	cmd = "cat genes.desc.uniq.tmp > genes.ss.uniq.jsonl"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()
	cmd = "cat genes.biotype.uniq.tmp >> genes.ss.uniq.jsonl"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()
	cmd = "cat common.ss.jsonl  >> genes.ss.uniq.jsonl"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	
	print "Finding unique protein descriptions ..."
	cmd = "sort -u -S " + sort_perc + " --parallel " + str(num_processors) + " -o " + "proteins.desc.uniq.tmp proteins.desc.tmp"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

	
	print "Concatenating protein files .."
	cmd = "cat proteins.desc.uniq.tmp > proteins.ss.uniq.jsonl"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()
	cmd = "cat common.ss.jsonl  >> proteins.ss.uniq.jsonl"
	Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()


#learnt that this doesnt really reduce time because mongod process creates index
#and mongod runs in a single processor
def create_all_indexes(host,port,num_processes,chunksize):
	
	global glob_mongo_port
	global glob_mongo_host

	glob_mongo_port = port
	glob_mongo_host = host



	#list of lists
	my_list = [
		{'collection':'genes', 'index':[('assembly_acc', pymongo.ASCENDING)]},
		{'collection':'genes', 'index':[('description', pymongo.ASCENDING)]},
		{'collection':'genes', 'index':[('unique_id', pymongo.ASCENDING)]},
		{'collection':'genes', 'index':[('biotype', pymongo.ASCENDING)]},
		{'collection':'genes', 'index':[('collection', pymongo.ASCENDING)]},
		{'collection':'genes','index':[('lineage.name', pymongo.ASCENDING),('lineage.rank', pymongo.ASCENDING),('lineage.tax_id', pymongo.ASCENDING)]},
		{'collection':'genes', 'index':[('privacy', pymongo.ASCENDING)]},

		{'collection':'proteins', 'index':[('assembly_acc', pymongo.ASCENDING)]},
		{'collection':'proteins', 'index':[('description', pymongo.ASCENDING)]},
		{'collection':'proteins', 'index':[('unique_id', pymongo.ASCENDING)]},
		{'collection':'proteins', 'index':[('collection', pymongo.ASCENDING)]},
		{'collection':'proteins','index':[('lineage.name', pymongo.ASCENDING),('lineage.rank', pymongo.ASCENDING),('lineage.tax_id', pymongo.ASCENDING)]},
		{'collection':'proteins', 'index':[('privacy', pymongo.ASCENDING)]}
	]
	
	mypool = Pool(num_processes)
	mypool.map(create_all_indexes_worker, my_list,chunksize)
	mypool.close()
	mypool.join()

#https://stackoverflow.com/questions/48055354/how-to-multiprocessing-pool-with-pymongo-in-python-2-7?rq=1
def create_all_indexes_worker(item):
	global glob_mongo_port
	global glob_mongo_host

	client = pymongo.MongoClient(glob_mongo_host,glob_mongo_port)
	db = client.omics

	my_col = item["collection"]
	my_index = item["index"]

	if my_col == "genes":
		my_collection = db.genes
	elif my_col == "proteins":
		my_collection = db.proteins

	result = my_collection.create_index(my_index)
	print result

	client.close()



'''	

if __name__ == "__main__":
	process_all_genome_files("/home/anitanavin/projects/data/test/test.jsonl",1)

	

get_assembly_metadata("~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input.txt",
"~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input_metadata.jsonl",
"~/projects/data/ncbi/assembly_summary_refseq.txt",
"~/projects/data/ncbi/taxonomy/nodes.dmp",
"~/projects/data/ncbi/taxonomy/names.dmp"
)


#importGenomes("~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input_metadata.jsonl")
#create_search_strings("~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input_metadata.jsonl");

#for upload to gooogle cloud engine, took the first 150 genomes out of the 1000 using  unix command head
#head -150  ../assembly_summary_refseq_bacteria_subset_gapp_input_metadata.jsonl > top150.jsonl 
#importGenomes("~/projects/data/ncbi/top150/top150.jsonl")
#create_search_strings("~/projects/data/ncbi/top150/top150.jsonl")

#get_gff_dict("~/projects/test/GCF_000161515.1.gff")


get_genes_proteins_info("~/projects/test/GCF_000161515.1.gff",
			"~/projects/test/GCF_000161515.1.fna",
			"~/projects/test/pof.fna",
			"~/projects/test/gof.fna",
			"~/projects/test/proteins.jsonl",
			"~/projects/test/genes.jsonl")


#this function was renamed to process_all_genome_files
#get_all_genes_proteins_info("~/projects/data/ncbi/top150/top150.jsonl")


##adding mylocidb to fasta files
#process_fasta("/home/mydirectory/projects/test","GCF_000161515.1","GCF_000161515.1")
#process_all_genome_files("/home/mydirectory/projects/data/ncbi/top150/top150.jsonl")

#concatenating genes and proteins jsonl from all genomes
#find data/  -name "*.genes.jsonl" -exec cat {} \;  > bacteria_top10_genes.jsonl
#find data/  -name "*.proteins.jsonl" -exec cat {} \;  > bacteria_top10_proteins.jsonl

#process_gff("/home/mydirectory/projects/data/ncbi/refseq_subset_download/GCF_000008365.1/GCF_000008365.1.gff","/home/mydirectory/projects/data/ncbi/refseq_subset_download/GCF_000008365.1/test.gff","test")

'''

