from collections import OrderedDict

#gets thelineage of all tax ids in a assembly report
#PLEASE NOTE: the function assumes that the first line in the report is a comment line
def getLineage(ass_report,nodes_file,names_file):

    #reading the tax ids into a dictionary
    tax_ids = {}
    with open(ass_report) as f:
        
        commentline = f.readline()
        firstline = f.readline()

        keys = firstline.strip().split("\t")
        
        #stripping each element in the list
        keys = map(str.strip,keys)
        
        #indices
        taxind = keys.index("taxid")

        for line in f:
            words = line.strip().split("\t")
            #get function assigns a default value when key is not present
            tax_ids[words[taxind]] = tax_ids.get(words[taxind], 0) + 1
    f.close()


    #reading nodes.dmp into a dictionary
    nodes = {}
    with open(nodes_file) as f:
        for line in f:
            words = line.strip("\t|\n").split("\t|\t")
            #gets the parent and the rank of a tax id (words[0])
            nodes[words[0]] = {'parent': words[1], 'rank': words[2]}
    f.close()

    #getting names
    names = {}
    with open(names_file) as f:
        for line in f:
            words = line.strip("\t|\n").split("\t|\t")
            #the same tax_id has types of names. We are choosing scientific name
            if(words[3] == 'scientific name'):
                #gets the scientific name of a tax id
                names[words[0]] = words[1]
    f.close()
    
    #this is a dict of list of objects
    lineage_dict = {}

    #getting lineage
    for tax_id in tax_ids:
        local_tax_id = tax_id
        #sometimes tax_id is not found in the nodes
        #dont know if Key error can occur in other dicts used below as well
        try:
            rank = nodes[local_tax_id]['rank']
        except KeyError:
            print local_tax_id + " tax id not found in nodes file"
            continue
        lineage = []
        #some unidentified samples can reach top node 1 without going through a superkingdom node
        #e.g. tax id 32644
        while((rank != 'superkingdom') and (local_tax_id != "1")):
            lineage.append({'rank': rank, 'tax_id': local_tax_id, 'name':names[local_tax_id]})
            local_tax_id = nodes[local_tax_id]['parent']
            rank = nodes[local_tax_id]['rank']
        lineage.append({'rank': rank, 'tax_id': local_tax_id, 'name':names[local_tax_id]})
        lineage_dict[tax_id] = lineage

    return lineage_dict

#returns information about a certain rank of the input_taxid. 
#lineage_dict is the output of getLineage
#input_taxid is the key for lineage dict. It is the tax id for whick you are seeking information. e.g. 14228
#rank_name is the level for which you are seeking information. e.g. 'superkingdom'
# Note: this function may raise a key error
#returns None if the rank_name is not present in the lineage
def get_rank_info(lineage_dict,input_taxid,rank_name):

    try:
        my_list = lineage_dict[input_taxid]
    except KeyError:
        raise

    for my_object in my_list:
        if my_object['rank'] == rank_name:
            return my_object
    #if the rank name is not found return none
    return None
    