import os
import gzip
import requests


#Note: there is a copy of this in flaskserver/loci_utils as well
#checks if a file is zipped using gzip and returns appropriate handle
def my_get_handle(file_name,mode):
    if file_name.endswith(".gz"):
        handle = gzip.open(file_name,mode)
    else:
        handle = open(file_name,mode)
    return handle

#create a directory if it doesnt exist
def create_if_not_exist(mydir):
    if not os.path.exists(mydir):
        os.makedirs(mydir)

#creates the loci attributes for proteins
#suffix is added for genome based databases. No suffix added for public db like nr, nt, etc
def create_protein_loci_attributes(locidb,parent,add_suffix):
	attributes = "MyLociAttributes=["
	if add_suffix:
		attributes = attributes + "mylocidb=" + locidb + "_mylociprotein" + ";"
	else:
		attributes = attributes + "mylocidb=" + locidb + ";"
	attributes = attributes + "mylociparent=" + parent + ";"
	attributes = attributes + "]=EndMyLociAttributes"
	return attributes

#creates the loci attributes for genes
#suffix is added for genome based databases. No suffix added for public db like nr, nt, etc
def create_gene_loci_attributes(locidb,add_suffix):
	attributes = "MyLociAttributes=["
	if add_suffix:
		attributes = attributes + "mylocidb=" + locidb + "_mylocigene" + ";"
	else:
		attributes = attributes + "mylocidb=" + locidb + ";"
	attributes = attributes + "]=EndMyLociAttributes"
	return attributes


#creates the loci attributes for genomes
#suffix is added for genome based databases. No suffix added for public db like nr, nt, etc
def create_genome_loci_attributes(locidb,add_suffix):
	attributes = "MyLociAttributes=["
	if add_suffix:
		attributes = attributes + "mylocidb=" + locidb + "_mylocigenome" + ";"
	else:
		attributes = attributes + "mylocidb=" + locidb + ";"
	attributes = attributes + "]=EndMyLociAttributes"
	return attributes

#gets actual description from biopython description of a fasta sequence
#Note: this is NOT for loci fasta files where desc= prefix is added

def get_fasta_description(desc):
	new_desc = ""
	words = desc.strip().split()

	#sometimes there is no description only ID
	if len(words) >=2:
		new_desc = desc[len(words[0]) : ]
		new_desc = new_desc.strip()

	return new_desc

#gets loci description from a biopython description
def make_loci_description(desc):
	fasta_desc = get_fasta_description(desc)
	if fasta_desc == "":
		return "desc=NA"
	else:
		return "desc="+fasta_desc

#downloads a file from url
#creates output directory if it does not exist
#https://stackoverflow.com/questions/16694907/how-to-download-large-file-in-python-with-requests-py
#Note: tested this function with the basic wget unix command. this works faster than wget.
#I was able to download 200M with this function and 100MB with wget in a minute
def download_file(url,out_dir,out_file):


	print "Downloading: " + url
	create_if_not_exist(out_dir)
	local_filename = out_dir + "/" + out_file
	# NOTE the stream=True parameter
	r = requests.get(url, stream=True)
	with open(local_filename, 'wb') as f:
		for chunk in r.iter_content(chunk_size=1024): 
			if chunk: # filter out keep-alive new chunks
				f.write(chunk)
	return local_filename

