import gzip
import time
#from tokyo.cabinet import *
#import bsddb

from multiprocessing import Pool

assembly_acc_str = "assembly_acc"
seq_type_str = "seq_type"
genomic_accession_str = "genomic_accession"	
start_str = "start"	
end_str = "end"	
strand_str = "strand"
product_accession_str = "product_accession"	
non_redundant_refseq_str = "non_redundant_refseq"	
name_str = "name"	
symbol_str = "symbol"	
locus_tag_str = "locus_tag"	
feature_interval_length_str = "feature_interval_length"	
product_length_str = "product_length"


def create_genes_json(file_name,out_file):

    if out_file.endswith(".gz"):
        of = gzip.open(out_file, 'wb')
    else:
        of = open(out_file, 'w')

    
    if file_name.endswith(".gz"):
        fp = gzip.open(file_name, 'rb')
    else:
        fp = open(file_name,"r")
    

        
    firstline = fp.readline()
    keys = firstline.strip().split("\t")
    #stripping each element in the list
    keys = map(str.strip,keys)
        

    #indices
    assembly_acc_ind = keys.index(assembly_acc_str)
    seq_type_ind = keys.index(seq_type_str)
    genomic_accession_ind = keys.index(genomic_accession_str)	
    start_ind = keys.index(start_str)
    end_ind = keys.index(end_str)
    strand_ind = keys.index(strand_str)
    product_accession_ind = keys.index(product_accession_str)	
    non_redundant_refseq_ind = keys.index(non_redundant_refseq_str)	
    name_ind = keys.index(name_str)
    symbol_ind = keys.index(symbol_str)
    locus_tag_ind = keys.index(locus_tag_str)	
    feature_interval_length_ind = keys.index(feature_interval_length_str)
    product_length_ind = keys.index(product_length_str)

    for line in fp:
        old_values = line.strip(" \n").split("\t")
        #stripping each element. strips only space and \n. \t is not stripped
        #https://stackoverflow.com/questions/10212445/python-map-list-item-to-function-with-arguments
        values = [p.strip() for p in old_values]

        my_dict = {}
        ss = []
        
        if values[assembly_acc_ind] != "":
            my_dict[assembly_acc_str] =  values[assembly_acc_ind]
            ss.append(values[assembly_acc_ind])

        if values[seq_type_ind] != "":
            my_dict[seq_type_str] =  values[seq_type_ind]

        if  values[genomic_accession_ind] != "":
            my_dict[genomic_accession_str] =  values[genomic_accession_ind]
            ss.append( values[genomic_accession_ind])

        if values[start_ind] != "":
            my_dict[start_str] =  values[start_ind]

        if values[end_ind] != "":
            my_dict[end_str] =  values[end_ind]

        if values[strand_ind] != "":
            my_dict[strand_str] =  values[strand_ind]

        if values[product_accession_ind] != "":
            my_dict[product_accession_str] =  values[product_accession_ind]
            ss.append(values[product_accession_ind])

        if values[non_redundant_refseq_ind] != "":
            my_dict[non_redundant_refseq_str] =  values[non_redundant_refseq_ind]

        if values[name_ind] != "":
            my_dict[name_str] =  values[name_ind]
            ss.extend(create_search_strings(values[name_ind]))

        if values[symbol_ind] != "":
            my_dict[symbol_str] =  values[symbol_ind]
            ss.append(values[symbol_ind])

        if values[locus_tag_ind] != "":
            my_dict[locus_tag_str] =  values[locus_tag_ind]
            ss.append( values[locus_tag_ind])

        if values[feature_interval_length_ind] != "":
            my_dict[feature_interval_length_str] =  values[feature_interval_length_ind]

        if values[product_length_ind] != "":
            my_dict[product_length_str] =  values[product_length_ind]
        
        ss_str = " ".join(ss)
        my_dict["search_strings"] = ss_str

        of.write(str(my_dict) + "\n")

def create_search_strings(input_str):
    
    result = []
    result.append(input_str)
    num_spaces = input_str.count(' ')
    for i in range(num_spaces):
        result.append(input_str.split(' ' , i+1)[i+1])
    
    return result


def add_search_strings(in_file,out_file):

    if out_file.endswith(".gz"):
        of = gzip.open(out_file, 'wb')
    else:
        of = open(out_file, 'w')

    
    if in_file.endswith(".gz"):
        fp = gzip.open(in_file, 'rb')
    else:
        fp = open(in_file,"r")
    
    my_dict = {}

    for line in fp:
        values = line.strip(" \n").split("\t")
        my_dict["name"] = values[0]
        my_dict["type"] = values[1]
        my_dict["tax_id"] = values[2]
        my_dict["search_strings"] = create_search_strings(values[0])

        of.write(str(my_dict) + "\n")


def create_large_file(file_name):
    f = open(file_name,'w')
    for i in range(3601):
        print i
        f.write(str(i) + "\n")
        f.flush()
        time.sleep(1)
    f.close()

def create_tokyo():
    
    hdb = HDB()

    #if need be, you should call tune/setcache/setxmsiz/setdfunit before
    # open, ex. with default values:
    print "hi"
    hdb.tune(75000000,-1, -1, 0)
    hdb.setcache(0)
    hdb.setxmsiz(0)
    hdb.setdfunit(0)

    print "hi1"

    # open the database
    hdb.open("/home/mydirectory/projects/software/tokyocabinet/tokyo1.tch", HDBOWRITER | HDBOCREAT)

    print "hi2"
    
    for i in xrange(150000000):
        if i % 500000 == 0:
            print i 
        hdb["key" + str(i)] = "1000000000,10,101,10"

    print hdb["key100"]


    # close the database
    hdb.close()

def query_tokyo():
    
    hdb = HDB()
    hdb.open("/home/mydirectory/projects/software/tokyocabinet/tokyo1.tch", HDBOREADER)
    print hdb["key10007000"]
    hdb.close()


def create_berkley():
    

    # open the database
    db =  bsddb.btopen("/home/mydirectory/projects/software/tokyocabinet/berkley.db","c")

    
    for i in xrange(150000000):
        if i % 500000 == 0:
            print i 
        db["key" + str(i)] = "1000000000,10,101,10"

    print db["key100"]


    # close the database
    db.close()


def query_berkley():
    

    # open the database
    db =  bsddb.btopen("/home/mydirectory/projects/software/tokyocabinet/berkley.db","c")
    print db["key600000"]
    db.close()



def add3(a):
    print a+1
    return a+1


x = [1,2,3,4,5]

def pool_handler():
    p = Pool(2)
    p.map(add3, x)




#add_search_strings("~/projects/data/ncbi/all_refseq_baterial_cds.ss.new.tsv.gz","~/projects/data/ncbi/all_refseq_baterial_cds.ss.new.jsonl.gz")
#create_genes_json("~/projects/data/ncbi/all_refseq_baterial_cds.tsv.gz","~/projects/data/ncbi/all_refseq_baterial_cds.jsonl.gz")
#create_large_file("/home/mydirectory/projects/loci/flaskserver/static/data/test.fa")

#create_tokyo()
#query_tokyo()

#create_berkley()
#query_berkley()

pool_handler()

