import filter_assemblies as myfilter
import import_genomes as genomes
import prepare_dashboard as dashboard
import prepare_jbrowse_data as jbrowse
import prepare_blast_databases as blast
import script_utils as sutils


'''
THIS IS A TOY EXAMPLE FOR DATA PREPARATION IN LOCI
Instructions:
1) Read each and every line carefully
2) Multi line comments contains text to read and commands that need to be executed in linux command line
3) Single line comments are python functions that needs to be run. You have to run these one function at a time
(i.e) uncomment a function, run it, comment it again before you run the next function
4) variable definitions (mostly dicrectory names) are not commented. such variable names are introduced as they arise in the code
instead of everything in the begining to make it easier to undeerstand
'''




'''
mdp is the directory where initial sequences and taxonomy information are downloaded
in this example mdp = "/home/mydirectory/projects/data/driver_example"
in command line type mkdir /home/mydirectory/projects/data/driver_example
'''

mdp = "/home/mydirectory/projects/data/driver_example/"

'''
download assembly_summary_refseq.txt from ftp://ftp.ncbi.nlm.nih.gov/genomes/refseq/ to mdp directory
This is the file that contains metadata about all ref_seq assemblies including taxonomy IDs
in command line type the following
cd /home/mydirectory/projects/data/driver_example
wget ftp://ftp.ncbi.nlm.nih.gov/genomes/refseq/assembly_summary_refseq.txt
'''

'''
next create a directory for downloading and unzipping taxonomy information
in mdp create a directory called taxonomy

mkdir /home/mydirectory/projects/data/driver_example/taxonomy

then go into the taxonomy directory and download the file

cd /home/mydirectory/projects/data/driver_example/taxonomy
wget ftp://ftp.ncbi.nih.gov/pub/taxonomy/taxdump.tar.gz
tar -xvf taxdump.tar.gz
'''

'''
assembly_summary_refseq.txt contains assembly metadata from all species. Now we identify only the bacterial genome assemblies
the metadata about bacterial assemblies are stored in mdb + assembly_summary_refseq_bacteria.txt file
the function may print some stuff like "1234 not found ... skipping". this is normal
'''
#myfilter.get_refseq_rank(mdp+ "assembly_summary_refseq.txt",mdp+"assembly_summary_refseq_bacteria.txt","superkingdom","2",mdp + "taxonomy/nodes.dmp", mdp + "taxonomy/names.dmp")


'''
because this is an example, we are going to work with only 10 bacterial genomes
so we are extracting only the top 10 genomes in the metadata file aling with the header line
In real installations we will NOT do this.

head -11 assembly_summary_refseq_bacteria.txt > test.txt
mv test.txt assembly_summary_refseq_bacteria.txt > test.txt

Now assembly_summary_refseq_bacteria.txt will have metadata about 10 assemblies and a header line
'''

'''
Now it is time to download assemblies
The assemblies are downloaded in mdp + refseq_download  i.e /home/mydirectory/projects/data/driver_example/refseq_download
I am using multiprocessing: 4 cores and chunksize of 1


'''

#myfilter.download_refseq_assemblies(mdp + "assembly_summary_refseq_bacteria.txt",mdp + "refseq_download",4,1)

'''
Now we should have 10 assemblies downloaded into mdp+ref_seq
We are going to sanity check to see if required files have been downloaded
This function will print to STDOUT out a line for each assembly which is not downloaded properly
If only a header line is printed we can just continue. If anything else is printed contact Karyosoft help
'''

#myfilter.sanity_check_refseq_downloads(mdp + "assembly_summary_refseq_bacteria.txt",mdp + "refseq_download/")

'''
Now that we know all files are downloaded properly we can go ahead and start processing them
Loci only uses the _genomic.gff.gz and _genomic.fna.gz
For example the gff and fna file for assembly GCF_000003135.1 are  called GCF_000003135.1_ASM313v1_genomic.gff.gz and GCF_000003135.1_ASM313v1_genomic.fna.gz
The following function just renames it to GCF_000003135.1.gff.gz and GCF_000003135.1.fna.gz to make it easy to process
'''

#myfilter.prepare_refseq_assemblies(mdp + "assembly_summary_refseq_bacteria.txt",mdp+"refseq_download/")

'''

Now we have to create a directory under loci to store all these genome data

In real installation:
=====================
create directory structure static/loci_data/genome_data in loci's flaskserver
for example if loci's flaskserver is installed in /mnt/disks/projects/loci/flaskserver
create a directory called /static/loci_data/genome_data in it so we have a directory called "/mnt/disks/locidisk/projects/loci/flaskserver/static/loci_data/genome_data/"

For this toy example:
====================
Because this is a toy example I am just using a toy directory but in real installation this directory
will be under loci

For this example do the following in command line

cd /home/mydirectory/projects/data/driver_example/
mkdir static
cd static
mkdir loci_data
cd loci_data
mkdir genome_data

I am calling this directory ldp
'''

ldp = "/home/mydirectory/projects/data/driver_example/static/loci_data/genome_data/"




'''
Now we will create the loci_input file. This file is a metadata file. It is just a simplified
version of the metadata file that we downloaded from refseq but has additional information.
THis is an important file because this is what will be used downstream.

When we are working with customer installation we have to ask them to provide this file to us if possible
the input file is called ldp + "assembly_summary_refseq_bacteria_input.txt". Open the file to checkout how it looks. It is pretty simple
all assemblies are assigned to NCBI_GENOMES assembly
they are also all made Public. You can edit this file to change these assignments

'''

#myfilter.make_input_file(mdp + "assembly_summary_refseq_bacteria.txt",ldp + "data",ldp + "assembly_summary_refseq_bacteria_input.txt","NCBI_GENOMES","Public")



'''
copy the .original files to ldp+data
all future processing will be done in ldp+data. we will come back to mdp directory for original data if we mess up something
'''

#myfilter.copy_files_to_loci(ldp+"assembly_summary_refseq_bacteria_input.txt",mdp+"refseq_download",ldp+"data")

'''
preprocessing the refseq files.
currently this only unzips the gff file because jbrowse needs unzipped files
other preprocessing steps can be added here in the future

I am using multiprocessing with 2 processes
After running the function checkout a assembly directory ldp/data/GCF... to see how it is unzipped
'''

#genomes.preprocess_refseq_files(ldp+"assembly_summary_refseq_bacteria_input.txt",2)

'''
delete the zipped gff files
'''

#genomes.cleanup_refseq_files(ldp+"assembly_summary_refseq_bacteria_input.txt")


'''
Now we will get the genomes.jsonl that is uploaded into mongo
this is the data used in the genome searches in loci

Note this usese the original assembly report downloaded frm ncbi mdp+ "assembly_summary_refseq.txt"
it also uses the taxonomy information to get lineage information
the assembly is stored in ldp+"genomes.jsonl"
it uses multiprocessing 4 processes
You will see some "not found" messages ... it is normal
after the function runs make sure genomes.jsonl has expected number of lines. 1 per genome (10 lines in this example)
'''
#genomes.get_assembly_metadata(ldp,ldp+"assembly_summary_refseq_bacteria_input.txt",ldp+"genomes.jsonl",mdp+ "assembly_summary_refseq.txt",mdp+"taxonomy/nodes.dmp",mdp+"/taxonomy/names.dmp",4)

'''
Now we will process the genome gff and fasta files to get the following file for each genome
1) .genes.biotype.gz: stores the biotype (e.g. protein coding, rrna) of genes in the genome
2) .genes.desc.gz: description of  genes in the genome
3) .genes.fna.gz: fasta file of all genes in the genome
4) .genes.id.gz: id of all genes in the genome
5) .genes.jsonl.gz: jsonl file of all genes in genome for upload into mongod
6) .new.fna.gz: new fasta file of genome with headers modified so it can be used by loci
7) .proteins.desc.gz: description of proteins
8) .proteins.faa.gz: fasta file of proteins
9) .proteins.id.gz: id of app proteins
10) .proteins.jsonl.gz: jsonl file of all proteins in genome for upload into mongod

These will be stored individually for each genome and merged later

i am using 4 processes
'''

#genomes.process_all_genome_files(ldp+"genomes.jsonl",4)

'''
Now we will merge files we created before for each genome
This creates genes.jsonl.gz and proteins.jsonl.gz: the genes and proteins data files for all genomes
to be uploaded into mongo

This also creates several temporary .tmp files that are used to create search strings
all outputs are stored in ldp directory
'''

#genomes.merge_files_from_genomes(ldp)

'''
Now we have the genomes.jsonl, genes.jsonl, proteins.jsonl
We are going to create the search strings that are used for live search in loci
First we create the genome search strings
The output is in ldp + genomes.ss.uniq.jsonl

the function also creates common.ss.jsonl which are search strings that are common to 
genes genomes and proteins they are added to the protein and gene search strings in the next step
'''

#genomes.create_search_strings(ldp+"genomes.jsonl", ldp)

'''
creating search strings for genes and proteins
this function also deletes the tmp files created before
'''

#genomes.create_gene_protein_search_strings(ldp,"75%",4)

'''
cleanup temp files
renames the .new.fna.gz to .fna.gz
'''

#genomes.cleanup_2(ldp+"genomes.jsonl",ldp)

'''
Now we have the genes,genomes, and proteins jsonl files
and search strings for genes, genomes, and proteins
Time to upload it into mongo. We have to do the following in command line
For this example I am using a mongod instance running on port 1500. I am setting the data
directory for mongod as  /home/mydirectory/projects/data/driver_example/mongodir

cd /home/mydirectory/projects/data/driver_example
mkdir mongodir
mongod --dbpath /home/mydirectory/projects/data/driver_example/mongodir --port 1500

In another window do the following

cd /home/mydirectory/projects/data/driver_example/static/loci_data/genome_data/


mongoimport -d omics  -c genomes  --port 1500 --type json    --numInsertionWorkers 16 --file genomes.jsonl
mongoimport -d omics  -c genome_search_strings  --port 1500 --type json    --numInsertionWorkers 16 --file genomes.ss.uniq.jsonl
zcat genes.jsonl.gz |  mongoimport -d omics  -c genes  --port 1500 --type json  --numInsertionWorkers 16
zcat proteins.jsonl.gz |  mongoimport -d omics  -c proteins  --port 1500 --type json  --numInsertionWorkers 16
mongoimport -d omics  -c gene_search_strings  --port 1500 --type json    --numInsertionWorkers 16 --file genes.ss.uniq.jsonl
mongoimport -d omics  -c protein_search_strings  --port 1500 --type json    --numInsertionWorkers 16 --file proteins.ss.uniq.jsonl

'''

'''
Now that we have uploaded stuff to mongo we can create the needed indexes
i am using 2 processes and chunk size 1
Note: i am using port 1500 in production it will be 1401
'''

#genomes.create_all_indexes("127.0.0.1",1500,2,1)

'''
Now we make the collection called dashboard in mongo that is used in the dashboard/home page
I am using port 1500 in production it will be port 1401
'''
#dashboard.prepare_dashboard("localhost",1500)

'''
Now we are ready to prepare files for jbrowse
Download jbrowse from here and unzip it in flasks static directory
https://jbrowse.org/

jb_bin directory is the bin directory within jbrowse. programs like prepare-refseqs.pl are there
jb_datadir is where the files required for jbrowse are stored.
In this example jb_datadir = "/home/mydirectory/projects/data/driver_example/static/loci_jbrowse_data/"
in production it will be "/mnt/disks/locidisk/projects/loci/flaskserver/static/jbrowse/JBrowse-1.12.1/loci_jbrowse_data/"

I am using multiprocessig with 4 processes

'''
jb_bindir= jb_bindir= "/home/mydirectory/projects/loci/flaskserver/static/jbrowse/JBrowse-1.12.1/bin/"
jb_datadir = "/home/mydirectory/projects/data/driver_example/static/loci_jbrowse_data/"


#jbrowse.prepare_jbrowse_data(jb_bindir,jb_datadir,ldp+"genomes.jsonl",4)

'''
Now we can prepare blast databases.
First download blast into any directory in your computer
wget ftp://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/2.6.0/ncbi-blast-2.6.0+-x64-linux.tar.gz
unzip it
and add the bin within blast to PATH variable in ~/.profile

First we create blast databases for each genome, genes, and proteins fasta file

BLAST_DB_ROOT is where these databases will be stored
in our example BLAST_DB_ROOT = /home/mydirectory/projects/data/driver_example/static/loci_data/blastdbs/

in production
BLAST_DB_ROOT = "/mnt/disks/locidisk/projects/loci/flaskserver/static/loci_data/blastdbs/"

'''
BLAST_DB_ROOT = "/home/mydirectory/projects/data/driver_example/static/loci_data/blastdbs/"

#blast.make_blast_databases(ldp+"genomes.jsonl",BLAST_DB_ROOT,4)

'''
If you look into the BLAST_DB_ROOT directory you will have one directory for each genome
within the genome directory you will see a directory each for gene, protein, and genome blast databases

Now we sanity check to make sure they are created properly
If the following function does not print anything that means all databases have been created properly
'''

#blast.sanity_check_blast_dbs(ldp+"genomes.jsonl",BLAST_DB_ROOT,ldp+"blast_sanity.jsonl")

'''
Its time now to create the preformatted databases like all_genes, all_genomes, all_proteins, etc.
using multiprocessing with 4 processors and chunk size 1

NOTE: this function is throwing errors now because we do not have any private genomes. but this is how we make preformatted databases
Ignore for now.
'''

#blast.make_preformatted_databases(ldp + "data",BLAST_DB_ROOT,4,1,"localhost",1500)


'''
Now we will download and make public NCBI blast databases. I am only doing the NCBI patent database
because it is the smallest. But the procedure is the same for all NCBI databases like nr, nt, etc.

First we download the ncbi patent fasta sequences
'''

ncbi_fasta_url = "https://ftp.ncbi.nlm.nih.gov/blast/db/FASTA/" 
ncbi_nr_url = ncbi_fasta_url + "nr.gz"
ncbi_nt_url = ncbi_fasta_url + "nt.gz"
ncbi_env_nr_url = ncbi_fasta_url + "env_nr.gz"
ncbi_env_nt_url = ncbi_fasta_url + "env_nt.gz"
ncbi_pataa_url =  ncbi_fasta_url + "pataa.gz"
ncbi_patnt_url =  ncbi_fasta_url + "patnt.gz"


#sutils.download_file(ncbi_pataa_url,BLAST_DB_ROOT + "/ncbi_pataa/","pataa.gz")

'''
Next we make the blast database
prot indicates a protein database. we will change it to nucl if it is a nucleotide database
'''

#blast.prepare_public_database("ncbi_pataa",BLAST_DB_ROOT + "/ncbi_pataa/","pataa.gz",BLAST_DB_ROOT + "/ncbi_pataa/",'prot')