import ntpath
import os.path
import os
import time
from pymongo import MongoClient
import re
from bson.json_util import dumps
import script_utils as sutils
from Bio import SeqIO
from multiprocessing import Pool
from subprocess import Popen, PIPE



assembly_str = "assembly_acc"
file_path_str = "file_path"


glob_outroot = ""

#check if all the databases has been made
def sanity_check_blast_dbs(input_file, blast_db_root,out_file):
    
    handle_in = sutils.my_get_handle(input_file,"r")
    handle_out = sutils.my_get_handle(out_file,"w")
    for line in handle_in:
        
        words = eval(line.strip())
        file_path = words[file_path_str]
        ass_acc = words[assembly_str]

        prot_dir = blast_db_root + "/" + ass_acc + "/protein"
        gene_dir =  blast_db_root + "/" + ass_acc+ "/gene"
        genome_dir =  blast_db_root + "/" + ass_acc+ "/genome"

        prot_len =  len([name for name in os.listdir(prot_dir) if os.path.isfile(os.path.join(prot_dir, name))])
        gene_len =  len([name for name in os.listdir(gene_dir) if os.path.isfile(os.path.join(gene_dir, name))])
        genome_len =  len([name for name in os.listdir(genome_dir) if os.path.isfile(os.path.join(genome_dir, name))])

        #if using -hash_index there will be 8 files. if not there will be 6 files
        if prot_len < 8 or gene_len < 8 or genome_len < 8:
            handle_out.write(line)
    
    handle_in.close()
    handle_out.close()
        
        



def make_blast_databases(input_file, out_dir_root, num_processes):

    global glob_outroot
    glob_outroot = out_dir_root

    sutils.create_if_not_exist(out_dir_root)
    handle_in = sutils.my_get_handle(input_file,"r")
    
    mypool = Pool(num_processes)
    mypool.map(make_blast_databases_worker, handle_in)
    mypool.close()
    mypool.join()
    
    handle_in.close()

#makes blast databases for each individual genomes
def make_blast_databases_worker(line):
    
        
        words = eval(line.strip())

        file_path = words[file_path_str]
        ass_acc = words[assembly_str]
        
        my_prot_file = file_path + "/" + ass_acc + ".proteins.faa.gz"
        my_gene_file = file_path + "/" + ass_acc + ".genes.fna.gz"
        my_genome_file = file_path + "/" + ass_acc + ".fna.gz"

        sutils.create_if_not_exist(glob_outroot + "/"  + ass_acc)

        #if the protein file exists
        if os.path.isfile(my_prot_file):
            out_dir = glob_outroot + "/"  + ass_acc + "/protein/"
            makeblastdbcommand = "gunzip -c " + my_prot_file  +  " | makeblastdb  -hash_index -parse_seqids -dbtype  \'prot\'  -in - -out " + ass_acc + " -title " + ass_acc+"_proteins"
            sutils.create_if_not_exist(out_dir)
            os.chdir(out_dir)
            os.system(makeblastdbcommand)
        else:
            print "\n\nLOCI ERROR: can't find " + my_prot_file + "blast database not created"

        #if the gene file exists
        if os.path.isfile(my_gene_file):
            out_dir = glob_outroot + "/"  + ass_acc + "/gene/"
            makeblastdbcommand = "gunzip -c " + my_gene_file  +  " | makeblastdb  -hash_index -parse_seqids -dbtype  \'nucl\'  -in - -out " + ass_acc + " -title " + ass_acc+"_genes"
            sutils.create_if_not_exist(out_dir)
            os.chdir(out_dir)
            os.system(makeblastdbcommand)
        else:
            print "\n\nLOCI ERROR: can't find " + my_gene_file + "blast database not created"

        #if the contig file exists
        if os.path.isfile(my_genome_file):
            out_dir = glob_outroot + "/"  + ass_acc + "/genome/"
            makeblastdbcommand = "gunzip -c " + my_genome_file  +  " | makeblastdb  -hash_index -parse_seqids -dbtype  \'nucl\'  -in - -out " + ass_acc + " -title " + ass_acc+"_genome"
            sutils.create_if_not_exist(out_dir)
            os.chdir(out_dir)
            os.system(makeblastdbcommand)
        else:
            print "\n\nLOCI ERROR: can't find " + my_genome_file + "blast database not created"
                 

	
def path_leaf(path):
    head, tail = ntpath.split(path)
    return tail or ntpath.basename(head)

#makes preformatted databases (e.g. all proteins in public genomes, all proteins in private genomes)
def make_preformatted_databases(input_root,blast_db_root,num_processes,chunksize,mongo_server,mongo_port):
    client = MongoClient(mongo_server,mongo_port)
    
    #this will create the db and collection if it is not already present
    db = client.omics
    collection = db.genomes    
    
    #getting all public and private genomes
    
    pub_regex = re.compile("public", re.IGNORECASE)
    publicResult = list(collection.find({"privacy": pub_regex}, { "assembly_acc":1, "_id":0 } ))
    #the function above returns a list of dictionaries. Converting it to a list of just assembly accessions
    public_genomes = [ f['assembly_acc'] for f in publicResult]

    priv_regex = re.compile("private", re.IGNORECASE)
    privateResult = list(collection.find({"privacy": priv_regex},{ "assembly_acc":1, "_id":0 }))
    #the function above returns a list of dictionaries. Converting it to a list of just assembly accessions
    private_genomes = [ f['assembly_acc'] for f in privateResult]

    #closing the mongodb client
    client.close()
    
    my_list = [
        {'genome_list': public_genomes, 'input_root': input_root, 'blast_db_root':blast_db_root,'out_db_name':"all_public_proteins",'dbof':"protein"},
        {'genome_list': public_genomes, 'input_root':input_root, 'blast_db_root':blast_db_root,'out_db_name':"all_public_genes",'dbof':"gene"},
        {'genome_list': public_genomes, 'input_root':input_root, 'blast_db_root':blast_db_root,'out_db_name':"all_public_genomes",'dbof':"genome"},
        
        {'genome_list': private_genomes, 'input_root':input_root, 'blast_db_root':blast_db_root,'out_db_name':"all_private_proteins",'dbof':"protein"},
        {'genome_list': private_genomes , 'input_root':input_root, 'blast_db_root':blast_db_root,'out_db_name':"all_private_genes",'dbof':"gene"},
        {'genome_list': private_genomes, 'input_root':input_root, 'blast_db_root':blast_db_root,'out_db_name':"all_private_genomes",'dbof':"genome"},
        
        {'genome_list': private_genomes + public_genomes, 'input_root':input_root, 'blast_db_root':blast_db_root,'out_db_name':"all_proteins",'dbof':"protein"},
        {'genome_list': private_genomes + public_genomes, 'input_root':input_root, 'blast_db_root':blast_db_root,'out_db_name':"all_genes",'dbof':"gene"}
    ]
    
    mypool = Pool(num_processes)
    mypool.map(make_preformatted_databases_worker, my_list,chunksize)
    mypool.close()
    mypool.join()

def make_preformatted_databases_worker(item):
    genome_list = item["genome_list"]
    input_root = item["input_root"]
    blast_db_root = item["blast_db_root"]
    out_db_name = item["out_db_name"]
    out_dir = blast_db_root + "/" + out_db_name
    dbof = item["dbof"]

    make_blast_db_from_list(genome_list,input_root,blast_db_root,out_dir,out_db_name,dbof)
   
def make_blast_db_from_list(genome_list,input_root,blast_db_root,out_dir,out_db_name,dbof):

    print "Making: " + out_db_name
    #creating output directory if it does not exist
    sutils.create_if_not_exist(out_dir)

    dblist_file = out_dir + "/" + out_db_name + "_db_list"
    of = open(dblist_file,"w")

    #creating the db list file
    for genome in genome_list:
        genome = genome.strip()

        #if it is  a db of gene and genomes
        if dbof == "gene+genome":
            filename = input_root + "/" + genome + "/" + genome + ".genes.fna.gz" +  "\n" + input_root + "/" + genome + ".fna.gz"
        elif dbof == "gene":
            filename = input_root + "/" + genome + "/" + genome + ".genes.fna.gz"
        elif dbof == "genome":
            filename = input_root + "/" + genome + "/" + genome + ".fna.gz"
        else:
            filename = input_root + "/" + genome + "/" + genome + ".proteins.faa.gz"

        of.write(filename + "\n")
    of.close()

    if(dbof == "protein"):
        dbtype = "prot"
    else:
        dbtype = "nucl"
        
    os.chdir(out_dir)
    mycmd = "cat " + dblist_file + " | xargs gunzip -c | makeblastdb  -hash_index -parse_seqids -in - -out " + out_db_name + " -title " + out_db_name + " -dbtype "   + dbtype
    Popen(mycmd, stdin=PIPE, stdout=PIPE,shell=True).wait()



#NOTE: this function is copied from flaskserver/server. 
# If you are making changes, make sure to change the other copy as well
#make alias db for a list of genome accessions
#dbof is one of protein,gene,genome
def make_alias_db(genome_list,blast_db_root,out_dir,out_db_name,dbof):

    print "Making: " + out_db_name
    
    dblist_file = out_dir + "/" + out_db_name + "_db_list"
    of = open(dblist_file,"w")
    for genome in genome_list:
        genome = genome.strip()

        #if it is  a db of gene and genomes
        if(dbof == "gene+genome"):
            dbname = blast_db_root + "/" + genome + "/" + "gene" + "/" + genome + "\n" + blast_db_root + "/" + genome + "/" + "genome" + "/" + genome
        else:
            dbname = blast_db_root + "/" + genome + "/" + dbof + "/" + genome

        of.write(dbname+ "\n")
    of.close()

    if(dbof is "protein"):
        dbtype = "prot"
    else:
        dbtype = "nucl"
        
    os.chdir(out_dir)
    aliascmd = "blastdb_aliastool -dblist_file " + dblist_file + " -dbtype " + dbtype + " -out " + out_db_name + " -title  " + out_db_name
    os.system(aliascmd)

#adds loci attributes to public database fasta files and stores it in a new file
#the original file can be deleted after calling this function
#blastdbtype can be nucl or prot
def prepare_public_database_fasta(dbname,in_dir,in_file,out_dir,blastdbtype):
    fasta_file = in_dir + "/" + in_file
    out_file = out_dir + "/" + dbname + ".fa.gz"

    if blastdbtype == 'prot':
        loci_attributes = sutils.create_protein_loci_attributes(dbname,"",False)
    else:
        loci_attributes = sutils.create_gene_loci_attributes(dbname,False)


    in_handle = sutils.my_get_handle(fasta_file,"r")
    out_handle = sutils.my_get_handle(out_file,"w")
    
    for line in in_handle:
        #if it is a header line
        if line.startswith(">"):
            line  = line.strip()
            #splitting with Ctrl+A character
            #nr and other databases has several ID and descriptions delimited by ctrl+A
            words = line.split("\x01",1)

            #getting the first description only
            description = words[0] + "\t" + loci_attributes + "\n"

            out_handle.write(description)
        else:
            #if it is not a header line
            out_handle.write(line)


    out_handle.close()
    in_handle.close()

#creates a blast database from a fasta.gz file
def make_blast_database_from_gzfasta(in_dir,in_file,out_dir,dbname,dbtitle,blastdbtype):
    in_fp = in_dir + "/" + in_file
    #if the protein file exists
    if os.path.isfile(in_fp):
        makeblastdbcommand = "gunzip -c " + in_fp  +  " | makeblastdb  -hash_index -parse_seqids -dbtype  \'" + blastdbtype + "\'  -in - -out " + dbname + " -title " + dbtitle
        sutils.create_if_not_exist(out_dir)
        os.chdir(out_dir)
        os.system(makeblastdbcommand)
    else:
        print "\n\nLOCI ERROR: can't find " + in_fp + "blast database not created"

def prepare_public_database(dbname,in_dir,in_file,out_dir,blastdbtype):

    print "preparing fasta file for blast database: " + dbname
    #prepare the fasta file and add loci attributes
    prepare_public_database_fasta(dbname,in_dir,in_file,out_dir,blastdbtype)

    new_fasta = dbname + ".fa.gz"
    print "making blast database: " + dbname
    #make the blast database
    make_blast_database_from_gzfasta(in_dir,new_fasta,out_dir,dbname,dbname,blastdbtype)

def prepare_16s(dbname,in_dir,tar_file_root,out_dir,blastdbtype):

    print "preparing fasta file for blast database: " + dbname

    #unzipping tar file
    tar_command = "tar -xvf " + in_dir + "/" + tar_file_root + ".tar.gz"
    fasta_file = in_dir + "/" +  tar_file_root + ".fa"
    blastdbcmd_command = "blastdbcmd -target_only -entry all -db "  + tar_file_root + " > " + fasta_file  

    os.chdir(in_dir)
    os.system(tar_command)
    os.system(blastdbcmd_command)

    #prepare the fasta file and add loci attributes
    prepare_public_database_fasta(dbname,in_dir,tar_file_root + ".fa",out_dir,blastdbtype)

    new_fasta = dbname + ".fa.gz"
    print "making blast database: " + dbname
    #make the blast database
    make_blast_database_from_gzfasta(in_dir,new_fasta,out_dir,dbname,dbname,blastdbtype)

    #removing original files
    os.system("rm " + tar_file_root + "*")


'''
if __name__ == "__main__":
    #prepare_public_database("ncbi_nr","/home/mydirectory/projects/loci/flaskserver/static/loci_data/blastdbs/ncbi_nr/","nr.fa.gz","/home/mydirectory/projects/loci/flaskserver/static/loci_data/blastdbs/ncbi_nr/",'prot')



    make_blast_databases("~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input.txt",
        "~/projects/loci/flaskserver/static/data/blastdbs")


    make_blast_databases("/home/mydirectory/projects/data/ncbi/top150/top150.jsonl",
    "/home/mydirectory/projects/loci/flaskserver/static/data/blastdbs")

    #make_preformatted_databases()  
'''