#this file was created to select a subset of assemblies from the NCBI genomes database

import random
import os
import os.path
import ntpath

import taxonomy
import script_utils as sutils
from multiprocessing import Pool
from subprocess import Popen, PIPE
from Bio import SeqIO
from Bio.Seq import Seq


assembly_acc_str = "# assembly_accession"
assembly_acc_str1 = "assembly_acc"
assembly_name_str = "asm_name"
taxid_str = "taxid"
ftp_path_str = "ftp_path"
intra_species_str = "infraspecific_name"
fpath_str = "file_path"

#gobal variables to be used in multiprocessing
assind = -1
ftpind = -1
assnameind = -1
ref_dwnld_root = ""
priv_out_root = ""


#gets num_ass assemblies from the ncbi genomes dataset that has refseq annotations
#total_ass is the number of assemblies in the metadata file. Get it using wc
def filter_assemblies(metadata_file,num_ass,total_ass,out_file):

    ones = [1] * num_ass
    zeros = [0] * (total_ass - num_ass)
    rand = ones + zeros 
    random.shuffle(rand)

    of = open(out_file, 'w')

    with open(metadata_file) as fp:
        firstline = fp.readline()
        keys = firstline.strip().split("\t")
		#stripping each element in the list
        keys = map(str.strip,keys)
        of.write("\t".join(keys) + "\n")

        
        i =0
        for line in fp:
            values = line.strip().split("\t")
			#stripping each element
            values = map(str.strip,values)
            if(rand[i] == 1):
                of.write("\t".join(values) + "\n") 
            i = i + 1

    fp.close()
    of.close()
            

def download_refseq_assemblies(input_file,out_root,num_processes,chunksize):
    
    
    global assind
    global ftpind
    global assnameind
    global ref_dwnld_root
    
    ref_dwnld_root = out_root
    sutils.create_if_not_exist(ref_dwnld_root)
    fp = sutils.my_get_handle(input_file,"r")

    firstline = fp.readline()
    keys = firstline.strip().split("\t")
    
    #stripping each element in the list
    keys = map(str.strip,keys)
        
    #indices
    assind = keys.index(assembly_acc_str)
    ftpind = keys.index(ftp_path_str)
    assnameind = keys.index(assembly_name_str)
    
    mypool = Pool(num_processes)
    mypool.map(download_refseq_assemblies_worker, fp,chunksize)
    mypool.close()
    mypool.join()


def download_refseq_assemblies_worker(line):

    values = line.strip().split("\t")
    #stripping each element 
    values = map(str.strip,values)

    ftp_site = values[ftpind]
    ass_acc = values[assind]
    ass_name = values[assnameind]

    out_dir = ref_dwnld_root + "/" + ass_acc + "/"

    file_root = path_leaf(ftp_site)

    gff_file = file_root + "_genomic.gff.gz"
    genome_file = file_root +  "_genomic.fna.gz"


    command = "wget " + ftp_site + "/" + gff_file  + " -P " + out_dir
    os.system(command)

    command1 = "wget " + ftp_site + "/" + genome_file  + " -P " + out_dir
    os.system(command1)


#makes sure we have downloaded all files. Prints the lines of genomes no downloaded properly
def sanity_check_refseq_downloads(input_file,dir_root):
    with open(input_file) as fp:
        firstline = fp.readline()
        firstline = firstline.strip()
        keys = firstline.strip().split("\t")
        #stripping each element in the list
        keys = map(str.strip,keys)
        
        #indices
        assind = keys.index(assembly_acc_str)
        ftpind = keys.index(ftp_path_str)

        #stores the assemblies that were not downloaded properly
        problem_assemblies = {}
        
        for line in fp:
            line = line.strip()
            values = line.strip().split("\t")
            #stripping each element 
            values = map(str.strip,values)

            ftp_site = values[ftpind]
            ass_acc = values[assind]

            file_root = path_leaf(ftp_site)


            my_dir = dir_root + "/" + ass_acc + "/" 
            gff_file = my_dir + file_root + "_genomic.gff.gz"
            genome_file = my_dir + file_root +  "_genomic.fna.gz"
            #protein_file = my_dir + file_root + "_protein.faa.gz"
            #cds_file = my_dir + file_root + "_cds_from_genomic.fna.gz"

            if not os.path.exists(gff_file):
                problem_assemblies[line] = 1
            if not os.path.exists(genome_file):
                problem_assemblies[line] = 1
            '''
            if not os.path.exists(protein_file):
                problem_assemblies[line] = 1
            if not os.path.exists(cds_file):
                problem_assemblies[line] = 1
            '''
        print firstline
        for key in problem_assemblies.keys():
            print key
 
 

#post processess the files downloaded from refseq
#for example, unzipping. If we want to delete unused files, we can do it here
#currently it gives the gff and fna file a new name
def prepare_refseq_assemblies(input_file,dir_root):
    with open(input_file) as fp:
        firstline = fp.readline()
        keys = firstline.strip().split("\t")
        #stripping each element in the list
        keys = map(str.strip,keys)
        
        #indices
        assind = keys.index(assembly_acc_str)
        taxind = keys.index(taxid_str)
        ftpind = keys.index(ftp_path_str)
        assnameind = keys.index(assembly_name_str)
        
        for line in fp:
            values = line.strip().split("\t")
            #stripping each element 
            values = map(str.strip,values)

            ftp_site = values[ftpind]
            ass_acc = values[assind]

            file_root = path_leaf(ftp_site)


            my_dir = dir_root + "/" + ass_acc + "/" 

            gff_file = my_dir + file_root + "_genomic.gff.gz"
            genome_file = my_dir + file_root +  "_genomic.fna.gz"
        
            gff_out_file = my_dir + ass_acc + ".gff.gz"
            genome_out_file = my_dir + ass_acc +  ".fna.gz"
        
            if os.path.exists(gff_file):
                command = "mv " + gff_file + " " + gff_out_file 
                os.system(command)
            else:
                print gff_file + "  not found"
            
            if os.path.exists(genome_file):
                command = "mv " + genome_file + " " + genome_out_file 
                os.system(command)
            else:
                print genome_file + "  not found"


#gets the last item in a path
#https://stackoverflow.com/questions/8384737/extract-file-name-from-path-no-matter-what-the-os-path-format
def path_leaf(path):
    head, tail = ntpath.split(path)
    return tail or ntpath.basename(head)



#gets refseq assemblies belonging to a certain superkingdom, species, etc.
#get the assembly report from here ftp://ftp.ncbi.nlm.nih.gov/genomes/ASSEMBLY_REPORTS/assembly_summary_refseq.txt
#rank_name is something like "superkingdom", if you want to get assemblies belonging to a certain superkingdom
#rank_id is something like "2" if you want to get assemblies belonging to superkingdom "Bacteria"
#node file and names file are the .dmp files from NCBI taxonomy database
def get_refseq_rank (ass_report,out_file,rank_level,rank_id,nodes_file,names_file):
    
    lineage_dict = taxonomy.getLineage(ass_report,nodes_file,names_file)
    
    of = open(out_file, 'w')

    with open(ass_report) as fp:
        #the comment line
        commentline = fp.readline()
        firstline = fp.readline()
        keys = firstline.strip().split("\t")
        
        #stripping each element in the list
        keys = map(str.strip,keys)
        of.write("\t".join(keys) + "\n")
        
        #indices
        assind = keys.index(assembly_acc_str)
        taxind = keys.index(taxid_str)
        ftpind = keys.index(ftp_path_str)

       
        
        for line in fp:
            values = line.strip().split("\t")
            #stripping each element
            values = map(str.strip,values)

            tax_id = values[taxind]

            try:
                rank_info = taxonomy.get_rank_info(lineage_dict,tax_id,rank_level)
            except KeyError:
                #executed when the tax_id is not found
                print tax_id, "  not found. skipping ..."
                continue
            #rank_info can be none if lineage does not contain rank_level
            if rank_info == None:
                print rank_level, "  not found in lineage for tax id ", tax_id
                continue

            #there were some genomes with ftp+path = na
            if values[ftpind] != "na":
                if rank_info['tax_id'] == rank_id:
                    of.write("\t".join(values) + "\n")
    of.close()
    fp.close()

#creates a table with assembly accession, taxid , etc.
def make_input_file(input_file,dir_root,out_file,collection,privacy):
    
    of = open(out_file, 'w')
    with open(input_file) as fp:
        firstline = fp.readline()
        keys = firstline.strip().split("\t")
        #stripping each element in the list
        keys = map(str.strip,keys)
        of.write("\t".join(["assembly_acc","tax_id","intraspecies_name","collection","privacy","file_path"]) + "\n")
        
        #indices
        assind = keys.index(assembly_acc_str)
        taxind = keys.index(taxid_str)
        intraind = keys.index(intra_species_str)
        
        for line in fp:
            values = line.strip().split("\t")
            #stripping each element 
            values = map(str.strip,values)

            intra = values[intraind]
            if intra == "":
                intra = "n/a"
            else:
                words = intra.split("=")
                intra = words[1]
            of.write("\t".join([values[assind],values[taxind],intra,collection,privacy,dir_root + "/" + values[assind] ]) + "\n")

    fp.close()
    of.close()

#copy files into loci (i.e. loci static directory)
#currently copies the genome fasta file and the gff file
def copy_files_to_loci(input_file,input_root,output_root):

    sutils.create_if_not_exist(output_root)

    with open(input_file) as fp:

        firstline = fp.readline()
        keys = firstline.strip().split("\t")
        #stripping each element in the list
        keys = map(str.strip,keys)

        #indices
        assind = keys.index(assembly_acc_str1)
        pathind = keys.index(fpath_str)
        
        for line in fp:
                    
            values = line.strip().split("\t")
            
            ass_acc = values[assind]
            fpath = values[pathind]
            
            input_dir = input_root + "/" + ass_acc + "/"
            output_dir = output_root + "/" + ass_acc + "/"

            mkdir_cmd = "mkdir " + output_dir
            cp_genome_cmd = "cp " + input_dir + ass_acc + ".fna.gz " + output_dir
            cp_gff_cmd = "cp " + input_dir + ass_acc + ".gff.gz " + output_dir

            os.system(mkdir_cmd)
            os.system(cp_genome_cmd)
            os.system(cp_gff_cmd)



#post processess the files downloaded from refseq to make it private genomes
#out_file is the summary file with new genome names "priv_" is added to the original assembly ID
def make_private_assemblies(input_file,out_file,in_root,out_root,num_processes,chunksize):

    make_private_assembly_summary(input_file,out_file)
    make_private_directories(input_file,in_root,out_root)
    make_private_gffs(out_file,out_root,num_processes,chunksize)
    make_private_fastas(out_file,out_root,num_processes,chunksize)
    clean_private_dir(out_root)


def clean_private_dir(dir_root):
    
    os.chdir(dir_root)
    cmd = "find . -name *.tmp.gz -delete"
    Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

def make_private_fastas(in_file,dir_root,num_processes,chunksize):

    global assind
    global priv_out_root

    in_handle = sutils.my_get_handle(in_file,"r")
    firstline = in_handle.readline()
    keys = firstline.strip().split("\t")
    #stripping each element in the list
    keys = map(str.strip,keys)
    #indices
    assind = keys.index(assembly_acc_str)
    priv_out_root = dir_root
        
    
    mypool = Pool(num_processes)
    mypool.map(make_private_fastas_worker, in_handle,chunksize)
    mypool.close()
    mypool.join()

    in_handle.close()

def make_private_fastas_worker(line):

    
    values = line.strip().split("\t")
    #stripping each element 
    values = map(str.strip,values)
    ass_acc = values[assind]

    in_fasta =  priv_out_root + "/" + ass_acc + "/" + "fna.tmp.gz"
    out_fasta = priv_out_root + "/" + ass_acc + "/" + ass_acc + ".original.fna.gz"
    make_private_fasta(in_fasta,out_fasta,"test")

#https://www.biostars.org/p/156428/
def make_private_fasta(in_file,out_file,assembly_acc):
    handle = sutils.my_get_handle(in_file,"r")
    out = sutils.my_get_handle(out_file,"w")
    
    for record in SeqIO.parse(handle, "fasta"):    
        words = record.description.split(None,1)

        new_id = "priv_" + words[0]
        if len(words) > 1:
            record.id = new_id
            record.description = new_id + "\t" + words[1]
        else:
            record.id = new_id
            record.description = ""
        
        
        SeqIO.write(record,out,"fasta")
    out.close()
    handle.close()



def make_private_gffs(in_file,dir_root,num_processes,chunksize):

    global assind
    global priv_out_root

    in_handle = sutils.my_get_handle(in_file,"r")
    firstline = in_handle.readline()
    keys = firstline.strip().split("\t")
    #stripping each element in the list
    keys = map(str.strip,keys)
    #indices
    assind = keys.index(assembly_acc_str)
    priv_out_root = dir_root
        
    
    mypool = Pool(num_processes)
    mypool.map(make_private_gffs_worker, in_handle,chunksize)
    mypool.close()
    mypool.join()

    in_handle.close()

def make_private_gffs_worker(line):

    
    values = line.strip().split("\t")
    #stripping each element 
    values = map(str.strip,values)
    ass_acc = values[assind]

    in_gff =  priv_out_root + "/" + ass_acc + "/" + "gff.tmp.gz"
    out_gff = priv_out_root + "/" + ass_acc + "/" + ass_acc + ".original.gff.gz"
    make_private_gff(in_gff,out_gff)

def make_private_gff(in_file,out_file):
    in_handle = sutils.my_get_handle(in_file,"r")
    out_handle = sutils.my_get_handle(out_file,"w")

    for line in in_handle:
        #if it is not a comments line
        if not line.startswith("#"):
            values = line.split("\t")
            values[0] = "priv_" + values[0]
            out_handle.write("\t".join(values))


    out_handle.close()
    in_handle.close()






def make_private_directories(in_file,in_root,out_root):

    sutils.create_if_not_exist(out_root)
    in_handle = sutils.my_get_handle(in_file,"r")
   
    firstline = in_handle.readline()
    keys = firstline.strip().split("\t")
    keys = map(str.strip,keys)
    assind = keys.index(assembly_acc_str)
    ftpind = keys.index(ftp_path_str)
    
    for line in in_handle:
        values = line.strip().split("\t")
        
        #stripping each element 
        values = map(str.strip,values)
        
        ass_acc = values[assind]
        ftp_site = values[ftpind]
        file_root = path_leaf(ftp_site)
        
        gff_file = in_root + "/" + ass_acc + "/" + file_root + "_genomic.gff.gz"
        genome_file = in_root + "/" + ass_acc +  "/" + file_root + "_genomic.fna.gz"
        
        sutils.create_if_not_exist(out_root + "/" + "priv_" + ass_acc + "/")
        gff_out_file = out_root + "/" + "priv_" + ass_acc + "/" + "gff.tmp.gz"
        genome_out_file = out_root + "/" + "priv_" + ass_acc + "/" + "fna.tmp.gz"

        cmd = "cp " + gff_file + " " + gff_out_file
        Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

        cmd = "cp " + genome_file + " " + genome_out_file
        Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

      
    in_handle.close()



    

def make_private_assembly_summary(input_file,out_file):
    in_handle = sutils.my_get_handle(input_file,"r")
    out_handle = sutils.my_get_handle(out_file,"w")

    firstline = in_handle.readline()
    keys = firstline.strip().split("\t")
    keys = map(str.strip,keys)
    assind = keys.index(assembly_acc_str)
    
    out_handle.write(firstline)
    for line in in_handle:
        values = line.strip().split("\t")
        
        #stripping each element 
        values = map(str.strip,values)
        
        values[assind] =  "priv_" + values[assind]

        out_handle.write("\t".join(values) + "\n")
    
    in_handle.close()
    out_handle.close()





'''
get_refseq_rank("~/projects/data/ncbi/assembly_summary_refseq.txt",
                "~/projects/data/ncbi/assembly_summary_refseq_bacteria.txt",
                "superkingdom",
                "2",
                "~/projects/data/ncbi/taxonomy/nodes.dmp",
                "~/projects/data/ncbi/taxonomy/names.dmp")


filter_assemblies("~/projects/data/ncbi/assembly_summary_refseq_bacteria.txt",
                 1000,
                 85257,
                 "~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset.txt"
                 )

download_refseq_assemblies("/home/mydirectory/projects/data/ncbi/assembly_summary_refseq_bacteria_subset.txt",
                           "/home/mydirectory/projects/data/ncbi/refseq_subset_download"
                          )


sanity_check_refseq_downloads("/home/mydirectory/projects/data/ncbi/assembly_summary_refseq_bacteria_subset.txt",
                          "/home/mydirectory/projects/data/ncbi/refseq_subset_download/"
                         )


#sanity check indicated that some assemblies were not downloaded properly so downloading them again
download_refseq_assemblies("/home/mydirectory/projects/data/ncbi/gen.txt",
                           "/home/mydirectory/projects/data/ncbi/refseq_subset_download"
                          )


prepare_refseq_assemblies("/home/mydirectory/projects/data/ncbi/assembly_summary_refseq_bacteria_subset.txt",
                          "/home/mydirectory/projects/data/ncbi/refseq_subset_download/"
                         )
'''
'''
make_input_file("~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset.txt",
                "~/projects/data/ncbi/refseq_subset_download",
                "~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input.txt"
               )


#downloading all refseq genomes
#in the download assembiles function, replaced /*.* by /*_feature_table.txt.gz to get only the feature table
download_refseq_assemblies("~/projects/data/ncbi/assembly_summary_refseq_bacteria.txt",
                           "~/projects/data/ncbi/refseq_all_download/"
                          )


prepare_refseq_assemblies("~/projects/data/ncbi/assembly_summary_refseq_bacteria.txt",
                          "~/projects/data/ncbi/refseq_all_download/"
                         )


process_fasta("/home/anitanavin/projects/data/privategenomes/priv_genomes/priv_GCF_000008505.1/fna.tmp.gz","/home/anitanavin/projects/data/privategenomes/priv_genomes/priv_GCF_000008505.1/test.tmp.gz","")
'''