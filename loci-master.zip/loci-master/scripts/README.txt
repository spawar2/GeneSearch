driver.py file is the driver for all etl scripts. check it out

Package dependency. This list is incomplete. Started putting it together on 19 April 2018.

Biopython
requests: http://docs.python-requests.org/en/master/