import os
from pymongo import MongoClient
import gzip
import script_utils as sutils
from subprocess import Popen, PIPE
import json


assembly_acc_str = "assembly_acc"
file_path_str =  "file_path"
species_str = "species"
lineage_str = "lineage"
tax_id_str = "tax_id"
privacy_str ="privacy"
collection_str = "collection"

#strings in the feature table file header

feature_str = "# feature"
feat_ass_str = "assembly"
seq_type_str = "seq_type"
genomic_accession_str = "genomic_accession"	
start_str = "start"	
end_str = "end"	
strand_str = "strand"
product_accession_str = "product_accession"	
non_redundant_refseq_str = "non-redundant_refseq"	
name_str = "name"	
symbol_str = "symbol"	
locus_tag_str = "locus_tag"	
feature_interval_length_str = "feature_interval_length"	
product_length_str = "product_length"



#creates jsonl or tsv file from multipe compressed .gz feature table files  for importing into mongo
#out_format is tsv or jsonl
#the input file is a jsonl file with genome information
def prepare_genes(input_file,out_file,out_format):

    #deleting output file if it already exists because this function appends
    if os.path.exists(out_file):
        os.system("rm " + out_file)
    
    #appending to file
    of = open(out_file, 'a')
    
    if out_format == "tsv":
        #printing header
        header = ["assembly_acc",seq_type_str,genomic_accession_str,start_str,end_str,strand_str,product_accession_str,
        "non_redundant_refseq",name_str,symbol_str,locus_tag_str,feature_interval_length_str,product_length_str,species_str,
        tax_id_str,lineage_str,privacy_str,collection_str]
        
        of.write("\t".join(header)+"\n")

    with open(input_file) as fp:
           
        #for printing progress
        numFiles = 0
        
        for line in fp:

            line = line.strip()
            meta_data = eval(line)

            ass_acc = meta_data[assembly_acc_str]
            file_path = meta_data[file_path_str]

            #feature table file
            feat_file = file_path + "/" + ass_acc + ".feature.table.gz"

            if out_format == "jsonl":
                process_feature_table_jsonl(feat_file,of,meta_data)
            
            if out_format == "tsv":
                process_feature_table_tsv(feat_file,of,meta_data)

            numFiles = numFiles +  1
            #print every 1000 files
            if(numFiles % 1000 == 0):
                print str(numFiles) + " files analyzed"
                
    fp.close()
    of.close()

#processes a single feature table and appends the jsonl output in the outuput file 
def process_feature_table_jsonl(in_file,out_file_handle,meta_data):

    with gzip.open(in_file, 'rb') as fp:
        firstline = fp.readline()
        keys = firstline.strip().split("\t")
        #stripping each element in the list
        keys = map(str.strip,keys)

        #indices
        feature_ind = keys.index(feature_str)
        feat_ass_ind = keys.index(feat_ass_str)
        seq_type_ind = keys.index(seq_type_str)
        genomic_accession_ind = keys.index(genomic_accession_str)	
        start_ind = keys.index(start_str)
        end_ind = keys.index(end_str)
        strand_ind = keys.index(strand_str)
        product_accession_ind = keys.index(product_accession_str)	
        non_redundant_refseq_ind = keys.index(non_redundant_refseq_str)	
        name_ind = keys.index(name_str)
        symbol_ind = keys.index(symbol_str)
        locus_tag_ind = keys.index(locus_tag_str)	
        feature_interval_length_ind = keys.index(feature_interval_length_str)
        product_length_ind = keys.index(product_length_str)


        for line in fp:
            values = line.strip(" \n").split("\t")
            
            #stripping each element 
            values = map(str.strip,values)

            my_dict = {}
            #if it is a CDS
            if values[feature_ind] == "CDS":

                my_dict["assembly_acc"] = values[feat_ass_ind]
                my_dict[seq_type_str] =   values[seq_type_ind]
                my_dict[genomic_accession_str] =   values[genomic_accession_ind]
                my_dict[start_str] =   values[start_ind]
                my_dict[end_str] =    values[end_ind]
                my_dict[strand_str] =  values[strand_ind]
                my_dict[product_accession_str] =  values[product_accession_ind]
                my_dict["non_redundant_refseq"] =  values[non_redundant_refseq_ind]
                my_dict[name_str] =   values[name_ind]
                my_dict[symbol_str] =    values[symbol_ind]
                my_dict[locus_tag_str] =   values[locus_tag_ind]
                my_dict[feature_interval_length_str] =   values[feature_interval_length_ind]
                my_dict[product_length_str] =  values[product_length_ind]

                #adding other metadata
                my_dict[species_str] = meta_data[species_str]
                my_dict[tax_id_str] = meta_data[tax_id_str]
                my_dict[lineage_str] = meta_data[lineage_str]
                my_dict[privacy_str] = meta_data[privacy_str]
                my_dict[collection_str] = meta_data[collection_str]
                
                
                out_file_handle.write(str(my_dict) + "\n")


    fp.close()


#processes a single feature table and appends the jsonl output in the outuput file 
#metadata is an object with genome level information (e.g. species) that needs to be stored with genes
def process_feature_table_tsv(in_file,out_file_handle,meta_data):

    with gzip.open(in_file, 'rb') as fp:
        firstline = fp.readline()
        keys = firstline.strip().split("\t")
        #stripping each element in the list
        keys = map(str.strip,keys)

        #indices
        feature_ind = keys.index(feature_str)
        feat_ass_ind = keys.index(feat_ass_str)
        seq_type_ind = keys.index(seq_type_str)
        genomic_accession_ind = keys.index(genomic_accession_str)	
        start_ind = keys.index(start_str)
        end_ind = keys.index(end_str)
        strand_ind = keys.index(strand_str)
        product_accession_ind = keys.index(product_accession_str)	
        non_redundant_refseq_ind = keys.index(non_redundant_refseq_str)	
        name_ind = keys.index(name_str)
        symbol_ind = keys.index(symbol_str)
        locus_tag_ind = keys.index(locus_tag_str)	
        feature_interval_length_ind = keys.index(feature_interval_length_str)
        product_length_ind = keys.index(product_length_str)


        for line in fp:
            values = line.strip(" \n").split("\t")

            #stripping each element 
            values = map(str.strip,values)

            #if it is a CDS
            if values[feature_ind] == "CDS":
                
                line =[]
                line.append(values[feat_ass_ind])
                line.append(values[seq_type_ind])
                line.append(values[genomic_accession_ind])
                line.append(values[start_ind])
                line.append(values[end_ind])
                line.append(values[strand_ind])
                line.append(values[product_accession_ind])
                line.append(values[non_redundant_refseq_ind])
                line.append(values[name_ind])
                line.append(values[symbol_ind])
                line.append(values[locus_tag_ind])
                line.append(values[feature_interval_length_ind])
                line.append(values[product_length_ind])

                #adding other metadata
                line.append(meta_data[species_str])
                line.append(meta_data[tax_id_str])
                line.append(str(meta_data[lineage_str]))
                line.append(meta_data[privacy_str])
                line.append(meta_data[collection_str])
                
                
                out_file_handle.write("\t".join(line) + "\n")


    fp.close()



def importCDS(fileName):

	client = MongoClient("localhost",27018)
	
	#this will create the db and collection if it is not already present	
	db = client.omics
	collection = db.cds
	

	with open(fileName) as fp:

		for line in fp:
			line = line.strip()
			my_data = eval(line)
			ins_id = 	collection.insert_one(my_data).inserted_id
			print(ins_id)

#creates a collection with search strings for proteins, each genus, species, etc.  for use in the app.
def create_protein_search_strings(file_name,out_file,common_file,file_root,num_processors,sort_perc):

    
    of = sutils.my_get_handle(out_file, 'w')
    tmp_file = file_root + "/proteins.tmp"
    tmp = sutils.my_get_handle(tmp_file, 'w')
    
    in_handle = sutils.my_get_handle(file_name,"r")
    

    for line in in_handle:
        
        line = line.strip()
        line = line.replace("'",'"')
        try:
            my_data = json.loads(line)
        except:
            continue
        
        name_doc = {}
        #a document for name of protein
        name_doc["name"] = my_data["description"]
        name_doc["type"] = "description"
        name_doc["tax_id"] = ""
         
        tmp.write(str(name_doc) + "\n")

        prod_doc = {}
        #a document for accession
        prod_doc["name"] = my_data["unique_id"]
        prod_doc["type"] = "unique_id"
        prod_doc["tax_id"] = ""
        of.write(str(prod_doc) + "\n")

    in_handle.close()
    of.close()
    tmp.close()

    #sorting the tmp file
    print "Sorting ..."
    uniq_file = file_root + "/proteins.tmp.uniq"
    sort_args = ["sort","-u","-S",sort_perc,"--parallel",str(num_processors),"-o",uniq_file,tmp_file]
    Popen(sort_args, stdin=PIPE, stdout=PIPE).wait()


    print "Concatenating..."
    #concatenating output file and uniq file
    cmd = "cat " +  uniq_file + "  >> " + out_file
    Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

    #concatenating output file and common file
    cmd = "cat " +  common_file  + "  >> " + out_file
    Popen(cmd, stdin=PIPE, stdout=PIPE,shell=True).wait()

    print "Deleting temp files ..."
    del_args = ["rm",tmp_file,uniq_file]
    Popen(del_args, stdin=PIPE, stdout=PIPE).wait()

    print "Complete ..."



#creates a collection with search strings for proteins, each genus, species, etc.  for use in the app.
def create_gene_search_strings(file_name,out_file):
    
    of = sutils.my_get_handle(out_file, 'w')
    in_handle = sutils.my_get_handle(file_name,"r")
    
    for line in in_handle:
		line = line.strip()
		my_data = eval(line)

		#a document for accession
		acc_doc = {}
		acc_doc["name"] = my_data["assembly_acc"]
		acc_doc["type"] = "assembly_acc"
		acc_doc["tax_id"] = ""
			
		of.write(str(acc_doc) + "\n")

        #a document for name of protein
		name_doc = {}
		name_doc["name"] = my_data["description"]
		name_doc["type"] = "description"
		name_doc["tax_id"] = ""
			
		of.write(str(name_doc) + "\n")

        #a document for accession
		prod_doc = {}
		prod_doc["name"] = my_data["unique_id"]
		prod_doc["type"] = "unique_id"
		prod_doc["tax_id"] = ""
			
		of.write(str(prod_doc) + "\n")

        #a document for biotype
		bio_doc = {}
		bio_doc["name"] = my_data["biotype"]
		bio_doc["type"] = "biotype"
		bio_doc["tax_id"] = ""
			
		of.write(str(bio_doc) + "\n")


		#a document for genome collection
		coll_doc = {}
		coll_doc["name"] = my_data["collection"]
		coll_doc["type"] = "collection"
		coll_doc["tax_id"] = ""

		of.write(str(coll_doc) + "\n")
			
		lineage = my_data["lineage"]
		for item in lineage:
			#dont allow any "no rank" entries
			if item["rank"] != "no rank":
				#renaming "rank" to "type"
				item["type"] = item.pop("rank")
				of.write(str(item) + "\n")

    in_handle.close()
    of.close()
	

'''
prepare_genes("~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input.txt",
"~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input_genes.jsonl")
'''

#importCDS("~/projects/data/ncbi/assembly_summary_refseq_bacteria_subset_gapp_input_genes.jsonl")

'''
prepare_genes("~/projects/data/ncbi/top150/top150.jsonl",
"~/projects/data/ncbi/top150_protiens.tsv","tsv")


#imported tsv into mongodb using command
#mongoimport -d omics  -c proteins  --type tsv --file top150_protiens.tsv  --headerline --ignoreBlanks
#this did not work because mongoimport could not import the lineage field
#see this following link for how to scale
#https://www.khalidalnajjar.com/insert-200-million-rows-into-mongodb-in-minutes/
'''
'''
prepare_genes("~/projects/data/ncbi/top150/top150.jsonl",
"~/projects/data/ncbi/top150_protiens.jsonl","jsonl")

 #mongoimport -d omics  -c proteins  --type json  --file top150_protiens.jsonl --numInsertionWorkers 4
'''

#create_protein_search_strings("~/projects/data/ncbi/top150_protiens.jsonl")

#find refseq_subset_download/ -name "*.proteins.new.jsonl" -exec cat {} \; > top150_proteins.new.jsonl
#find refseq_subset_download/ -name "*.genes.new.jsonl" -exec cat {} \; > top150_genes.new.jsonl
#mongod --dbpath ~/projects/mongodb/data --nojournal
#mongoimport -d omics  -c proteins  --type json  --file top150_proteins.new.jsonl --numInsertionWorkers 4
#mongoimport -d omics  -c genes  --type json  --file top150_genes.new.jsonl --numInsertionWorkers 4

#create_protein_search_strings("~/projects/data/ncbi/top150_proteins.new.jsonl","~/projects/data/ncbi/top150_proteins.new.ss.jsonl")
#create_gene_search_strings("~/projects/data/ncbi/top150_genes.new.jsonl","~/projects/data/ncbi/top150_genes.new.ss.jsonl")
#sort top150_proteins.new.ss.jsonl | uniq >  top150_proteins.new.ss.uniq.jsonl
#sort top150_genes.new.ss.jsonl | uniq >  top150_genes.new.ss.uniq.jsonl
#mongoimport -d omics  -c protein_search_strings  --type json  --file top150_proteins.new.ss.uniq.jsonl --numInsertionWorkers 4

