from pymongo import MongoClient



#used to get top species, collections, etc
num_top = 5

def prepare_dashboard(host,port):

    client = MongoClient(host,port)
    db = client.omics
    
    genomes_collection = db.genomes
    genes_collection = db.genes
    proteins_collection = db.proteins
    dashboard_collection = db.dashboard


    my_document = {}

    my_document["name"] = "my_dashboard"

    print "Preparing dashboard ..."
    my_document["public_genomes_count"] = genomes_collection.find({'privacy':"Public"}).count()
    my_document["private_genomes_count"] = genomes_collection.find({'privacy':"Private"}).count()

    print "Completed 2/16"
    my_document["public_protein_coding_count"] = genes_collection.find({'privacy':"Public",'biotype':'protein_coding'}).count()
    my_document["private_protein_coding_count"] = genes_collection.find({'privacy':"Private",'biotype':'protein_coding'}).count()
    print "Completed 4/16"

    my_document["public_trna_count"] = genes_collection.find({'privacy':"Public",'biotype':'tRNA'}).count()
    my_document["private_trna_count"] = genes_collection.find({'privacy':"Private",'biotype':'tRNA'}).count()
    print "Completed 6/16"

    my_document["public_rrna_count"] = genes_collection.find({'privacy':"Public",'biotype':'rRNA'}).count()
    my_document["private_rrna_count"] = genes_collection.find({'privacy':"Private",'biotype':'rRNA'}).count()
    print "Completed 8/16"

    my_document["public_ncrna_count"] = genes_collection.find({'privacy':"Public",'biotype':'ncRNA'}).count()
    my_document["private_ncrna_count"] = genes_collection.find({'privacy':"Private",'biotype':'ncRNA'}).count()
    print "Completed 10/16"

    my_document["public_protein_count"] = proteins_collection.find({'privacy':"Public"}).count()
    my_document["private_protein_count"] = proteins_collection.find({'privacy':"Private"}).count()
    print "Completed 12/16"

    my_document["top_public_collections"] = list(genomes_collection.aggregate([{"$match":{"privacy":"Public"}},{"$sortByCount": "$collection"},{"$limit":num_top}]))
    my_document["top_private_collections"] = list(genomes_collection.aggregate([{"$match":{"privacy":"Private"}},{"$sortByCount": "$collection"},{"$limit":num_top}]))
    print "Completed 14/16"


    my_document["top_public_species"] = list(genomes_collection.aggregate([{"$match":{"privacy":"Public"}},{"$sortByCount": "$species"},{"$limit":num_top}]))
    my_document["top_private_species"] = list(genomes_collection.aggregate([{"$match":{"privacy":"Private"}},{"$sortByCount": "$species"},{"$limit":num_top}]))
    print "Completed 16/16"


    #updates the same document
    dashboard_collection.replace_one({'name':"my_dashboard"},my_document,upsert=True)

'''
if __name__ == "__main__":
    #prepare_dashboard()
'''