import collections

#a dictionary of preformatted nt databases
#the keys shoud match the name of directories in the blastdbs directory
#tha values are the labels
preformatted_nt = collections.OrderedDict() 
preformatted_nt["all_public_genes"] =  "Genes - All Public Collections"
preformatted_nt["all_private_genes"]  = "Genes - All Private Collections" 
preformatted_nt["all_public_genomes"] =  "Genomes - All Public Collections" 
preformatted_nt["all_private_genomes"] =  "Genomes - All Private Collections"
preformatted_nt["ncbi_nt"]  =  "NCBI nt"
preformatted_nt["ncbi_env_nt"] =  "NCBI env_nt - Nucleotide Sequences from Metagenomes"
preformatted_nt["ncbi_patnt"] =  "NCBI Patent Nucleotide Sequences"
preformatted_nt["ncbi_16smicrobial"] =  "NCBI Bacterial and Archaeal 16S rRNA Sequences"



preformatted_prot = collections.OrderedDict()
preformatted_prot["all_public_proteins"] =  "Proteins - All Public Collections"
preformatted_prot["all_private_proteins"] =  "Proteins - All Private Collections"
preformatted_prot["ncbi_nr"] =  "NCBI nr"
preformatted_prot["ncbi_env_nr"] =  "NCBI env_nr - Protein Sequences from Metagenomes"
preformatted_prot["ncbi_pataa"] =  "NCBI Patent Protein Sequences"


