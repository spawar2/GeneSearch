#this is the main flask server application
from __future__ import division
from flask import Flask, request, send_from_directory, Response, flash, redirect, abort, jsonify
from pymongo import MongoClient
from bson.json_util import dumps
from bson.objectid import ObjectId
from flask_cors import CORS, cross_origin
import re
import os
from subprocess import Popen, PIPE
from uuid import uuid4
import datetime
from pymongo.collection import ReturnDocument
import math
import time
import loci_utils as lutils
import blast_databases

from Bio.Blast import NCBIXML
from flask_celery import make_celery
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from login import User
import json, csv, sys

login_manager = LoginManager()
app = Flask(__name__)
app.secret_key = app.config['SECRET_KEY']

login_manager.init_app(app)

#getting the proper configurations

if 'FLASK_ENV' in os.environ:
    #google compute engine environment. 
    if os.environ['FLASK_ENV'] == "gce":
        app.config.from_object('config_gce')
else:
    #default config is loaded
    app.config.from_object('config')

CORS(app, supports_credentials=True)

#creating a celery object
celery = make_celery(app)


mongo_server = app.config['MY_MONGO_SERVER']
mongo_port = app.config['MY_MONGO_PORT']

#initializng database connection
client = MongoClient(mongo_server, mongo_port,connect=False)
db = client.omics
genomeCollection = db.genomes

search_strings_collection =  db.genome_search_strings
protein_search_strings_collection =  db.protein_search_strings
gene_search_strings_collection =  db.gene_search_strings

proteinCollection = db.proteins
geneCollection = db.genes

dashboardCollection = db.dashboard


celColl = db.celery_tasks_collection
CelCounters = db.celery_counters

users = db.users

@login_manager.user_loader
def load_user(email):  
    user = users.find_one({"email": email})
    if not user:
        return None
    return User(str(user['_id']), user['email'], user['firstName'], user['lastName'])

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        body = request.get_json()
        if body:
            email = body.get("email")
            password = body.get("password")
        else:
            email = ""
            password = ""
        user = users.find_one({"email": email})
        if user and User.validate_login(user['password'], password):
            user_obj = User(str(user['_id']), user['email'], user['firstName'], user['lastName'])
            login_user(user_obj)
            print "Logged in successfully"
            return Response( '{"success": "true" }', status=200, mimetype='application/json')
        print "Wrong email for password"
    return Response('{"success": "false"}', status=401, mimetype='application/json')

@app.route('/change-password', methods = ["POST"])
@login_required
def change_password():  
    if request.method == 'POST':
        data = json.loads(request.data)
        if data:
            email = data["email"]
            password = data["password"]
        user = users.find_one({"email": email})
        if not user:
            print "User not found for password change"
            return Response('{"success": "false"}', status=404, mimetype='application/json')

        print "Updating user password!"
        hash = User.hash_password(password)
        result = db.users.update_one({'_id': user['_id']}, {'$set': {'password': hash}}, upsert=False)
        if result.modified_count == 1:
            return Response('{"success": "true"}', status=201, mimetype='application/json')
    return Response('{"success": "false"}', status=400, mimetype='application/json')

@app.route('/logout')
@login_required
def logout():  
    logout_user()
    print "Logged out!"
    return Response('{"success": "true"}', status=200, mimetype='application/json')

@app.route('/get-user')
@login_required
def get_user():
    user = User.get_name(current_user._get_current_object())
    user["success"] = "true"
    print "getting logged in user info: %s" % json.dumps(user)
    return jsonify(user)

@app.route('/api/v1.0/genomes/getgenomecount/')
@login_required
def get_genome_count():
    return dumps(genomeCollection.find().count())


@app.route('/api/v1.0/help/getadminemail/')
def get_admin_email():
    return dumps(app.config['LOCI_ADMIN_EMAIL'])

@app.route('/api/v1.0/help/downloadmanual/')
def download_manual():
    help_dir = app.config['MY_DATA_ROOT'] + "/help"
    return send_from_directory(directory=help_dir, filename="loci_manual.pdf")

@app.route('/api/v1.0/genes/getgenecount/')
@login_required
def get_gene_count():
    return dumps(geneCollection.find().count())

@app.route('/api/v1.0/proteins/getproteincount/')
@login_required
def get_protein_count():
    return dumps(proteinCollection.find().count())

@app.route('/api/v1.0/genomes/getgenomesubset',methods=['POST'])
def get_the_genomes():
    post_json = request.get_json()
    search_dict = post_json["searchEvent"]
    searchString = search_dict["searchString"]
    skip = int(post_json["skip"])
    limit = int(post_json["limit"])
    search_items = search_dict["searchItems"]
    sortColumn = post_json["sortColumn"]
    sortOrder = post_json["sortOrder"]
    public_collections = search_dict["publicCollections"]
    private_collections = search_dict["privateCollections"]

    # the key names of the result data to be returned to the frontend and displayed in a results table
    return_fields_list = ["assembly_acc","species","intraspecies_name","collection","size","num_genes","num_proteins","gc"]

    # only sort the data if requested, otherwise it's returned as-is ... 
    # so on the initial request, the data will not be sorted ... only when the user
    # clicks on the column headers on the frontend will the data be sorted here, on the backend
    # and returned as freshly sorted data.
    if len(sortColumn) and len(sortOrder):
        # get the data
        result = filter_collection("genome",searchString,-1,-1,search_items,public_collections,private_collections,return_fields_list)
        reverse_sort = True if sortOrder == "desc" else False
        results = list(result["results"])

        # this is where the magic happens - "sorted" sorts the data based on the sortColumn, possibly being reversed.
        # the "lutils.typed_lambda" function will be used to sort the column either as an ints, floats, or strings.
        # see the "typed_lambda" function, and the global list of column types at the top of the "loci_utils" module ...
        # this makes it easy to add or change column types in the future, so sorting will continue to work w/o
        # changes to the routes.
        sorted_data = sorted(results, key=lutils.typed_lambda(sortColumn), reverse=reverse_sort)

        start = (skip * limit)
        end = (skip * limit) + limit
        return_data = {"count": result["count"], "results": sorted_data[start:end]}
        return dumps(return_data)
    else:
        # get the data, and return unsorted - always the initial request
        result = filter_collection("genome", searchString, 
                                    (skip*limit), limit, 
                                    search_items, public_collections, 
                                    private_collections, return_fields_list)
        return dumps(result)

@app.route('/api/v1.0/proteins/getproteinsubset',methods=['POST'])
def get_the_proteins():
    post_json = request.get_json()
    search_dict = post_json["searchEvent"]
    searchString = search_dict["searchString"]
    skip = int(post_json["skip"])
    limit = int(post_json["limit"])
    search_items = search_dict["searchItems"]
    sortColumn = post_json["sortColumn"]
    sortOrder = post_json["sortOrder"]
    public_collections = search_dict["publicCollections"]
    private_collections = search_dict["privateCollections"]

    # the key names of the result data to be returned to the frontend and displayed in a results table
    return_fields_list = ["unique_id","description","species","assembly_acc","collection","length","locus_tag"]

    # only sort the data if requested, otherwise it's returned as-is ... 
    # so on the initial request, the data will not be sorted ... only when the user
    # clicks on the column headers on the frontend will the data be sorted here, on the backend
    # and returned as freshly sorted data.
    if len(sortColumn) and len(sortOrder):
        # get the data
        result = filter_collection("protein",searchString,-1,-1,search_items,public_collections,private_collections,return_fields_list)
        reverse_sort = True if sortOrder == "desc" else False

        # this is where the magic happens - "sorted" sorts the data based on the sortColumn, possibly being reversed.
        # the "lutils.typed_lambda" function will be used to sort the column either as an ints, floats, or strings.
        # see the "typed_lambda" function, and the global list of column types at the top of the "loci_utils" module ...
        # this makes it easy to add or change column types in the future, so sorting will continue to work w/o
        # changes to the routes.
        sorted_data = sorted(result["results"], key=lutils.typed_lambda(sortColumn), reverse=reverse_sort)

        start = (skip * limit)
        end = (skip * limit) + limit
        return_data = {"count": result["count"], "results": sorted_data[start:end]}
        return dumps(return_data)
    else:
        # get the data, and return unsorted - always the initial request
        result = filter_collection("protein", searchString, 
                                    (skip * limit), limit, 
                                    search_items, public_collections,
                                    private_collections, return_fields_list)
        return dumps(result)

@app.route('/api/v1.0/genes/getgenesubset',methods=['POST'])
def get_the_genes():
    post_json = request.get_json()
    search_dict = post_json["searchEvent"]
    searchString = search_dict["searchString"]
    skip = int(post_json["skip"])
    limit = int(post_json["limit"])
    search_items = search_dict["searchItems"]
    sortColumn = post_json["sortColumn"]
    sortOrder = post_json["sortOrder"]
    public_collections = search_dict["publicCollections"]
    private_collections = search_dict["privateCollections"]

    # the key names of the result data to be returned to the frontend and displayed in a results table
    return_fields_list = ["unique_id", "biotype", "description","species","assembly_acc","collection","length","locus_tag"]

    # only sort the data if requested, otherwise it's returned as-is ... 
    # so on the initial request, the data will not be sorted ... only when the user
    # clicks on the column headers on the frontend will the data be sorted here, on the backend
    # and returned as freshly sorted data.
    if len(sortColumn) and len(sortOrder):
        # get the data
        result = filter_collection("gene",searchString,-1,-1,search_items,public_collections,private_collections,return_fields_list)
        reverse_sort = True if sortOrder == "desc" else False

        # this is where the magic happens - "sorted" sorts the data based on the sortColumn, possibly being reversed.
        # the "lutils.typed_lambda" function will be used to sort the column either as an ints, floats, or strings.
        # see the "typed_lambda" function, and the global list of column types at the top of the "loci_utils" module ...
        # this makes it easy to add or change column types in the future, so sorting will continue to work w/o
        # changes to the routes.
        sorted_data = sorted(result["results"], key=lutils.typed_lambda(sortColumn), reverse=reverse_sort)

        start = (skip * limit)
        end = (skip * limit) + limit
        return_data = {"count": result["count"], "results": sorted_data[start:end]}
        return dumps(return_data)
    else:
        result = filter_collection("gene", searchString, 
                                    (skip * limit), limit, 
                                    search_items, public_collections,
                                    private_collections, return_fields_list)
        return dumps(result)


@app.route('/api/v1.0/genomes/gettasksubset')
@login_required
def get_task_subset():
    user_id = User.get_user_id(current_user._get_current_object())
    skip = int(request.args.get('skip'))
    limit = int(request.args.get('limit'))
    sort_order = request.args.get('sortOrder')
    sort_column = request.args.get('sortColumn')
    start = (skip * limit)

    if len(sort_column) and len(sort_order):
        sort_direction = 1 if sort_order == 'asc' else -1
        queryResult = celColl.find({"user_id": user_id},{"task_name": 1, "task_id" : 1, "status" : 1,"task_type": 1,"task_index": 1,"enqueue_date":1}).sort(sort_column,sort_direction)
    else:
        queryResult = celColl.find({"user_id": user_id},{"task_name": 1, "task_id" : 1, "status" : 1,"task_type": 1,"task_index": 1,"enqueue_date":1}).sort("enqueue_date",-1)
    
    #setting date and time so it can be deserialized by javascript
    tasks = list(queryResult.skip(start).limit(limit))
    for task in tasks:
        #2012-11-29 17:00:34 UTC
        task["enqueue_date"] = task["enqueue_date"].strftime("%Y-%m-%d %H:%M:%S UTC")

    result = {"count": queryResult.count(),"tasks": tasks}

    return dumps(result)


#return_fields_list is a list of fields to return e.g. ["name","description"]
#use return_fields_list = None to return all fields
#use skip = -1 and limit = -1 to get all results
#colname is the collection you want to filter: gene, protein
def filter_collection(col_name,searchString,skip,limit,search_items,public_collections,private_collections,return_fields_list):

    if col_name == "gene":
        mongo_collection = geneCollection
        uniq_str = "unique_id"
        max_find_limit = app.config["MAX_FIND_LIMIT_GENES"]
    elif col_name == "protein":
        mongo_collection = proteinCollection
        uniq_str = "unique_id"
        max_find_limit = app.config["MAX_FIND_LIMIT_PROTEINS"]
    elif col_name == "genome":
        mongo_collection = genomeCollection
        uniq_str = "assembly_acc"
        max_find_limit = app.config["MAX_FIND_LIMIT_GENOMES"]
    
    all_collections = public_collections +  private_collections

    #converting the return fields list to dictionary {"name":1,"description":1}
    return_fields_dict = None
    if return_fields_list != None:
        return_fields_dict = {} 
        #converting return fields list to a dict
        for item in return_fields_list:
            return_fields_dict[item] = 1
    
    
    #regx = re.compile(searchString, re.IGNORECASE)



    #followed this: https://stackoverflow.com/questions/5150061/mongodb-multiple-or-operations
    #first query component has the keyword (if any) and the search items
    #second query component will have the collections
    #I will OR within each component and AND between them
    comp1 = []
    
    if searchString != "":
        #search string in the box.
        #comp1.extend([{"species": regx},{"assembly_acc": regx}])
        comp1.extend([{uniq_str : searchString}])
    
    #selected items in the md-chips
    for item in search_items:
        
        #if there is a tax id then the search must be within the lineage array
        if item["tax_id"] != "":
            #comp1.append({"lineage":{"$elemMatch": {"rank": item["type"], "tax_id":item["tax_id"]}}})
            comp1.append({"lineage":{"$elemMatch": {"name":item["name"],"rank": item["type"], "tax_id":item["tax_id"]}}})
        else:
            #the item must contain a accession number or a intra species name
            #see import_genomes.py in the scripts directory
            comp1.append({item["type"]:item["name"]})
    
    #second query component for ORing collections
    comp2 = []
    #selected items in the md-chips
    for collection in all_collections:
        comp2.append({"collection":collection})
    
    #when both the searchstring and the items are not empty
    if len(comp1) > 0 and len(comp2) > 0 :
        #building the query
        # #followed this: https://stackoverflow.com/questions/5150061/mongodb-multiple-or-operations
        query = {"$and": [{"$or" : comp1},{"$or" : comp2}] }
        queryResult = mongo_collection.find(query,return_fields_dict).limit(max_find_limit)
    else:
        queryResult = mongo_collection.find({},return_fields_dict).limit(max_find_limit)

    limited_count = queryResult.count(with_limit_and_skip=True)

    if skip == -1 or limit == -1:
        result = {"count": limited_count, "limit_value": max_find_limit , "results": queryResult}
    else:
        result = {"count": limited_count, "limit_value": max_find_limit , "results": queryResult.skip(skip).limit(limit)}
    return result
 
@app.route('/api/v1.0/genes/sortgenes', methods=["POST"])
def sort_genes():
    
    post_json = request.get_json()
    column_sort = post_json["columnToSort"]
    sort_direction = post_json["sortDirection"]
    search_dict = post_json["searchEvent"]
    searchString = search_dict["searchString"]
    skip = search_dict["skip"]
    limit = search_dict["limit"]
    search_items = search_dict["searchItems"]
    public_collections = search_dict["publicCollections"]
    private_collections = search_dict["privateCollections"]

    return_fields_list = ["unique_id","biotype","description","species","assembly_acc","collection","length"]
    # Change skip and limit to -1
    result = filter_collection("gene",searchString,-1,-1,search_items,public_collections,private_collections,return_fields_list)

    reverse_sort = True if sort_direction == "desc" else False
    sorted_data = sorted(result["results"], key=lambda k: k[column_sort], reverse=reverse_sort)

    end_index = skip + limit
    return_data = {"count": result["count"], "results": sorted_data[skip:end_index]}

    return dumps(return_data)


#used for getting public and private collections
@app.route('/api/v1.0/genomes/getcollections')
@login_required
def get_collections():
    
    pub_regex = re.compile("public", re.IGNORECASE)
    publicResult = genomeCollection.find({"privacy": pub_regex}).distinct("collection")

    priv_regex = re.compile("private", re.IGNORECASE)
    privateResult = genomeCollection.find({"privacy": priv_regex}).distinct("collection")
    
    result ={}

    result["public"] = publicResult
    result["private"] = privateResult

    return dumps(result)


#used for live search of genomes
@app.route('/api/v1.0/genomes/getlivesearchsuggestions')
@login_required
def get_live_search_suggestions():
    searchString = request.args.get('searchString')
    skip = int(request.args.get('skip'))
    limit = int(request.args.get('limit'))

    regx = re.compile(searchString, re.IGNORECASE)
    queryResult = search_strings_collection.find({"name": regx})
    
    result = {"count": queryResult.count(), "entries": queryResult.skip(skip).limit(limit)}
 
    return dumps(result)

#used for live search of proteins
@app.route('/api/v1.0/proteins/getlivesearchsuggestions')
@login_required
def get_protein_live_search_suggestions():
    searchString = request.args.get('searchString')
    skip = int(request.args.get('skip'))
    limit = int(request.args.get('limit'))

    regx = re.compile(searchString, re.IGNORECASE)
    queryResult = protein_search_strings_collection.find({"name": regx})
    
    result = {"count": queryResult.count(), "entries": queryResult.skip(skip).limit(limit)}
 
    return dumps(result)

#used for live search of genes
@app.route('/api/v1.0/genes/getlivesearchsuggestions')
@login_required
def get_gene_live_search_suggestions():
    searchString = request.args.get('searchString')
    skip = int(request.args.get('skip'))
    limit = int(request.args.get('limit'))

    regx = re.compile(searchString, re.IGNORECASE)
    queryResult = gene_search_strings_collection.find({"name": regx})
    
    result = {"count": queryResult.count(), "entries": queryResult.skip(skip).limit(limit)}
 
    return dumps(result)

#used for creating the blast graphical overview
@app.route('/api/v1.0/blast/gethspinfo',methods=['POST'])
@login_required
def get_blast_hsp_info():
    post_json = request.get_json()
    taskid = post_json['taskid']
    query_num = post_json['query_num']

    blast_tasks_root = app.config['BLAST_TASKS_ROOT']
    fileName =  blast_tasks_root + "/" + taskid + "/query_" + str(query_num) + "/hsp_info.txt"
    my_res = []
    with open(fileName) as fp:
        firstline = eval(fp.readline().strip())
        query_len = firstline["queryLen"]
        hit_names = firstline["hit_names"]
        query = firstline["query"]

        for line in fp:
            line = line.strip()
            my_data = eval(line)
            my_res.append(my_data)
    fp.close()
    results = {"query":query, "query_len": query_len, "hit_names": hit_names,"hsp_data":my_res}
    return dumps(results)

#used for creating the blast hits table
@app.route('/api/v1.0/blast/gethitinfo',methods=['POST'])
@login_required
def get_blast_hits_info():
    post_json = request.get_json()
    query_num = post_json['query_num']
    taskid = post_json['taskId']
    sort_column = post_json['sortColumn']
    sort_order = post_json['sortOrder']
    skip = int(post_json['skip'])
    limit = int(post_json['limit'])
    blast_tasks_root = app.config['BLAST_TASKS_ROOT']
    fileName =  blast_tasks_root + "/" + taskid + "/query_" + str(query_num) + "/hits_info.txt"
    my_res = []

    start_index = (skip * limit)
    end_index = (skip * limit) + limit

    with open(fileName) as fp:
        for line in fp:
            line = line.strip()
            my_data = eval(line)
            my_res.append(my_data)
    fp.close()

    if len(sort_order) and len(sort_column):
        reverse_sort = True if sort_order == "desc" else False
        sorted_data = sorted(my_res, key=lutils.typed_lambda(sort_column), reverse=reverse_sort)
        start = (skip * limit)
        end = (skip * limit) + limit
        return_data = {"count": len(sorted_data), "hits_data": sorted_data[start:end]}
        return dumps(return_data)
    else:
        results = {"count":len(my_res), "hits_data":my_res[start_index:end_index]}
        return dumps(results)


#used for creating the blast query names
@app.route('/api/v1.0/blast/getqueriesinfo',methods=['POST'])
@login_required
def get_blast_queries_info():

    post_json = request.get_json()
    taskid = post_json['taskid']
    
    blast_tasks_root = app.config['BLAST_TASKS_ROOT']
    fileName =  blast_tasks_root + "/" + taskid + "/queries.txt"
    my_res = []
    with open(fileName) as fp:
        for line in fp:
            line = line.strip()
            my_res.append(line)
    fp.close()
    results = {"queries_data":my_res}
    return dumps(results)


#used for getting blast html results 
@app.route('/api/v1.0/blast/getblasthmtl',methods=['POST'])
@login_required
def get_blast_out_html():

    post_json = request.get_json()
    taskid = post_json['taskid']
    query_num = post_json['query_num']

    blast_tasks_root = app.config['BLAST_TASKS_ROOT']
    fileName =  blast_tasks_root + "/" + taskid + "/query_" + str(query_num) +  "/blast.out.modified.html"
    my_data = ""
    with open(fileName) as fp:
        for line in fp:
            my_data = my_data + line
    fp.close()
    results = {"html_results":my_data}
    return dumps(results)

@app.route('/api/v1.0/blast/runblast',methods=['POST'])
@login_required
def run_blast():
    blast_job = request.get_json()

    #this is just an auto incrementing counter to name the task if the user doesn't give a name
    task_index = get_next_index("tasks_collection")
    if(blast_job['task_name'] == ''):
        blast_job['task_name']= "Task_" + task_index

    #creating  a task in the database
    task_id = uuid4().hex
    user_id = User.get_user_id(current_user._get_current_object())
    celColl.insert_one({"user_id" : user_id ,"task_id": task_id,"task_index": task_index,"task_name": blast_job['task_name'],"task_type" : blast_job['program'],"enqueue_date": datetime.datetime.utcnow(),"status":"Pending"})


    blast_task.delay(task_id,blast_job)
    return dumps(task_index)

#gets the list of preformatted blast database
@app.route('/api/v1.0/blast/getblastdatabases')
@login_required
def get_blast_databases():
    
    nt_dbs = []
    nt_labels = []
    prot_dbs = []
    prot_labels = []

    for key, value in blast_databases.preformatted_nt.iteritems():
        nt_dbs.append(key)
        nt_labels.append(value)
    
    for key, value in blast_databases.preformatted_prot.iteritems():
        prot_dbs.append(key)
        prot_labels.append(value)

    result_dict = {
        "nt_dbs": nt_dbs,
        "nt_labels":nt_labels,
        "prot_dbs":prot_dbs,
        "prot_labels":prot_labels

    }
    return dumps(result_dict)




#Auto incrementing counter
#used to get the task number
def get_next_index(collection_name):
    next_index = str(CelCounters.find_one_and_update(
        filter={ 'collection_name' : collection_name },
        update={'$inc': {'index': 1}},upsert=True,return_document=ReturnDocument.AFTER).get('index'))
    return next_index

@app.route('/api/v1.0/dashboard/getdashboarddata')
@login_required
def get_dashboard_data():
    #get the only document
    queryResult = dashboardCollection.find_one()
    return dumps(queryResult)



#download single fasta sequence
#this assumes that the seqDB is of name_type "blastdb". Please see lutils.get_blast_db_full_path for what name_type means
@app.route('/api/v1.0/download/downloadsinglesequence',methods=['POST'])
@login_required
def download_single_seq_fasta():
    
    post_json = request.get_json()
    seq_db = post_json["seqDB"]
    seq_id = post_json["seqID"]

    #output file name
    file_name = seq_db + seq_id + ".fa"
    outfile_full_path = app.config['LOCI_DOWNLOAD_ROOT'] + "/" + file_name

    #handling sequence download from individual databases in Loci
    #setting the blast db full path
    blast_db_fullpath = lutils.get_blast_db_full_path(seq_db,app.config['BLAST_DB_ROOT'],"blastdb")

    #this is common for external and internal databases. only the blast_db_fullpath changes
    lutils.run_blast_db_cmd(app.config["BLAST_BIN"],seq_id,blast_db_fullpath,outfile_full_path)

    return send_from_directory(directory=app.config['LOCI_DOWNLOAD_ROOT'], filename= file_name)



#streams a fasta file to the client
#TODO: need to see if this is better done  by a web server like nginx
@app.route('/api/v1.0/download/downloadgenomefasta')
@login_required
def downloadgenomefasta():
    assembly_acc = request.args.get('assembly')
    file_name = app.config['GENOME_DATA_ROOT'] + "/" + assembly_acc + "/" + assembly_acc + ".fna.gz"
    def generate():
        f = lutils.my_get_handle(file_name,"r")
        for line in f:
            yield line
        f.close()
    return Response(generate(),mimetype="text/plain",headers={"Content-Disposition": "attachment;filename=sequences.txt"})


#starts creating a fasta file for download and sends a task id as output
#NOTE: this sends an error message if the numer of sequences requested for creation is greater than max allowable
@app.route('/api/v1.0/download/creategenefastafilefordownload',methods=['POST'])
@login_required
def create_gene_fasta_file_for_download():
    
    #TODO: may be the querying needs to be done in celery as well. We can just create a task id here
    post_json = request.get_json()
    searchString = post_json["searchString"]
    search_items = post_json["searchItems"]
    public_collections = post_json["publicCollections"]
    private_collections = post_json["privateCollections"]
    

    return_fields_list = ["unique_id","assembly_acc"]
    #setting skip and limit to -1 so it returns all documents
    my_result = filter_collection("gene",searchString,-1,-1,search_items,public_collections,private_collections,return_fields_list)
    my_count = my_result["count"]

    my_response = {}

    #if the count is greater than maximum allowable. send error message
    if my_count > app.config["MAX_GENE_DOWNLOAD_COUNT"]:
            my_response["file_name"] = ""
            error_message = "Can not download more than " +  str(app.config["MAX_GENE_DOWNLOAD_COUNT"])  + " sequences using Loci. "
            error_message = error_message + "Please try changing your query or contact admin"
            my_response["error_message"] = error_message

    else:
        result = list(my_result["results"])
        print result
        task_id = uuid4().hex
        create_fasta_file_for_download_task.delay(result,"unique_id","assembly_acc","gene",task_id)
        my_response["file_name"] = "download." +  task_id + ".tmp"
        my_response["error_message"] = ""
    
    return dumps(my_response)

#creates a  CSV file for download (fires off a celery task) for a given download type (gene, genome, protein) and sends a task id as output
#NOTE: this sends an error message if the numer of sequences requested for creation is greater than max allowable
@app.route('/api/v1.0/download/createCSVfilefordownload',methods=['POST'])
@login_required
def create_csv_file_for_download():
    #TODO: may be the querying needs to be done in celery as well. We can just create a task id here
    post_json = request.get_json()
    searchString = post_json["searchString"]
    search_items = post_json["searchItems"]
    public_collections = post_json["publicCollections"]
    private_collections = post_json["privateCollections"]
    download_type = post_json["downloadType"]

    # if there is a list of elected items from the frontend
    # that means only those items are to be included in the 
    # CSV download file
    # otherwise, the selected items is empty
    # meaning ALL items are to be downloaded
    if "selectedItems" in post_json:
        # print "selected items found!!!"
        # only selected items are to be included in CSV file
        selected_items = post_json["selectedItems"]
        # print "The selected items are: %s" % selected_items
    else:
        # all items from query are included
        selected_items = []

    # set the keys to be returned from filter_collection
    # set the CSV column header names
    # set the max number of items to be downloaded w/o error
    if download_type == "gene":
        return_fields_list = ['unique_id', 'biotype', 'description', 'species', 'assembly_acc', 'collection', 'length']    
        CSV_header_names = ['ID', 'Type', 'Description', 'Species', 'Assembly', 'Collection', 'Length (bps)']
        max_download_count = app.config["MAX_GENE_DOWNLOAD_COUNT_CSV"]
        unique_identifier = 'unique_id'
    elif download_type == "genome":
        return_fields_list = ['assembly_acc', 'species', 'intraspecies_name', 'collection', 'size', 'num_genes', 'num_proteins', 'gc']    
        CSV_header_names = ['Assembly', 'Species', 'Intraspecies Name', 'Collection', 'Size(Mb)', 'Num. Genes', 'Num. Proteins', 'GC Content(%)']
        max_download_count = app.config["MAX_GENOME_DOWNLOAD_COUNT_CSV"]
        unique_identifier = 'assembly_acc'
    elif download_type == "protein":
        return_fields_list = ['unique_id', 'description', 'species', 'assembly_acc', 'collection', 'length']   
        CSV_header_names = ['ID', 'Description', 'Species', 'Assembly', 'Collection', 'Length (AAs)']
        max_download_count = app.config["MAX_PROTEIN_DOWNLOAD_COUNT_CSV"]
        unique_identifier = 'unique_id'
    else:
        # if there is no download_type, then something is very wrong
        abort(500)

    # setting skip and limit to -1 so it returns all documents
    my_result = filter_collection(download_type,searchString,-1,-1,search_items,public_collections,private_collections,return_fields_list)
    my_count = my_result["count"]

    my_response = {}

    #if the count is greater than maximum allowable. send error message
    if my_count > max_download_count:
            my_response["file_name"] = ""
            error_message = "Can not download more than " +  str(max_download_count)  + " sequences using Loci. "
            error_message = error_message + "Please try changing your query or contact admin"
            my_response["error_message"] = error_message

    else:
        result = list(my_result["results"])
        # if there are selected items, only allow those items in the CSV download file
        if selected_items:
            result = [item for item in result if item[unique_identifier] in selected_items]
        print result
        task_id = uuid4().hex
        # celery task to create CSV file for download
        create_csv_file_for_download_task.delay(result, task_id, return_fields_list, CSV_header_names)
        my_response["file_name"] = "download." +  task_id + ".tmp"
        my_response["error_message"] = ""
    
    return dumps(my_response)


#starts creating a fasta file for download and sends a task id as output
#NOTE: this sends an error message if the numer of sequences requested for creation is greater than max allowable
#TODO: this can be recactored so there is only one function for genes and proteins
@app.route('/api/v1.0/download/createproteinfastafilefordownload',methods=['POST'])
@login_required
def create_protein_fasta_file_for_download():
    
    #TODO: may be the querying needs to be done in celery as well. We can just create a task id here
    post_json = request.get_json()
    searchString = post_json["searchString"]
    search_items = post_json["searchItems"]
    public_collections = post_json["publicCollections"]
    private_collections = post_json["privateCollections"]
    

    return_fields_list = ["unique_id","assembly_acc"]
    #setting skip and limit to -1 so it returns all documents
    my_result = filter_collection("protein",searchString,-1,-1,search_items,public_collections,private_collections,return_fields_list)
    my_count = my_result["count"]

    my_response = {}

    #if the count is greater than maximum allowable. send error message
    if my_count > app.config["MAX_PROTEIN_DOWNLOAD_COUNT"]:
            my_response["file_name"] = ""
            error_message = "Can not download more than " +  str(app.config["MAX_PROTEIN_DOWNLOAD_COUNT"])  + " sequences using Loci. "
            error_message = error_message + "Please try changing your query or contact admin"
            my_response["error_message"] = error_message

    else:
        result = list(my_result["results"])
        task_id = uuid4().hex
        create_fasta_file_for_download_task.delay(result,"unique_id","assembly_acc","protein",task_id)
        my_response["file_name"] = "download." +  task_id + ".tmp"
        my_response["error_message"] = ""
    
    return dumps(my_response)

#starts creating a fasta file for download and sends a task id as output
#NOTE: this sends an error message if the numer of sequences requested for creation is greater than max allowable
#TODO: this can be recactored so there is only one function for genes and proteins
@app.route('/api/v1.0/download/createselectedproteinfasta',methods=['POST'])
@login_required
def create_selected_protein_fasta():
    
    protein_array = request.get_json()

    my_count = len(protein_array)
    my_response = {}

    #if the count is greater than maximum allowable. send error message
    if my_count > app.config["MAX_PROTEIN_DOWNLOAD_COUNT"]:
            my_response["file_name"] = ""
            error_message = "Can not download more than " +  str(app.config["MAX_PROTEIN_DOWNLOAD_COUNT"])  + " sequences using Loci. "
            error_message = error_message + "Please try changing your query or contact admin"
            my_response["error_message"] = error_message

    else:
        task_id = uuid4().hex
        create_fasta_file_for_download_task.delay(protein_array,"unique_id","assembly_acc","protein",task_id)
        my_response["file_name"] = "download." +  task_id + ".tmp"
        my_response["error_message"] = ""
    
    return dumps(my_response)


#starts creating a fasta file for download and sends a task id as output
#NOTE: this sends an error message if the numer of sequences requested for creation is greater than max allowable
#TODO: this can be recactored so there is only one function for genes and proteins
@app.route('/api/v1.0/download/createselectedgenefasta',methods=['POST'])
@login_required
def create_selected_gene_fasta():
    
    gene_array = request.get_json()


    my_count = len(gene_array)
    my_response = {}

    #if the count is greater than maximum allowable. send error message
    if my_count > app.config["MAX_GENE_DOWNLOAD_COUNT"]:
            my_response["file_name"] = ""
            error_message = "Can not download more than " +  str(app.config["MAX_GENE_DOWNLOAD_COUNT"])  + " sequences using Loci. "
            error_message = error_message + "Please try changing your query or contact admin"
            my_response["error_message"] = error_message

    else:
        task_id = uuid4().hex
        create_fasta_file_for_download_task.delay(gene_array,"unique_id","assembly_acc","gene",task_id)
        my_response["file_name"] = "download." +  task_id + ".tmp"
        my_response["error_message"] = ""
    
    return dumps(my_response)


#assumes the file is in the LOCI_DOWNLOAD_ROOT directory
#it tries for 15 seconds and if the file is not created in 15 seconds it stops
#downloads a file as it is being created
@app.route('/api/v1.0/download/downloadfilestream')
@login_required
def download_file_stream():
    file_name = app.config["LOCI_DOWNLOAD_ROOT"] + "/" + request.args.get('filename')
    out_name = request.args.get('outname')
    
    def generate():
        tries = 0
        #tries once every second
        while tries <= 15:
            print tries
            #if the file exists
            if os.path.isfile(file_name): 
                print "file found"
                f = lutils.my_get_handle(file_name,"r")
                while True:
                    line = f.readline()
                    if line == "//LOCI_EOF\n":
                        download_complete = True
                        return
                    else:
                        yield line
                f.close()
            else:
                #sleep for one second
                time.sleep(1)
                tries = tries + 1
    return Response(generate(),mimetype="text/plain",headers={"Content-Disposition": "attachment;filename=" + out_name})

@app.route('/api/v1.0/download/maxdownloadcounts')
@login_required
def get_max_download_counts():
    result = {}
    #number of genes that can be downloaded in fasta format
    result["max_gene_download_count"] = app.config["MAX_GENE_DOWNLOAD_COUNT"]
    #number of genomes that can be downloaded in fasta format
    result["max_genome_download_count"] = app.config["MAX_GENOME_DOWNLOAD_COUNT"]
    #number of genes that can be downloaded in fasta format
    result["max_protein_download_count"] = app.config["MAX_PROTEIN_DOWNLOAD_COUNT"]
    #number of blast hits that can be downloaded in fasta format
    result["max_hit_download_count"] = app.config["MAX_HIT_DOWNLOAD_COUNT"]

    #number of genes that can be downloaded in csv format
    result["max_gene_download_count_csv"] = app.config["MAX_GENE_DOWNLOAD_COUNT_CSV"]
    #number of genomes that can be downloaded in csv format
    result["max_genome_download_count_csv"] = app.config["MAX_GENOME_DOWNLOAD_COUNT_CSV"]
    #number of genes that can be downloaded in csv format
    result["max_protein_download_count_csv"] = app.config["MAX_PROTEIN_DOWNLOAD_COUNT_CSV"]
    #number of blast hits that can be downloaded in csv format
    result["max_hit_download_count_csv"] = app.config["MAX_HIT_DOWNLOAD_COUNT_CSV"]
    
    return dumps(result)

@app.route('/api/v1.0/blast/maxquerycount')
@login_required
def get_max_query_count():
    result = {}
    #number of queries that can be used to blast
    result["max_query_count"] = app.config["MAX_BLAST_QUERIES"]

    return dumps(result)

#starts creating a fasta file of blast hits for download and sends a task id as output
#NOTE: this sends an error message if the numer of sequences requested for creation is greater than max allowable
@app.route('/api/v1.0/download/createblasthitfasta')
@login_required
def create_blast_hit_fasta():
    task_id = request.args.get('taskid')
    query_num = request.args.get('querynum')
    blast_tasks_root = app.config['BLAST_TASKS_ROOT']
    file_name =  blast_tasks_root + "/" + task_id + "/query_" + query_num + "/hits_info.txt"

    hit_generator = lutils.jsonl_dict_generator(file_name)
    count = 0
    #this is a list of dicttionaries which contains the id, dbname and nametype
    seq_list = []
    #getting the total count, sequence ids and database names from the generator
    for item in hit_generator:
        count = count + 1
        seq_dict = {}
        seq_dict["seq_id"] = item["id"]
        seq_dict["dbname"] = item["locidb"]
        seq_dict["nametype"] = "blastdb"
        seq_list.append(seq_dict)

    my_response = {}

    #if the count is greater than maximum allowable. send error message
    if count > app.config["MAX_HIT_DOWNLOAD_COUNT"]:
            my_response["file_name"] = ""
            error_message = "Can not download more than " +  str(app.config["MAX_HIT_DOWNLOAD_COUNT"])  + " sequences using Loci. "
            error_message = error_message + "Please contact admin for more help"
            my_response["error_message"] = error_message
    else:    
        task_id = uuid4().hex
        create_fasta_file_for_download_task.delay(seq_list,"seq_id","dbname","blastdb",task_id)
        my_response["file_name"] = "download." +  task_id + ".tmp"
        my_response["error_message"] = ""
    

    return dumps(my_response)


#starts creating a fasta file for download and sends a task id as output
#NOTE: this sends an error message if the numer of sequences requested for creation is greater than max allowable
@app.route('/api/v1.0/download/createselectedhitfasta',methods=['POST'])
@login_required
def create_selected_hit_fasta():
    
    hit_array = request.get_json()

    my_count = len(hit_array)
    my_response = {}

    #if the count is greater than maximum allowable. send error message
    if my_count > app.config["MAX_HIT_DOWNLOAD_COUNT"]:
            my_response["file_name"] = ""
            error_message = "Can not download more than " +  str(app.config["MAX_HIT_DOWNLOAD_COUNT"])  + " sequences using Loci. "
            error_message = error_message + "Please contact admin for more help"
            my_response["error_message"] = error_message
    
    else:
        task_id = uuid4().hex
        create_fasta_file_for_download_task.delay(hit_array,"unique_id","locidb","blastdb",task_id)
        my_response["file_name"] = "download." +  task_id + ".tmp"
        my_response["error_message"] = ""
    
    return dumps(my_response)



#starts creating a CSV file of blast hits for download and sends a task id as output
#NOTE: this sends an error message if the numer of sequences requested for creation is greater than max allowable
@app.route('/api/v1.0/download/createblasthitCSVfilefordownload')
@login_required
def create_blast_hit_csv():
    task_id = request.args.get('taskid')
    query_num = request.args.get('querynum')
    blast_tasks_root = app.config['BLAST_TASKS_ROOT']
    file_name =  blast_tasks_root + "/" + task_id + "/query_" + query_num + "/hits_info.txt"


    # if there is a list of elected items from the frontend
    # url as a parameter, that means only those items are to be included in the 
    # CSV download file
    # otherwise, the selected items is empty
    # meaning ALL items are to be downloaded
    if "selectedItems" in request.args and request.args.get('selectedItems') != '':
        print "selected items found!!!"
        # only selected items are to be included in CSV file
        selected_items = [item.strip() for item in request.args.get('selectedItems').split(",")]
        print "The selected items are: %s" % selected_items
    else:
        # all items from query are included
        selected_items = []

    seq_list = []
    count = 0
    with open(file_name) as fp:
        for line in fp:
            line = line.strip()
            line_data = eval(line)
            seq_list.append(line_data)
    fp.close()

    return_fields_list = ['id', 'desc', 'max_score', 'evalue', 'query_coverage', 'percent_id']
    
    # the header in the csv file had different column names than the key names of each gene dict
    CSV_header_names = ['Sequence ID', 'Description', 'Max Score', 'E-value', 'Query Coverage', '% Identity']
    

    my_response = {}

    #if the count is greater than maximum allowable. send error message
    if count > app.config["MAX_HIT_DOWNLOAD_COUNT"]:
            my_response["file_name"] = ""
            error_message = "Can not download more than " +  str(app.config["MAX_HIT_DOWNLOAD_COUNT"])  + " sequences using Loci. "
            error_message = error_message + "Please contact admin for more help"
            my_response["error_message"] = error_message
    else:    
        task_id = uuid4().hex
        # if there are selected items, only allow those items in the CSV download file
        if selected_items:
            seq_list = [item for item in seq_list if item['id'] in selected_items]
        # celery task to create to create CSV file
        create_csv_file_for_download_task.delay(seq_list, task_id, return_fields_list, CSV_header_names)
        my_response["file_name"] = "download." +  task_id + ".tmp"
        my_response["error_message"] = ""
    

    return dumps(my_response)

#return json summary data about a specific gene, genome, or protein
#formatted according to its type by the format files in the summary_format/ dir
@app.route('/api/v1.0/summary')
@login_required
def lookup_format_and_return_summary_data():
    type = request.args.get('type')
    id = request.args.get('id')
    #set the correct omics collection according to its type
    if type == "genes":
        collection = geneCollection
        lookup_field = "unique_id"
    elif type == "genomes":
        collection = genomeCollection
        lookup_field = "assembly_acc"
    elif type == "proteins":
        collection = proteinCollection
        lookup_field = "unique_id"
    else:
        collection = []
        lookup_field = "unique_id"
    
    try: 
        data = collection.find_one({lookup_field: id})
        if data:
            #if the item is found, format its data and return it as json
            return jsonify(lutils.format_fields_and_sections(type, data))
    except:
        print "The db lookup and/or formating threw an exception!"

    return jsonify({"error": {"id": id, "type": type}})
    
############################################################33
####everything under this is used in celery tasks

#seq_list is a list of dictionaries. each dict should contain the seq_id and the db_name
#id_var is the variable within one of the dictionaries which represents the sequence id
#db var is the same thing for the db name
#name type is used to get the full path of the blast db
#task name is used to create a unique download file
@celery.task(name='create_fasta_file_for_download_task')
def create_fasta_file_for_download_task(seq_list,id_var,db_var,name_type,task_name):
    print len(seq_list)
    file_name = app.config['LOCI_DOWNLOAD_ROOT'] + "/" + "download." +  task_name + ".tmp"
    out_handle = lutils.my_get_handle(file_name,"a")
    for item in seq_list:
        my_id = item[id_var]
        my_db = item[db_var]
        blast_db_fullpath = lutils.get_blast_db_full_path(my_db,app.config["BLAST_DB_ROOT"],name_type)
        lutils.run_blast_db_cmd_append(app.config['BLAST_BIN'],my_id,blast_db_fullpath,out_handle)
    #this is the EOF marker used by the streamer to stop generating lines
    out_handle.write("//LOCI_EOF\n")
    out_handle.close()

@celery.task(name='create_csv_file_for_download_task')
def create_csv_file_for_download_task(seq_list, task_name, fieldnames, header_names):
    file_name = app.config['LOCI_DOWNLOAD_ROOT'] + "/" + "download." +  task_name + ".tmp"
    out_handle = lutils.my_get_handle(file_name,"a")

    file_header = csv.writer(out_handle)
    file_header.writerow(header_names)

    w = csv.DictWriter(out_handle, fieldnames=fieldnames, restval='', extrasaction='ignore')
    w.writerows(seq_list)

    #this is the EOF marker used by the streamer to stop generating lines
    out_handle.write("//LOCI_EOF\n")
    out_handle.close()

@celery.task(name='blast_task')
def blast_task(task_id,blast_job):

    #updating the task collection with the deque time
    celColl.update_one({"task_id":task_id},{"$set": {"start_date": datetime.datetime.utcnow(), "status":"Running"}},upsert=False)


    blast_bin = app.config["BLAST_BIN"]
    blast_db_root = app.config['BLAST_DB_ROOT']
    blast_num_threads = app.config['BLAST_NUM_THREADS']

    blast_program = blast_job['program']
    blast_program_fullpath = blast_bin + "/" + blast_job['program']
    blast_formatter_fullpath = blast_bin + "/" + "blast_formatter"
    blastdbcmd_fullpath = blast_bin + "/" + "blastdbcmd"


    blast_tasks_root = app.config['BLAST_TASKS_ROOT']
    blast_task_dir =  blast_tasks_root + "/" + task_id
    #creating the output directory if it does not exist
    if not os.path.exists(blast_task_dir):
        os.makedirs(blast_task_dir)

    os.chdir(blast_task_dir)

    #the input can be a sequence, sequence ID
    input_type = blast_job['inputType']

    #if the input type is a sequence
    if(input_type == 'seq'):
        #writing the input file
        with open("blast.in", 'wb') as query_f:
            query_f.write(blast_job['input'])
    elif input_type == "seq_id":
        assembly_acc = blast_job["assembly_acc"]
        #protein or gene
        seq_type = blast_job["seq_type"]
        my_input = blast_job["input"]

        #getting only the sequence ID
        my_input = my_input.replace("QUERY=","")


        if assembly_acc != "":
            #db to retrieve sequence
            blastdbcmd_db = blast_db_root + "/" + assembly_acc + "/" + seq_type + "/" + assembly_acc
        elif blast_program == "blastp" or blast_program == "tblastn":
            #the query must be protein
            blastdbcmd_db = blast_db_root + "/all_proteins/all_proteins"
        elif blast_program == "blastn" or blast_program == "blastx":
            #the query must be nucleotide
            blastdbcmd_db = blast_db_root + "/all_genes/all_genes"


        #retrieving the input sequence
        blastdbcmd_args_list = [blastdbcmd_fullpath, "-out","blast.in","-db",blastdbcmd_db,"-entry",my_input]

        #rumnning the command
        Popen(blastdbcmd_args_list, stdin=PIPE, stdout=PIPE).wait()
    
    

    
    blast_db_type = blast_job['blast_db_type'].strip()
    blast_dbs = blast_job['blast_dbs']

    # If the user selected one or more of the preformatted databases
    if(blast_db_type == "preformatted"):
        #create the alisas db

        db_list = [ f['db'] for f in blast_dbs]

        #if the program is blastp or blastx create a protein database
        if(blast_program == 'blastp' or blast_program == 'blastx'):
            make_alias_db_preformatted(db_list,blast_db_root,blast_task_dir,task_id,"protein",blast_bin)
        else:
            #the db of not matter if it is not "protein" in the preformatted case
            make_alias_db_preformatted(db_list,blast_db_root,blast_task_dir,task_id,"blah-blah",blast_bin)

    #the user is blasting custom database
    else:

        #getting the sequence type
        blast_seq_type = blast_job['blast_seq_type']

        #getting the list of genomes satisfying the queries that the user has submitted
        genome_list = get_genomes_from_search_items(blast_dbs)

        if(blast_seq_type == "protein"):
             #making an alias db from the genomes list
             make_alias_db(genome_list,blast_db_root,blast_task_dir,task_id,"protein",blast_bin)
        else:
            if(blast_seq_type == "gene"):
                make_alias_db(genome_list,blast_db_root,blast_task_dir,task_id,"gene",blast_bin)
            else:
                if(blast_seq_type == "genome"):
                    make_alias_db(genome_list,blast_db_root,blast_task_dir,task_id,"genome",blast_bin)
                else:
                    if(blast_seq_type == "gene+genome"):
                        make_alias_db(genome_list,blast_db_root,blast_task_dir,task_id,"gene+genome",blast_bin)


    blast_db_fullpath = blast_task_dir + "/" + task_id

    blast_args_list = [blast_program_fullpath, "-query","blast.in","-db",blast_db_fullpath,"-out","blast.out.asn.1","-outfmt","11","-num_threads",str(blast_num_threads)]
    fmtr_args_list_xml = [blast_formatter_fullpath,"-archive","blast.out.asn.1","-outfmt","5","-out","blast.out.xml"]
    fmtr_args_list_html = [blast_formatter_fullpath,"-archive","blast.out.asn.1","-html","-out","blast.out.html"]
    
    Popen(blast_args_list, stdin=PIPE, stdout=PIPE).wait()
    Popen(fmtr_args_list_xml, stdin=PIPE, stdout=PIPE).wait()
    Popen(fmtr_args_list_html, stdin=PIPE, stdout=PIPE).wait()
    
    parse_blast_out(blast_task_dir)
    prepare_html_out(blast_task_dir)

    #updating task collection that the task has finished
    celColl.update_one({"task_id":task_id},{"$set": {"end_date": datetime.datetime.utcnow(), "status":"Complete"}},upsert=False)

    return task_id

#removes parts of the html file like the hits table
#makes sure the hashtag anchor in the html file does not contain the ":" character because
#angular does not like it
def prepare_html_out(input_dir):

    query_num = 0
    
    input_file = input_dir + "/blast.out.html"

    fp = open(input_file)


    start_writing = False
    for line in fp:
        
        #A new query
        if "<b>Query=</b>" in line:
            #if it is not the first query, the we need to release the file pointer
            if query_num != 0:
                of.write("</PRE>\n</BODY>\n</HTML>")
                of.close()
            
            #creatinh a new output file for each query
            of = open(input_dir + "/query_"  + str(query_num) + "/blast.out.modified.html", 'w')
            of.write("<HTML>" + "\n"+ '<BODY BGCOLOR="#FFFFFF" LINK="#0000FF" VLINK="#660099" ALINK="#660099">' + "\n" + '<PRE>'+"\n")
            start_writing = False
            #used to create hashtag anchors
            hit_counter = 0
            query_num = query_num + 1

        if "<a name=" in line or "***** No hits found *****" in line:
            start_writing = True
            if("<a name=" in line):
                internal_hit_id = "hit_" + str(hit_counter)
                replace_str = "id=" + internal_hit_id + " name="
                line = line.replace("name=", replace_str,1)
                hit_counter = hit_counter + 1
        if start_writing:
            #don't write the following HTML tags from the file. We will write it manually
            if "<HTML>" in line or "<BODY BGCOLOR" in line or "<PRE>" in line or "</PRE>" in line or "</BODY>" in line or "</HTML>" in line:
                pass 
            else:
                of.write(line)
    fp.close()
    #hte output file for the last query is not closed in the above loop.
    #handling it here
    of.write("</PRE>\n</BODY>\n</HTML>")
    of.close()
    




#given a list of search items (md-chips) entered by the user, this function produces a list of genes 
#satisfying the search item query
def get_genomes_from_search_items(search_items):
    comp1 = []
    #selected items in the md-chips
    for item in search_items:
        
        #if there is a tax id then the search must be within the lineage array
        if item["tax_id"] != "":
            comp1.append({"lineage":{"$elemMatch": {"rank": item["type"], "tax_id":item["tax_id"]}}})
        else:
            #the item must contain a accession number or a intra species name
            #see import_genomes.py in the scripts directory
            comp1.append({item["type"]:item["name"]})
   
    #when search item list is not empty
    if len(comp1) > 0:
        #building the query
        query = {"$or" : comp1}
        queryResult = list(genomeCollection.find(query,{"assembly_acc": 1,"_id":0}))
        result = [ f['assembly_acc'] for f in queryResult]

    else:
        result = []

    return result


#gets genomes under a certain rank:taxid combo
#inputs are the rank and its value. e.g. "species", 1428 is for bacillus thuringiensis
def get_genomes_under_rank(rank,value):
    queryResult = genomeCollection.find({"lineage":{"$elemMatch": {"rank": rank, "tax_id":value}}},{"assembly_acc": 1,"_id":0})
    return list(queryResult)

#NOTE: this function is also copied in scripts/make_blast_databases. If you are making changes, make sure to change the other copy as well
#make alias db for a list of genome accessions
#dbof is one of protein,gene,genome
def make_alias_db(genome_list,blast_db_root,out_dir,out_db_name,dbof,blast_bin):
    
    dblist_file = out_dir + "/" + out_db_name + "_db_list"
    of = open(dblist_file,"w")
    for genome in genome_list:
        genome = genome.strip()

        #if it is  a db of gene and genomes
        if(dbof == "gene+genome"):
            dbname = blast_db_root + "/" + genome + "/" + "gene" + "/" + genome + "\n" + blast_db_root + "/" + genome + "/" + "genome" + "/" + genome
        else:
            dbname = blast_db_root + "/" + genome + "/" + dbof + "/" + genome

        of.write(dbname+ "\n")
    of.close()

    if(dbof is "protein"):
        dbtype = "prot"
    else:
        dbtype = "nucl"
        
    os.chdir(out_dir)
    alias_program = blast_bin + "/" + "blastdb_aliastool"
    aliascmd = alias_program + " -dblist_file " + dblist_file + " -dbtype " + dbtype + " -out " + out_db_name + " -title  " + out_db_name
    os.system(aliascmd)

#making alias db of preformatted databases
def make_alias_db_preformatted(db_list,blast_db_root,out_dir,out_db_name,dbof,blast_bin):
    
    dblist_file = out_dir + "/" + out_db_name + "_db_list"
    of = open(dblist_file,"w")
    for db in db_list:
        db = db.strip()
        dbname = blast_db_root + "/" + db + "/" + db
        of.write(dbname+ "\n")
    of.close()

    if(dbof is "protein"):
        dbtype = "prot"
    else:
        dbtype = "nucl"
        
    os.chdir(out_dir)
    alias_program = blast_bin + "/" + "blastdb_aliastool"
    aliascmd = alias_program + " -dblist_file " + dblist_file + " -dbtype " + dbtype + " -out " + out_db_name + " -title  " + out_db_name
    os.system(aliascmd)

#creates  files from blast output e.g. the  tabular and input for graphical overview
#TODO: this code assumes that there is only one query sequence. Need to change it later.
def parse_blast_out(out_dir_root):

    #this is the total number of hits for which the info will be written for drawing in the graphical overview
    num_graph_hits = 20
    
    result_handle = open(out_dir_root + "/blast.out.xml")
    blast_records = NCBIXML.parse(result_handle)

    #currently stores the names of the queries to be displayed in front end
    queries_file = open(out_dir_root + "/queries.txt","w")
    
    query_num = 0
    #for each query
    for blast_record in blast_records:
    
        #first line that will be printed in hsp  output file
        first_line_dict = {}
        #names of hits
        hit_names = []

        out_str = ""
   
        first_line_dict["queryLen"] = blast_record.query_length
        first_line_dict["query"] = blast_record.query

        #writing the name of the query to for displaying in front end
        queries_file.write(blast_record.query + "\n")

        #creating output directory for blast results of  a specific query
        out_dir_name = out_dir_root + "/query_" + str(query_num)
        lutils.my_makedir(out_dir_name)

        hitsfile = open(out_dir_name + "/hits_info.txt", 'w')
        hits_counter = 0
        for alignment in blast_record.alignments:

            hit_id = alignment.hit_id
            hit_desc = lutils.remove_loci_attributes(alignment.hit_def)
            #gets the database to which the hit belongs to from the fasta header
            hit_db = lutils.get_loci_attribute(alignment.hit_def,"mylocidb")
        
            #for graphical overview
            if(hits_counter < num_graph_hits):
                hit_names.append(alignment.hit_id + " " + hit_desc)
        
            hsp_counter = 0

            for hsp in alignment.hsps:
                #for graphical overview
                if(hits_counter < num_graph_hits):
                    my_dict = {"hit_name":alignment.hit_id + " " + hit_desc,"score":str(hsp.score),"start":str(hsp.query_start),"end":str(hsp.query_end) }
                    out_str = out_str + str(my_dict) + "\n"
            
                #write information about the first hsp into the hits file
                if(hsp_counter == 0):
                    query_coverage = int(math.floor((((hsp.query_end - hsp.query_start) + 1) / blast_record.query_length)*100))
                    percent_id = int(math.floor((hsp.identities/hsp.align_length)*100))
        

                    #this name is sent to the client side to be used as the hashtag anchor for the hits
                    #to jump from the table to the alignment. see prepare_html_out function to see how i create
                    #ids for hashtag anchors
                    internal_hit_name = "hit_" + str(hits_counter)
                    #writing data for the table in front-end
                    hit_dict = {"internal_hit_name":internal_hit_name,"id":hit_id,"desc":hit_desc,"max_score":str(hsp.score),"evalue":str(hsp.expect),"query_coverage":str(query_coverage),"percent_id":str(percent_id),"locidb":hit_db}
                    hitsfile.write(str(hit_dict) + "\n")

                hsp_counter = hsp_counter+1

            hits_counter = hits_counter +  1

        hitsfile.close()

        first_line_dict["hit_names"] = hit_names

        #writing the output file for graphical overview
        of = open(out_dir_name + "/hsp_info.txt", 'w')
        of.write(str(first_line_dict) + "\n")
        of.write(out_str)
        of.close()

        query_num = query_num + 1

    queries_file.close()

if __name__ == "__main__":
    app.run()