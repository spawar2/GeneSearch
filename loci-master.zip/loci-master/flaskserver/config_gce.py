#google compute engine config file
#NOTE: the config variables should be all caps

'''
USER INPUT NEEDED
'''

LOCI_ADMIN_EMAIL = "admin@karyosoft.com"

#mongo server
MY_MONGO_SERVER = "localhost"
MY_MONGO_PORT = 1401

#General config
MY_APP_ROOT = "/mnt/disks/locidisk/projects/loci/flaskserver"

#BLAST config
BLAST_BIN = "/mnt/disks/locidisk/projects/software/blast/ncbi-blast-2.6.0+/bin"
#try different values. a good value is total number of cores available
#this is the num_threads parameter for blast programs
BLAST_NUM_THREADS = 94

#maximum number of queries for blast
MAX_BLAST_QUERIES = 20



#Celery settings
CELERY_BROKER_URL='amqp://localhost'
CELERY_RESULT_BACKEND=''

#maximum number of genes that can be downloaded from this server in fasta format
MAX_GENE_DOWNLOAD_COUNT = 5000
#maximum number of genomes that can be downloaded from this server in fasta format
MAX_GENOME_DOWNLOAD_COUNT = 5000
#maximum number of proteins that can be downloaded from this server in fasta format
MAX_PROTEIN_DOWNLOAD_COUNT = 5000
#maximum number of blast hits that can be downloaded from server in fasta format
MAX_HIT_DOWNLOAD_COUNT = 500


#maximum number of genes that can be downloaded from this server in csv format
MAX_GENE_DOWNLOAD_COUNT_CSV = 50000
#maximum number of genomes that can be downloaded from this server in csv format
MAX_GENOME_DOWNLOAD_COUNT_CSV = 50000
#maximum number of proteins that can be downloaded from this server in csv format
MAX_PROTEIN_DOWNLOAD_COUNT_CSV = 50000
#maximum number of blast hits that can be downloaded from server in csv format
MAX_HIT_DOWNLOAD_COUNT_CSV = 500

#maximum number of ANY genes, gemomes, or proteins documents to be found in
#their respective mongodb collection
MAX_FIND_LIMIT_GENOMES = 100000000
MAX_FIND_LIMIT_GENES = 20000
MAX_FIND_LIMIT_PROTEINS = 20000


''' 
NO USER INPUT NEEDED HERE
'''
#General config
MY_DATA_ROOT = MY_APP_ROOT + "/static/loci_data"

#BLAST config
BLAST_DB_ROOT = MY_DATA_ROOT + "/blastdbs"

#BLAST TASKS
BLAST_TASKS_ROOT = MY_DATA_ROOT + "/user_data/blast_tasks"

LOCI_DOWNLOAD_ROOT = MY_DATA_ROOT + "/user_data/downloads"

#root of raw genome data fasta,gff, etc are stored here
GENOME_FILES_ROOT = MY_DATA_ROOT + "/genome_data"
GENOME_DATA_ROOT = GENOME_FILES_ROOT + "/data"

# for auth/flask_login
SECRET_KEY = b'\x9f\x9b]Gx\xab\xde\xdc\xd7\xd5\x10c\x99\x0e\xef\x1cg\xed\x12\xab\x07\x1e\xf2O'




