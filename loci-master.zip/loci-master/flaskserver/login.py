from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from flask import abort

password_hasher = PasswordHasher()

class User():

    def __init__(self, user_id, email, first_name, last_name):
        self.user_id = user_id
        self.email = email
        self.first_name = first_name
        self.last_name = last_name

    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return False

    def get_id(self):
        return self.email

    def get_name(self):
        return {"firstName": self.first_name, "lastName": self.last_name}

    def get_user_id(self):
        return self.user_id

    @staticmethod
    def validate_login(password_hash, password):
        try:
            return password_hasher.verify(password_hash, password)
        except VerifyMismatchError:
            abort(401)

    @staticmethod
    def hash_password(password):
        try:
            return password_hasher.hash(password)
        except:
            abort(400)


