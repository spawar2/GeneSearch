import re
import gzip
import os
import json
from operator import itemgetter
from subprocess import Popen, PIPE

# column name and their types for sorting via the typed_lambda function below
int_table_columns = ['num_proteins', 'num_genes', 'length', 'percent_id', 'query_coverage']
float_table_columns = ['gc', 'size', 'evalue', 'max_score']

# returns a lambda that casts its return value for sorting in "sorted"
# if the sort column isn't in either the int or float list, then it is
# sorted as is ... as a string
def typed_lambda(sort_column):
  if sort_column in int_table_columns:
    return lambda key: int(key[sort_column])
  elif sort_column in float_table_columns:
    return lambda key: float(key[sort_column])
  else:
    return lambda key: key[sort_column]

#removes loci attributes from a string
def remove_loci_attributes(input_str):
    #removing loci attributes
    out_str = re.sub(r"MyLociAttributes=\[.+\]=EndMyLociAttributes", "", input_str)
    out_str = out_str.strip()

    return out_str

#gets the description from loci style fasta header which includes the id
def get_fasta_header_desc(header):

    #removing loci attributes
    header = re.sub(r"MyLociAttributes=\[.+\]=EndMyLociAttributes", "", header)
    header = header.strip()

    #splitting by white space ones. the first item should be id and the second shoud be description
    words = header.split(None,1)
    
    if len(words) == 2:
        return words[1]
    else:
        return ""


def get_loci_attribute(header,attribute):
    loci_attributes_str  = find_between(header,"MyLociAttributes=[","]=EndMyLociAttributes")

    if loci_attributes_str != "":
        return find_between(loci_attributes_str,attribute+"=",";")
    else:
        return ""

#https://stackoverflow.com/questions/3368969/find-string-between-two-substrings
def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""


#checks if a file is zipped using gzip and returns appropriate handle
def my_get_handle(file_name,mode):
    if file_name.endswith(".gz"):
        handle = gzip.open(file_name,mode)
    else:
        handle = open(file_name,mode)
    return handle


#gets full path of blast db from seq_db name
#name type is either protein, gene, genome, or blastdb. for protein and genes
def get_blast_db_full_path(seq_db,blast_db_root,name_type):
    if name_type != "blastdb":
        blast_db_fullpath = blast_db_root + "/" +  seq_db + "/" + name_type + "/" + seq_db
        return blast_db_fullpath
    
    #the seq_db name comes from a fasta file
    if seq_db.endswith("_mylocigene"):
        #handle download of gene sequences
        genome_acc = seq_db.replace("_mylocigene","")
        blast_db_fullpath = blast_db_root + "/" +  genome_acc + "/gene/" + genome_acc
    elif seq_db.endswith("_mylociprotein"):
        genome_acc = seq_db.replace("_mylociprotein","")
        blast_db_fullpath = blast_db_root + "/" +  genome_acc + "/protein/" + genome_acc
    elif seq_db.endswith("mylocigenome"):
        genome_acc = seq_db.replace("_mylocigenome","")
        blast_db_fullpath = blast_db_root + "/" +  genome_acc + "/genome/" + genome_acc
    else:
        #external public database like nr, nt, etc
        blast_db_fullpath = blast_db_root + "/" + seq_db + "/" + seq_db

    return blast_db_fullpath


#gets sequence in fasta format using blastdbcmd and stores it in ouput file
def run_blast_db_cmd(blast_bin,seq_id,blast_db_fullpath,outfile_full_path):
    blast_program_fullpath = blast_bin + "/blastdbcmd"
    blastdbcmd_args_list = [blast_program_fullpath, "-entry",seq_id,"-db",blast_db_fullpath,"-out",outfile_full_path,"-outfmt","\'%f\'","-target_only"]
    Popen(blastdbcmd_args_list, stdin=PIPE, stdout=PIPE).wait()

#gets sequences in fasta format using blastdbcmd and appends to output file
#https://stackoverflow.com/questions/7389158/append-subprocess-popen-output-to-file
def run_blast_db_cmd_append(blast_bin,seq_id,blast_db_fullpath,outfile_handle):
    blast_program_fullpath = blast_bin + "/blastdbcmd"
    blastdbcmd_args_list = [blast_program_fullpath, "-entry",seq_id,"-db",blast_db_fullpath,"-outfmt","\'%f\'","-target_only"]
    Popen(blastdbcmd_args_list, stdin=PIPE, stdout=outfile_handle).wait()

#uses blastdbcmd to get a single sequene from a blast db. returns it as a string
def get_seq_blast_db_cmd(blast_bin,seq_id,blast_db_fullpath):
    blast_program_fullpath = blast_bin + "/blastdbcmd"
    blastdbcmd_args_list = [blast_program_fullpath, "-entry",seq_id,"-db",blast_db_fullpath,"-outfmt","\'%f\'","-target_only"]
    process = Popen(blastdbcmd_args_list,stdout=PIPE)
    fasta = process.communicate()[0]
    return fasta



#converts a jsonl file to a genrator returning one line at a time as a dictionary
def jsonl_dict_generator(file_name):
    fp = my_get_handle(file_name,"r")
    for line in fp:
        yield eval(line.strip())
    fp.close()

#makes a directory if it does not already exist
def my_makedir(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)
    
'''
print get_fasta_header_db("abc desc=this is description\tdb=this is the database")
print get_fasta_header_db("abc desc=this is description\tdb=this is the database")
'''

#returns dictionary of data formated by fields and sections files from summary_format dir
def format_fields_and_sections(type, data):

    #open and read json format "template" files into section and filed buffers
    if type == "genomes":
        format_sections = open('summary_format/genomes_sections.json').read()
        format_fields = open('summary_format/genomes_fields.json').read()
    elif type == "genes":
        format_sections = open('summary_format/genes_sections.json').read()
        format_fields = open('summary_format/genes_fields.json').read()
    elif type == "proteins":
        format_sections = open('summary_format/proteins_sections.json').read()
        format_fields = open('summary_format/proteins_fields.json').read()
    else:
        return {"error": "Bad format file name"}

    #create dicts from json format "templates"
    sections = json.loads(format_sections)
    fields = json.loads(format_fields)

    #process each section
    for section in sections:
        sub_section_values = []
        #find all fields for the current section
        try:
            for field in fields:
                if field["section_id"] == section["section_id"]:
                    field_id = field["field_id"]
                    #if the data has a key for the current field
                    #set the field value to it, otherwise set it to "N/A"
                    if data.has_key(field_id):
                        value = data[field_id]
                    else:
                        value = "N/A"
                    field.update({"value": value})
                    #add newly updated field dict to list of section sub values
                    sub_section_values.append(field)
        except Exception as e:
            print "We have an error in the processing the fields", e
            
        #sort list of sub_section_values according to their order_in_section value
        sorted_sub_section_values = sorted(sub_section_values, key=itemgetter("order_in_section"))
        #create and set sub_section_values list as property on the current section
        section.update({"sub_section_values": sorted_sub_section_values})
    #sort the sections according to the section_order
    sorted_formatted_data = sorted(sections, key=itemgetter("section_order"))
    return sorted_formatted_data