//environment variables for google compute engine
export const environment = {  
  production: false,
  envName: 'gce',

  //this is the place where the flask server is running
  serverURL: "http://18.191.186.163:5000/",
  jBrowseURL: "http://18.191.186.163:5000/static/jbrowse/JBrowse-1.12.1/index.html?menu=0&data=loci_jbrowse_data/"
};
