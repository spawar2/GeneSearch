//environment variables for google compute engine
export const environment = {  
  production: true,
  envName: 'prod',

  //this is the place where the flask server is running
  serverURL: "http://52.14.184.181:5000/",
  jBrowseURL: "http://52.14.184.181:5000/static/jbrowse/JBrowse-1.12.1/index.html?menu=0&data=loci_jbrowse_data/"
};
