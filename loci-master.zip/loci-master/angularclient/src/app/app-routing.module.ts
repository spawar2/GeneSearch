
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GenomesComponent } from './components/genomes/genomes.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { GenomeDetailsComponent } from './components/genome-details/genome-details.component'
import { GenomeBrowserComponent } from './components/genome-browser/genome-browser.component'
import { BlastComponent } from './components/blast/blast.component'
import { MyTasksComponent } from './components/my-tasks/my-tasks.component'
import { TaskConfirmationComponent } from './components/task-confirmation/task-confirmation.component'
import { BlastResultComponent } from './components/blast-result/blast-result.component'
import { ProteinsComponent } from './components/proteins/proteins.component';
import { GenesComponent } from './components/genes/genes.component';
import { LoginComponent } from './components/login/login.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { AuthGuard } from './services/auth-guard.service';
import { SummaryComponent } from './components/summary/summary.component';


const routes: Routes = [
  {
    path: 'change-password',
    component: ChangePasswordComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'genomes',
    component: GenomesComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'proteins',
    component: ProteinsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'detail/:strain',
    component: GenomeDetailsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'browser/:genome',
    component: GenomeBrowserComponent,
    canActivate: [AuthGuard]
  },
  //loc is for location
  {
    path: 'browser/:genome/:loc',
    component: GenomeBrowserComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'blast/:assembly_acc', 
    component: BlastComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'blast/:assembly_acc/:query_type/:query_id', 
    component: BlastComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'blast',
    component: BlastComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'mytasks',
    component: MyTasksComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'taskconfirmation',
    component: TaskConfirmationComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'blastresult/:task_id',
    component: BlastResultComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'genes',
    component: GenesComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'summary/:type/:id',
    component: SummaryComponent,
    canActivate: [AuthGuard]
  },
  {
    path: '',
    redirectTo: '/dashboard',
    pathMatch: 'full'
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }