export class GeneSearchItem {
    //e.g. bacillus thuringiensis
    name: string = "";
    //e.g. species
    type: string = "";
    //e.g. 123
    tax_id: string = "";
    };
    
    //this is the event that is fired when the search button is clicked on the my-search-component
    export class GeneSearchEvent{
    
        //these are the selected items
        searchItems: GeneSearchItem[] = [];
    
        //string in the input box
        searchString: string = "";
    
        //num pages to skip after searching
        skip: number =  0;
    
        //limit number of results
        limit: number = 10;
    
        //which prublic collections to search
        publicCollections: string[] = [];
    
        //which private collections to search
        privateCollections: string[] = [];
    
        //what type of CSV download
        downloadType: string = "gene";
    
        selectedItems: string[] = [];
        
    }
    