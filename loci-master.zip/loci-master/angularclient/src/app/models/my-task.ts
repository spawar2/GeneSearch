export class MyTask {
  task_id: string;
  task_type: string;
  status: string;
  task_name: string
}