export interface DialogData {
    message: string;
    email: string;
  }