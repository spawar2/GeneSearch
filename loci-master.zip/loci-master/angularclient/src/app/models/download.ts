export class SingleSequenceDownloadEvent {
    
        seqDB: string = "";
        seqID: string = "";
    
    }