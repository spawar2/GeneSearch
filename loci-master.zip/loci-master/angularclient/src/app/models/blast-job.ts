export class BlastJob {
  //'seq' if the user enters a fasta sequence. 'file' if a fasta file needs to be uploaded
  //'seq_id' if the sequence identifier is entered in the text box
  inputType: string;
  //this is what is entered in the text box
  input: string;

  //this is set when inputType is set to seq_id.
  //the accepted values are "gene" and "protein"
  seq_type: string;

  //this is set when inputType is set to seq_id
  //we need the assembly accession to go retrive the sequence
  assembly_acc:string;

  program: string;
  task_name: string;
  blast_dbs =  [];

  //custom or preformatted
  blast_db_type: string;

  //gene or protein or genome
  blast_seq_type: string;
}