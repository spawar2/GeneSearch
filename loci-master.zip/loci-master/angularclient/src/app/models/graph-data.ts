//data for blast graphical overview

export class GraphData {
  query_len: number;
  hit_names: string[];
  hsp_data: Array<any>;

}