export class Gene{
    
    _id: string;
    seq_type:string;
    unique_id :string;
    description:string;
    length:string;
    assembly_acc:string;
    species:string;
    lineage:string;
    privacy:string;
    collection:string;
    biotype: string;
  }