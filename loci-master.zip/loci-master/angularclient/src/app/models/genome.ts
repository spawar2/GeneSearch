export class Genome {
  _id: string;
  assembly_acc: string;
  tax_id: string;
  intraspecies_name: string;
  species: string;
  num_proteins: string;
  num_genes: string;
  size: string;
  gc: string;
  collection: string;
  privacy: string;
}