export class BlastHit {
  //'seq' if the user enters a fasta sequence. 'file' if a fasta file needs to be uploaded
  //'seq_id' if the sequence identifier is entered in the text box
  id: string;
  desc: string;
  max_score: string;
  evalue: number;
  query_coverage: string;
  percent_id: string;
  internal_hit_name: string;
  locidb:string;
}