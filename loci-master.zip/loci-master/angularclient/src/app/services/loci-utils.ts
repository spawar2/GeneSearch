//file where general reusable functions are stored

export class LociUtils {


    //call this function like this:
    //this.saveAs("http://localhost:5000/api/v1.0/download/testgetfile");
    //saves a file. Bypasses angular http client by simulating a clisk
    saveAs(uri) {
        var link = document.createElement('a');
        if (typeof link.download === 'string') {
            link.href = uri;
            link.setAttribute('download', "sequences.txt");

            //Firefox requires the link to be in the body
            document.body.appendChild(link);

            //simulate click
            link.click();

            //remove the link when done
            document.body.removeChild(link);
        } else {
            window.open(uri);
        }
    }

}

