import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Headers, Http, RequestOptions, ResponseContentType } from '@angular/http';


@Injectable()
export class HelpService {

        private serverURL = environment.serverURL;
        private getAdminEmailUrl = this.serverURL + "api/v1.0/help/getadminemail";
        private downloadManualUrl = this.serverURL + "api/v1.0/help/downloadmanual";


        constructor(private http: Http) { }

        //gets Amin email
        getAminEmail() {

                return this.http.get(this.getAdminEmailUrl, { withCredentials: false })
                        .map(res => res.json());

        }

        downloadManual() {
                return this.http
                .get(this.downloadManualUrl, {
                  responseType: ResponseContentType.Blob,
                })
                .map(res => {
                  return res.blob();
                });
        }


}
