import { TestBed, inject } from '@angular/core/testing';

import {LiveSearchService } from './live-search.service';

describe('GenomesLiveSearchService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LiveSearchService]
    });
  });

  it('should be created', inject([LiveSearchService], (service: LiveSearchService) => {
    expect(service).toBeTruthy();
  }));
});
