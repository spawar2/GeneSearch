import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import { environment } from '../../environments/environment';   

@Injectable()
export class MyTasksService {

  private serverURL = environment.serverURL;
  private tasksURL = this.serverURL + "api/v1.0/genomes/gettasksubset";

  public numTasks: number = 0;

  constructor(private http: Http) { }

    getTasks(sortOrder = 'asc', sortColumn = '', pageNumber = 0, pageSize = 10) {
        let skip = pageNumber.toString()
        let limit = pageSize.toString()

        return this.http.get(`${this.tasksURL}?skip=${skip}&limit=${limit}&sortOrder=${sortOrder}&sortColumn=${sortColumn}`, {withCredentials: true})
        .map(res => res.json());
    }

    get100Tasks() {

        return this.http.get(this.tasksURL + "?skip=" + 0 + "&limit=" + 100, {withCredentials: true})
            .map(res => res.json());
    }


}
