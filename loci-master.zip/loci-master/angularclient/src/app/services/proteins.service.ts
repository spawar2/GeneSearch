import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, ResponseContentType } from '@angular/http';
import { environment } from '../../environments/environment';
import { ProteinSearchEvent } from "../models/protein-search-item"
import { SingleSequenceDownloadEvent } from "../models/download"
import { LociUtils } from "./loci-utils"
import { Protein } from '../models/protein';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class ProteinsService {
    constructor(private http: Http) { }

    private serverURL = environment.serverURL;

    private proteinsURL = this.serverURL + "api/v1.0/proteins/getproteinsubset";
    private getSingleSeqURL = this.serverURL + "api/v1.0/download/downloadsinglesequence";
    private maxDownloadCountsURL = this.serverURL + "api/v1.0/download/maxdownloadcounts";
    private createSelectedProteinsURL = this.serverURL + "api/v1.0/download/createselectedproteinfasta"
    private createFilteredProteinsURL = this.serverURL + "api/v1.0/download/createproteinfastafilefordownload"
    private downloadFileURL = this.serverURL + "api/v1.0/download/downloadfilestream";
    private createFilteredProteinCSVURL = this.serverURL + "api/v1.0/download/createCSVfilefordownload"

    private lUtils = new LociUtils;
    public numProteins: number = 0
    public proteinLimit: number = 0
    public limitReached: boolean = false
    public searchEventSubject = new BehaviorSubject<ProteinSearchEvent>(undefined)

    addSearchEvent(val) {
        this.searchEventSubject.next(val)
    }

    getProteins(sortOrder = 'asc', sortColumn = '',
        pageNumber = 0, pageSize = 10): Observable<Protein[]> {

        let postData = {
            searchEvent: this.searchEventSubject.value,
            sortOrder: sortOrder,
            sortColumn: sortColumn,
            skip: pageNumber.toString(),
            limit: pageSize.toString()
        }
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, withCredentials: true });

        return this.http.post(this.proteinsURL, postData, options).map(res => res.json());
    }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }

    downloadSingleSequence(ssDownloadEvent: SingleSequenceDownloadEvent) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, responseType: ResponseContentType.Blob, withCredentials: true });

        return this.http.post(this.getSingleSeqURL, JSON.stringify(ssDownloadEvent), options)
            .map(res => { return new Blob([res.blob()], { type: "application/octet-stream" }) });
    }

    //gets the naximum number of genes for which fasta can be downloaded
    getMaxDownloadCounts() {

        return this.http.get(this.maxDownloadCountsURL, { withCredentials: true })
            .map(res => res.json());

    }

    //starts creation of fasta file with requested proteins
    createFilteredProteinsFasta(myEvent: ProteinSearchEvent) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, withCredentials: true });

        //setting them to -1 so there is no skip and limit
        //all sequences satisfying the filters will be downloaded
        myEvent.skip = -1;
        myEvent.limit = -1;

        return this.http.post(this.createFilteredProteinsURL, JSON.stringify(myEvent), options)
            .map(res => res.json());
    }

    //starts creation of fasta file with selected proteins
    createSelectedProteinsFasta(protein_array) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, withCredentials: true });

        return this.http.post(this.createSelectedProteinsURL, JSON.stringify(protein_array), options)
            .map(res => res.json());
    }


    downloadFileStream(file_name: string, outname: string) {

        let myURL = this.downloadFileURL + "?filename=" + file_name + "&outname=" + outname;
        this.lUtils.saveAs(myURL);

    }

    createFilteredProteinCSV(myEvent: ProteinSearchEvent) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, withCredentials: true });

        return this.http.post(this.createFilteredProteinCSVURL, JSON.stringify(myEvent), options)
            .map(res => res.json());
    }





}
