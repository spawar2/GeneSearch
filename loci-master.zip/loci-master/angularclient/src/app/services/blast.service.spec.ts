import { TestBed, inject } from '@angular/core/testing';

import { BlastService } from './blast.service';

describe('BlastService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BlastService]
    });
  });

  it('should be created', inject([BlastService], (service: BlastService) => {
    expect(service).toBeTruthy();
  }));
});
