import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, ResponseContentType } from '@angular/http';
import { environment } from '../../environments/environment';
import { SingleSequenceDownloadEvent } from "../models/download"
import { LociUtils } from "./loci-utils"


@Injectable()
export class BlastResultService {

  private serverURL = environment.serverURL;

  private getHspInfoURL = this.serverURL + "api/v1.0/blast/gethspinfo";
  private getHitInfoURL = this.serverURL + "api/v1.0/blast/gethitinfo";
  private getQueriesInfoURL = this.serverURL + "api/v1.0/blast/getqueriesinfo";
  private getHTMLResultsURL = this.serverURL + "api/v1.0/blast/getblasthmtl";
  private getSingleSeqURL = this.serverURL + "api/v1.0/download/downloadsinglesequence";
  private maxDownloadCountsURL = this.serverURL + "api/v1.0/download/maxdownloadcounts";
  private createBlastHitFastaURL = this.serverURL + "api/v1.0/download/createblasthitfasta";
  private downloadFileURL = this.serverURL + "api/v1.0/download/downloadfilestream";
  private createFilteredBlastHitCSVURL = this.serverURL + "api/v1.0/download/createblasthitCSVfilefordownload"
  private createSelectedHitsURL = this.serverURL + "api/v1.0/download/createselectedhitfasta";

  private lUtils = new LociUtils;
  public numHits: number = 0


  constructor(private http: Http) { }

  //used for graphical overview
  getBlastHspInfo(taskid: string, query_num: number) {

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, withCredentials: true });

    var post_obj = { taskid: taskid, query_num: query_num };


    return this.http.post(this.getHspInfoURL, JSON.stringify(post_obj), options)
      .map(res => res.json());

  }

  //used for graphical overview
  getBlastHitInfo(taskId: string, query_num: number, sortOrder = 'asc', sortColumn = '',
    pageNumber = 0, pageSize = 10) {

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, withCredentials: true });

    let postData = {
      taskId: taskId,
      sortOrder: sortOrder,
      sortColumn: sortColumn,
      skip: pageNumber.toString(),
      limit: pageSize.toString(),
      query_num: query_num
    }

    return this.http.post(this.getHitInfoURL, JSON.stringify(postData), options)
      .map(res => res.json());

  }

  //used for query names in selector
  getBlastQueryInfo(taskid: string) {

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, withCredentials: true });

    var post_obj = { taskid: taskid };

    return this.http.post(this.getQueriesInfoURL, JSON.stringify(post_obj), options)
      .map(res => res.json());

  }


  //get the html results
  getBlastHTMLResults(taskid: string, query_num: number) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, withCredentials: true });

    var post_obj = { taskid: taskid, query_num: query_num };

    return this.http.post(this.getHTMLResultsURL, JSON.stringify(post_obj), options)
      .map(res => res.json());
  }


  downloadSingleSequence(ssDownloadEvent: SingleSequenceDownloadEvent) {

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, responseType: ResponseContentType.Blob, withCredentials: true });

    return this.http.post(this.getSingleSeqURL, JSON.stringify(ssDownloadEvent), options)
      .map(res => { return new Blob([res.blob()], { type: "application/octet-stream" }) });
  }

  //gets the naximum number of genes for which fasta can be downloaded
  getMaxDownloadCounts() {

    return this.http.get(this.maxDownloadCountsURL, { withCredentials: true })
      .map(res => res.json());

  }

  createBlastHitFasta(taskid, query_num) {

    return this.http.get(this.createBlastHitFastaURL + "?taskid=" + taskid + "&querynum=" + query_num, { withCredentials: true })
      .map(res => res.json())
  }

  downloadFileStream(file_name: string, outname: string) {

    let myURL = this.downloadFileURL + "?filename=" + file_name + "&outname=" + outname;
    this.lUtils.saveAs(myURL);

  }

  createBlastHitCSV(taskid, query_num, selectedItems) {
    return this.http.get(`${this.createFilteredBlastHitCSVURL}?taskid=${taskid}&selectedItems=${selectedItems.toString()}&querynum=${query_num}`, { withCredentials: true })
      .map(res => res.json())
  }

  //starts creation of fasta file with selected proteins
  createSelectedHitsFasta(hit_array) {

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, withCredentials: true });

    return this.http.post(this.createSelectedHitsURL, JSON.stringify(hit_array), options)
      .map(res => res.json());
  }



}
