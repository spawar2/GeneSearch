import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { environment } from '../../environments/environment';


import { BlastJob } from '../models/blast-job'

@Injectable()
export class BlastService {

    private serverURL = environment.serverURL;
    private runBlastURL = this.serverURL + "api/v1.0/blast/runblast";
    private getBlastDbsURL = this.serverURL + "api/v1.0/blast/getblastdatabases";
    private maxQueryCountURL = this.serverURL + "api/v1.0/blast/maxquerycount"

    constructor(private http: Http) { }

    runBlast(blastJob: BlastJob) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, withCredentials: true });

        return this.http.post(this.runBlastURL, JSON.stringify(blastJob), options)
            .map(res => res.json());
    }

    getBlastDatabases() {

        return this.http.get(this.getBlastDbsURL, { withCredentials: true })
            .map(res => res.json());
    }

    //gets the naximum number of queries that can be blasted
    getMaxQueryCount() {

        return this.http.get(this.maxQueryCountURL, { withCredentials: true })
            .map(res => res.json());

    }

}
