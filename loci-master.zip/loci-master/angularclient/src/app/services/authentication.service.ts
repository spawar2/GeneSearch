import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import {Router} from '@angular/router'; 
import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/catch';
import {Observable} from "rxjs";

@Injectable()
export class AuthenticationService {

  private serverURL = environment.serverURL;
  private loginURL = this.serverURL + "login";
  private changePasswordURL = this.serverURL + "change-password";
  private logOutURL = this.serverURL + "logout";
  private getUserURL = this.serverURL + "get-user";
  
  public userIsLoggedIn: boolean
  public redirectURL: string
  public userName: string
  public activeLink: string = '/dashboard'

  constructor(private http: Http,
              private router: Router) { }

  loginUser(userInfo) {

      return this.http.post(this.loginURL, userInfo, {withCredentials: true})
          .map(res => res.json())
          

  }

  getUser() {
    this.http.get(this.getUserURL, {withCredentials: true})
        .map(res => res.json())
        .catch(e => {
          // Here we catch the nasty 401 error - if there happens to be one
          if (e.status === 401) {
              return Observable.throw('Unauthorized');
          }
        })
        .subscribe(
          res => {
            // On a successful call, we'll set loggedIn to true in the service,
            // set their name, and navigate to the dashboard
            if (res.success) {
              this.userIsLoggedIn = true
              this.userName = `${res.firstName} ${res.lastName}`
              this.router.navigate([this.activeLink])
            }
          }
        )

  }

  changePassword(userInfo) {

    return this.http.post(this.changePasswordURL, userInfo, {withCredentials: true})
        .map(res => res.json())

  }

  logUserOut() {
    this.http.get(this.logOutURL, {withCredentials: true})
        .map(res => res.json())
        .subscribe(
          res => {
            if (res.success) {
              this.userIsLoggedIn =  false
              this.activeLink = '/dashboard'
              this.router.navigate(['/login'])
            }
          }
        )
  }

}