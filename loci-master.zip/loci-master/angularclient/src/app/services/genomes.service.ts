import { Injectable } from '@angular/core';
import { Genome } from '../models/genome';
import { environment } from '../../environments/environment';

import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

import { GenomeSearchEvent } from "../models/genome-search-item"
import {LociUtils} from "./loci-utils"


@Injectable()
export class GenomeService {

    constructor(private http: Http) { }

    private serverURL = environment.serverURL;

    private genomesURL = this.serverURL + "api/v1.0/genomes/getgenomesubset";
    private downloadGenomeFastaURL = this.serverURL + "api/v1.0/download/downloadgenomefasta";
    private createFilteredGenomeCSVURL = this.serverURL + "api/v1.0/download/createCSVfilefordownload";
    private downloadFileURL = this.serverURL + "api/v1.0/download/downloadfilestream"
    private maxDownloadCountsURL = this.serverURL + "api/v1.0/download/maxdownloadcounts";

    private lUtils = new LociUtils;
    public numGenomes: number = 0
    public genomeLimit: number = 0
    public limitReached: boolean = false
    public searchEventSubject = new BehaviorSubject<GenomeSearchEvent>(undefined)

    addSearchEvent(val) {
        this.searchEventSubject.next(val)
    }

    getGenomes(sortOrder = 'asc', sortColumn = '',
        pageNumber = 0, pageSize = 10): Observable<Genome[]> {

        let postData = {
            searchEvent: this.searchEventSubject.value,
            sortOrder: sortOrder,
            sortColumn: sortColumn,
            skip: pageNumber.toString(),
            limit: pageSize.toString()
        }

        return this.http.post(this.genomesURL, postData, {withCredentials: true}).map(res =>  res.json());
    }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }


    downloadGenomeFasta(genomeAssemblyAcc: string){

       let myURL = this.downloadGenomeFastaURL + "?assembly=" + genomeAssemblyAcc;
       this.lUtils.saveAs(myURL);

    }

    downloadFile(file_name: string) {

        let myURL = this.downloadFileURL + "?filename=" + file_name + "&outname=genomes.csv";
        this.lUtils.saveAs(myURL);

    }

    createFilteredGenomeCSV(myEvent: GenomeSearchEvent) {
        
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, withCredentials: true});

        return this.http.post(this.createFilteredGenomeCSVURL, JSON.stringify(myEvent), options)
            .map(res => res.json());
    }

    //gets the naximum number of genes for which fasta can be downloaded
    getMaxDownloadCounts() {

        return this.http.get(this.maxDownloadCountsURL, {withCredentials: true})
            .map(res => res.json());

    }



}