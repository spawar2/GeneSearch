import { TestBed, inject } from '@angular/core/testing';

import { BlastResultService } from './blast-result.service';

describe('BlastResultService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BlastResultService]
    });
  });

  it('should be created', inject([BlastResultService], (service: BlastResultService) => {
    expect(service).toBeTruthy();
  }));
});
