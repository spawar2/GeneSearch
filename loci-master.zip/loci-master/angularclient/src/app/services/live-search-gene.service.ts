import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import { environment } from '../../environments/environment';

@Injectable()
export class LiveSearchGeneService {

  private serverURL = environment.serverURL;
  private livesearchURL = this.serverURL + "api/v1.0/genes/getlivesearchsuggestions";
  private collectionsURL = this.serverURL + "api/v1.0/genomes/getcollections";

  constructor(private http: Http) { }

  search(terms: Observable<string>, numResults:number) {
    return terms.debounceTime(400)
      .distinctUntilChanged()
      .switchMap(term => this.getLiveSearchSuggestions(0,numResults,term));
  }


  getLiveSearchSuggestions(skip: number, limit: number, searchString: string) {

        return this.http.get(this.livesearchURL + "?searchString=" + searchString + "&skip=" + skip + "&limit=" + limit, {withCredentials: true})
            .map(res => res.json());
    }

  getCollections(){
    return this.http.get(this.collectionsURL, {withCredentials: true})
    .map(res => res.json());
  }

}
