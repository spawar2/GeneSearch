import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, ResponseContentType, Response } from '@angular/http';
import { environment } from '../../environments/environment';
import { GeneSearchEvent } from "../models/gene-search-item"
import { SingleSequenceDownloadEvent } from "../models/download"
import { LociUtils } from "./loci-utils"
import { Observable } from 'rxjs/Observable';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import { Gene } from '../models/gene';

@Injectable()
export class GenesService {

    constructor(private http: Http) { }

    private serverURL = environment.serverURL;

    private genesURL = this.serverURL + "api/v1.0/genes/getgenesubset";
    private getSingleSeqURL = this.serverURL + "api/v1.0/download/downloadsinglesequence"
    private createFilteredGenesURL = this.serverURL + "api/v1.0/download/creategenefastafilefordownload"
    private createFilteredGenesCSVURL = this.serverURL + "api/v1.0/download/createCSVfilefordownload"
    private downloadFileURL = this.serverURL + "api/v1.0/download/downloadfilestream"
    private maxDownloadCountsURL = this.serverURL + "api/v1.0/download/maxdownloadcounts";
    private createSelectedGenesURL = this.serverURL + "api/v1.0/download/createselectedgenefasta"
    

    private lUtils = new LociUtils;
    public numGenes: number = 0
    public geneLimit: number = 0
    public limitReached: boolean = false
    public searchEventSubject = new BehaviorSubject<GeneSearchEvent>(undefined)

    addSearchEvent(val) {
        this.searchEventSubject.next(val)
    }

    getGenes(sortOrder = 'asc', sortColumn = '',
        pageNumber = 0, pageSize = 10): Observable<Gene[]> {

        let postData = {
            searchEvent: this.searchEventSubject.value,
            sortOrder: sortOrder,
            sortColumn: sortColumn,
            skip: pageNumber.toString(),
            limit: pageSize.toString()
        }

        return this.http.post(this.genesURL, postData, {withCredentials: true}).map(res =>  res.json());
    }

    //Downloads all sequences that passes filter
    createFilteredGenesFasta(myEvent: GeneSearchEvent) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, withCredentials: true});

        return this.http.post(this.createFilteredGenesURL, JSON.stringify(myEvent), options)
            .map(res => res.json());
    }

    //starts creation of fasta file with selected proteins
    createSelectedGenesFasta(gene_array) {
        
                let headers = new Headers({ 'Content-Type': 'application/json' });
                let options = new RequestOptions({ headers: headers, withCredentials: true });
        
                return this.http.post(this.createSelectedGenesURL, JSON.stringify(gene_array), options)
                    .map(res => res.json());
            }
        

    createFilteredGenesCSV(myEvent: GeneSearchEvent) {
        
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, withCredentials: true});

        return this.http.post(this.createFilteredGenesCSVURL, JSON.stringify(myEvent), options)
            .map(res => res.json());
    }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }



    downloadSingleSequence(ssDownloadEvent: SingleSequenceDownloadEvent) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers, responseType: ResponseContentType.Blob, withCredentials: true });

        return this.http.post(this.getSingleSeqURL, JSON.stringify(ssDownloadEvent), options)
            .map(res => { return new Blob([res.blob()], { type: "application/octet-stream" }) });
    }

    downloadFileStream(file_name: string, outname: string) {

        let myURL = this.downloadFileURL + "?filename=" + file_name + "&outname=" + outname;
        this.lUtils.saveAs(myURL);

    }

    //gets the naximum number of genes for which fasta can be downloaded
    getMaxDownloadCounts() {

        return this.http.get(this.maxDownloadCountsURL, {withCredentials: true})
            .map(res => res.json());

    }


}
