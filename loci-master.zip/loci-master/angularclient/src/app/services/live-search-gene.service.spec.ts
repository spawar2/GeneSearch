import { TestBed, inject } from '@angular/core/testing';

import { LiveSearchGeneService } from './live-search-gene.service';

describe('LiveSearchGeneService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LiveSearchGeneService]
    });
  });

  it('should be created', inject([LiveSearchGeneService], (service: LiveSearchGeneService) => {
    expect(service).toBeTruthy();
  }));
});
