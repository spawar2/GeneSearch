import { TestBed, inject } from '@angular/core/testing';

import { ProteinsService } from './proteins.service';

describe('ProteinsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProteinsService]
    });
  });

  it('should be created', inject([ProteinsService], (service: ProteinsService) => {
    expect(service).toBeTruthy();
  }));
});
