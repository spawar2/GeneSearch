import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment'; 
import { Headers, Http } from '@angular/http';

@Injectable()
export class DashboardService {

  private serverURL = environment.serverURL;
  private tasksURL = this.serverURL + "api/v1.0/dashboard/getdashboarddata";

  constructor(private http: Http) { }

  getDashboardData() {
    
            return this.http.get(this.tasksURL, { withCredentials: true })
                .map(res => res.json());
        }

}
