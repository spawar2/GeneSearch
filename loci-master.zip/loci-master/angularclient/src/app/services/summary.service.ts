import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment'; 
import { Headers, Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class SummaryService {

  private serverURL = environment.serverURL;
  private summaryDataURL = this.serverURL + 'api/v1.0/summary'

  constructor(private http: Http) { }

  getSummaryData(type: string, id: string) {

    // Uncomment and finish when backend route is complete
    return this.http.get(`${this.summaryDataURL}?type=${type}&id=${id}`, { withCredentials: true })
                    .map(res => res.json());
    
  }

}