import { TestBed, inject } from '@angular/core/testing';

import { LiveSearchProteinService } from './live-search-protein.service';

describe('LiveSearchProteinService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LiveSearchProteinService]
    });
  });

  it('should be created', inject([LiveSearchProteinService], (service: LiveSearchProteinService) => {
    expect(service).toBeTruthy();
  }));
});
