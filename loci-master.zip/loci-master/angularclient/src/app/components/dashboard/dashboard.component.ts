import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart } from 'chart.js';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { DataSource } from '@angular/cdk/collections';
import 'rxjs/add/observable/of';

import { DashboardService } from "../../services/dashboard.service"
import { AuthenticationService } from '../../services/authentication.service';


@Component({
  selector: 'my-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {

  myColors = {
    red: 'rgb(255, 99, 132)',
    orange: 'rgb(255, 159, 64)',
    yellow: 'rgb(255, 205, 86)',
    green: 'rgb(75, 192, 192)',
    blue: 'rgb(54, 162, 235)',
    purple: 'rgb(153, 102, 255)',
    grey: 'rgb(201, 203, 207)'
  };

  //TODO: change to proper colors later
  publicBgColors = [this.myColors.red, this.myColors.blue, this.myColors.green, this.myColors.yellow, this.myColors.orange];
  privateBgColors = [this.myColors.orange, this.myColors.green, this.myColors.yellow, this.myColors.blue, this.myColors.red];


  //charts
  privateCollectionsChart = [];
  publicCollectionsChart = [];
  publicSpeciesChart = [];
  privateSpeciesChart = [];

  //data for top public collections chart
  publicCollectionsData = {
    datasets: [{
      data: [],
      backgroundColor: [],
    },
    ],

    labels: []
  };

  //data for top private collections chart
  privateCollectionsData = {
    datasets: [{
      data: [],
      backgroundColor: []
    },
    ],

    labels: []
  };


  //data for top public species
  publicSpeciesData = {
    labels: [],
    datasets: [{
      label: '# of Genomes',
      data: [],
      backgroundColor: []
    }],

  };

  //public species chart options
  publicSpeciesChartOptions = {

    maintainAspectRatio: true,

    layout: {
      padding: {
        bottom: 50,
      }
    },

    scales: {
      xAxes: [{

        barPercentage: 0.6,

        gridLines: {
          display: false
        },
        ticks: {
          autoSkip: false,
          maxRotation: 45,
          minRotation: 45,
          fontSize: 14,
          fontStyle: "italic",
        },
      }],
      yAxes: [{
        gridLines: {
          display: false
        },
        ticks: {
          min: 0,
          max: 0,
          stepSize: 0,
          fontSize: 14,
        },
        scaleLabel: {
          display: true,
          labelString: 'Count',
          fontSize: 14,
        }
      }]
    },
    legend: {
      display: false
    },
  };

  //data for top private species
  privateSpeciesData = {
    labels: [],
    datasets: [{
      label: '# of Genomes',
      data: [],
      backgroundColor: []
    }],

  };

  //private species chart options
  privateSpeciesChartOptions = {

    maintainAspectRatio: true,

    layout: {
      padding: {
        bottom: 50,
      }
    },
    scales: {
      xAxes: [{

        barPercentage: 0.6,

        gridLines: {
          display: false
        },
        ticks: {
          autoSkip: false,
          maxRotation: 45,
          minRotation: 45,
          fontSize: 14,
          fontStyle: "italic",
        },
      }],
      yAxes: [{
        gridLines: {
          display: false
        },
        ticks: {
          min: 0,
          max: 0,
          stepSize: 0,
          fontSize: 14,
        },

        scaleLabel: {
          display: true,
          labelString: 'Count',
          fontSize: 14,
        }
      }]
    },
    legend: {
      display: false
    },
  }


  displayedColumns = ['name', 'public', 'private'];
  summaryTable = [
    { name: "Num. Genomes", public_count: 0, private_count: 0 },
    { name: "Num. Protein Coding Genes", public_count: 0, private_count: 0 },
    { name: "Num. tRNA Genes", public_count: 0, private_count: 0 },
    { name: "Num. rRNA Genes", public_count: 0, private_count: 0 },
    { name: "Num. ncRNA Genes", public_count: 0, private_count: 0 },
    { name: "Num. Proteins", public_count: 0, private_count: 0 },

  ];
  summaryTableDataSource = new SummaryTableDataSource(this.summaryTable);

  get userLoggedIn() {
    return this.authService.userIsLoggedIn
  }


  constructor(private dashboardService: DashboardService,
    private authService: AuthenticationService,
    private router: Router) { };

  ngOnInit(): void {

    this.dashboardService.getDashboardData().subscribe(data => {

      //Loading the table with correct values
      this.summaryTable[0].public_count = this.numberWithCommas(data.public_genomes_count);
      this.summaryTable[0].private_count = this.numberWithCommas(data.private_genomes_count);

      this.summaryTable[1].public_count = this.numberWithCommas(data.public_protein_coding_count);
      this.summaryTable[1].private_count = this.numberWithCommas(data.private_protein_coding_count);

      this.summaryTable[2].public_count = this.numberWithCommas(data.public_trna_count);
      this.summaryTable[2].private_count = this.numberWithCommas(data.private_trna_count);

      this.summaryTable[3].public_count = this.numberWithCommas(data.public_rrna_count);
      this.summaryTable[3].private_count = this.numberWithCommas(data.private_rrna_count);

      this.summaryTable[4].public_count = this.numberWithCommas(data.public_ncrna_count);
      this.summaryTable[4].private_count = this.numberWithCommas(data.private_ncrna_count);

      this.summaryTable[5].public_count = this.numberWithCommas(data.public_protein_count);
      this.summaryTable[5].private_count = this.numberWithCommas(data.private_protein_count);


      //public collections pie chart
      var numTopPublic = data.top_public_collections.length;

      for (var i = 0; i < numTopPublic; i++) {
        this.publicCollectionsData.labels[i] = data.top_public_collections[i]["_id"];
        this.publicCollectionsData.datasets[0].data[i] = data.top_public_collections[i]["count"];
        this.publicCollectionsData.datasets[0].backgroundColor[i] = this.publicBgColors[i];
      }

      this.publicCollectionsChart = new Chart('publicCollectionsCanvas', {
        type: 'doughnut',
        data: this.publicCollectionsData
      });


      //private collections pie chart
      var numTopPrivate = data.top_private_collections.length;

      for (var i = 0; i < numTopPrivate; i++) {
        this.privateCollectionsData.labels[i] = data.top_private_collections[i]["_id"];
        this.privateCollectionsData.datasets[0].data[i] = data.top_private_collections[i]["count"];
        this.privateCollectionsData.datasets[0].backgroundColor[i] = this.privateBgColors[i];
      }


      this.privateCollectionsChart = new Chart('privateCollectionsCanvas', {
        type: 'doughnut',
        data: this.privateCollectionsData
      });


      //top public species
      var numTopPublicSpecies = data.top_public_species.length;

      for (var i = 0; i < numTopPublicSpecies; i++) {
        this.publicSpeciesData.labels[i] = data.top_public_species[i]["_id"];
        this.publicSpeciesData.datasets[0].data[i] = data.top_public_species[i]["count"];
        this.publicSpeciesData.datasets[0].backgroundColor[i] = this.myColors.green;
      }

      //setting y axs max and step size.
      var pubMax = Math.max(...this.publicSpeciesData.datasets[0].data);
      this.publicSpeciesChartOptions.scales.yAxes[0].ticks.max = pubMax;
      if (pubMax != 0 && pubMax != undefined) {
        this.publicSpeciesChartOptions.scales.yAxes[0].ticks.stepSize = Math.ceil(pubMax / 4);
      }

      this.publicSpeciesChart = new Chart('publicSpeciesCanvas', {
        type: 'bar',
        data: this.publicSpeciesData,
        options: this.publicSpeciesChartOptions,
      });


      //top private species
      var numTopPrivateSpecies = data.top_private_species.length;

      for (var i = 0; i < numTopPrivateSpecies; i++) {
        this.privateSpeciesData.labels[i] = data.top_private_species[i]["_id"];
        this.privateSpeciesData.datasets[0].data[i] = data.top_private_species[i]["count"];
        this.privateSpeciesData.datasets[0].backgroundColor[i] = this.myColors.green;
      }

      //setting y axs max and step size.
      var priMax = Math.max(...this.privateSpeciesData.datasets[0].data);
      this.privateSpeciesChartOptions.scales.yAxes[0].ticks.max = priMax;
      if (priMax != 0 && priMax != undefined) {
        this.privateSpeciesChartOptions.scales.yAxes[0].ticks.stepSize = Math.ceil(priMax / 4);
      }


      this.privateSpeciesChart = new Chart('privateSpeciesCanvas', {
        type: 'bar',
        data: this.privateSpeciesData,
        options: this.privateSpeciesChartOptions,

      });


    }); //end  of subscribe
  } // end of onInit

  //https://stackoverflow.com/questions/2901102/how-to-print-a-number-with-commas-as-thousands-separators-in-javascript
  numberWithCommas(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
  }
} //end of class



interface MyDataType {
  name: string;
  public_count: number;
  private_count: number;
}

export class SummaryTableDataSource extends DataSource<MyDataType> {
  constructor(private staticData: MyDataType[]) {
    super();
  }

  connect(): Observable<MyDataType[]> {
    return Observable.of(this.staticData);
  }

  disconnect() { }
}