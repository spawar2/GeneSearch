import { Component, OnInit } from '@angular/core';
import { Inject } from '@angular/core';
import {DialogData} from '../../models/dialog-data';
import {MAT_DIALOG_DATA,MatDialogRef} from '@angular/material'

@Component({
  selector: 'app-my-dialog',
  templateUrl: './my-dialog.component.html',
  styleUrls: ['./my-dialog.component.css']
})

export class MyDialogComponent implements OnInit {

  message = "Thanks for using Loci";
  email = "info@karyosoft.com";

  constructor(
    public dialogRef: MatDialogRef<MyDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {
      this.message = data.message;
      this.email = data.email;
    }

  closeDialog(): void {
    this.dialogRef.close();
  }


  ngOnInit() {
  }

}
