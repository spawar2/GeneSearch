import { Component } from '@angular/core';
import {MatSnackBar} from '@angular/material';
import {Router} from '@angular/router'; 
import {AuthenticationService} from '../../services/authentication.service';

@Component({
  selector: 'change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent {

  changePasswordModel: any = {}
  checkEmailRegex = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
  checkPasswordRegex = /(?=\D*\d)(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z]).{8,}$/

  constructor(private authService: AuthenticationService,
              private snackBar: MatSnackBar,
              private router: Router){}

  changePassword() {
    if (this.changePasswordModel.email && this.changePasswordModel.password) {
      
      let passwordsMatch = this.changePasswordModel.password == this.changePasswordModel.verifyPassword
      let emailPassesTest = this.checkEmailRegex.test(this.changePasswordModel.email)
      let passwordPassesTest = this.checkPasswordRegex.test(this.changePasswordModel.password)

      if (emailPassesTest) {

        if (passwordPassesTest) {
          if (passwordsMatch) {
            this.authService.changePassword(this.changePasswordModel)
            .subscribe(
              res => {
                if (res.success) {
                  this.snackBar.open('Password successfully changed', 'Close', {
                    duration: 2500,
                  });
                  this.router.navigate(['/dashboard'])
                }
              }
            )
          } else {
            this.snackBar.open('Passwords do not match', 'Close');
          }

        } else {
          this.snackBar.open('Passwords must contain a lowercase letter, an uppcase letter, a number, and must be 8 characters long.', 'Close');
        }

      } else {
        this.snackBar.open('Emails must contain an @ and .', 'Close');
      }

    } else {
      this.snackBar.open('Please enter an email and password', 'Close');
    }

  }

}