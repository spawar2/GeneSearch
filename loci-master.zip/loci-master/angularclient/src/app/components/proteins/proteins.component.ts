import { Component, ViewChild } from '@angular/core';
import { ProteinsService } from '../../services/proteins.service';
import { Router } from '@angular/router';
import { ProteinSearchEvent } from "../../models/protein-search-item"
import { SnackbarService } from '../../services/snackbar.service';
import { ProteinTableComponent} from '../proteins-table/proteins-table.component'

@Component({
  selector: 'app-proteins',
  templateUrl: './proteins.component.html',
  styleUrls: ['./proteins.component.css']
})
export class ProteinsComponent {

  @ViewChild(ProteinTableComponent)
  private proteinTable: ProteinTableComponent;

  //toggle displaying the table
  showTable = false;

  constructor(private proteinService: ProteinsService, private router: Router, public sbService: SnackbarService) { };

  onDownloadAllFilteredSeqsButtonClicked() {
    this.proteinTable.onDownloadAllFilteredSeqsButtonClicked()
  }

  onDownloadSelectedSeqsButtonClicked() {
    this.proteinTable.onDownloadSelectedSeqsButtonClicked();
  }

  get numProteins() {
    return this.proteinService.numProteins == this.proteinService.proteinLimit? `>${this.proteinService.proteinLimit}`: this.proteinService.numProteins
  }

  onDownloadCSVButtonClicked() {
    let downloadSelectedRows = false
    this.proteinTable.onDownloadCSVButtonClicked(downloadSelectedRows)
  }

  onDownloadSelectedCSVButtonClicked() {
    let downloadSelectedRows = true
    this.proteinTable.onDownloadCSVButtonClicked(downloadSelectedRows)
  }

  //called when the search button is clicked
  onSearchButtonClicked(myEvent: ProteinSearchEvent): void {

    // Here we're adding the search event to the service, so it can be 
    // used in the service and in the table component
    this.proteinService.addSearchEvent(myEvent);

    // Once the table is shown, the table component will initialize with
    // the correct data
    this.showTable = true;

  }

  //called when the reset button is clicked
  onResetButtonClicked(): void {
    this.proteinService.addSearchEvent(undefined);
    this.showTable = false;
  }

}


