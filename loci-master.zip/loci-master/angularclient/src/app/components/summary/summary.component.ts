import { Component, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SummaryService } from '../../services/summary.service';

@Component({
  selector: 'summary-page',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent {

  id: string = ''
  type: string = ''
  summaryResults = []
  errorOccurred: boolean = false

  constructor(private summaryService: SummaryService, private activatedRoute: ActivatedRoute) {}
  
  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.id = params.id
      this.type = params.type
    });

    this.summaryService.getSummaryData(this.type, this.id)
      .subscribe(data => {
        if (data.error) this.errorOccurred = true
        else {
          this.summaryResults = data.map(item => {
            if (item.section_boolean) {
              let subSections = item.sub_section_values.filter(subSection => subSection.display_boolean)
              item.sub_section_values = subSections
              return item
            }
          })
        }
      })
  }
}