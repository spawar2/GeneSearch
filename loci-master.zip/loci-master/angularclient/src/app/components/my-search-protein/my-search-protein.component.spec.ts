import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MySearchProteinComponent } from './my-search-protein.component';

describe('MySearchProteinComponent', () => {
  let component: MySearchProteinComponent;
  let fixture: ComponentFixture<MySearchProteinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MySearchProteinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MySearchProteinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
