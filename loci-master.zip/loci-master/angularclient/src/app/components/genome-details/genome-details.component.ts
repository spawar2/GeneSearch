import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Params }   from '@angular/router';
import { Location }                 from '@angular/common';
import { GenomeService } from '../../services/genomes.service';
import {Genome} from '../../models/genome'

import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'genome-detail',
  templateUrl: './genome-details.component.html',


})
export class GenomeDetailsComponent implements OnInit{
     
    genome: Genome;

    constructor(
    private genomeService: GenomeService,
    private route: ActivatedRoute,
    private location: Location
    ) {}

    ngOnInit(): void {
        /*
        this.route.params
        .switchMap((params: Params) => this.genomeService.getGenome(params['strain']))
        .subscribe(genome => this.genome = genome);
        */
    }


    goBack(): void {
        this.location.back();
    }

}

