import { Component, ViewChild, OnInit, ElementRef, AfterViewInit } from '@angular/core';
import { Gene } from '../../models/gene';
import { GenesService } from '../../services/genes.service';
import { SnackbarService } from '../../services/snackbar.service'
import { Router } from '@angular/router';
import { GeneSearchEvent } from "../../models/gene-search-item"
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { CollectionViewer, DataSource, SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import * as FileSaver from 'file-saver';
import { SingleSequenceDownloadEvent } from "../../models/download"
import { debounceTime, distinctUntilChanged, catchError, finalize, tap } from "rxjs/operators";
import { merge } from "rxjs/observable/merge";
import { fromEvent } from 'rxjs/observable/fromEvent';


@Component({
  selector: 'gene-table',
  templateUrl: './gene-table.component.html',
  styleUrls: ['./gene-table.component.css']
})
export class GeneTableComponent implements OnInit, AfterViewInit {

  // Used to show the page result count
  pageIndex = 0;
  numGenesPerPage = 10;

  displayedColumns = ['select', 'id', 'biotype', 'desc', 'species', 'assembly', 'collection', 'length', 'analyze'];

  //datasource for the table
  dataSource: GenesDataSource | null;

  // Initial Values for Row Selection
  initialSelection = [];
  allowMultiSelect = true;
  selection = new SelectionModel<Gene>(this.allowMultiSelect, this.initialSelection);

  // Necessary for sorting, filtering, and pagination
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('input') input: ElementRef;

  //selected search items (see my-search component) and the search string
  searchEvent: GeneSearchEvent

  //maximum number of genes that can be downloaded as fasta format
  maxGeneDownloadCount = 0;

  //maximum number of genes that can be downloaded as csv format
  maxGeneDownloadCountCSV = 0;

  get numGenes() {
    return this.geneService.numGenes
  }

  constructor(private geneService: GenesService, private router: Router, public sbService: SnackbarService) { };

  ngOnInit(): void {
    this.dataSource = new GenesDataSource(this.geneService, this.sbService);
    this.paginator.pageIndex = 0;
    this.geneService.getMaxDownloadCounts().subscribe(data => {
      this.maxGeneDownloadCount = data.max_gene_download_count;
      this.maxGeneDownloadCountCSV = data.max_gene_download_count_csv;
    });
  }

  // Once the page has initialized
  // we set up the filter, sorting, and pagination
  ngAfterViewInit() {
    fromEvent(this.input.nativeElement, 'keyup')
      .pipe(
      debounceTime(150),
      distinctUntilChanged(),
      tap(() => {
        this.dataSource.filter(this.input.nativeElement.value)
      })
      )
      .subscribe();

    // reset the paginator after sorting
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    // on sort or paginate events, load a new page
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
      // If the sort changes or the page is changed, reload the table
      tap(() => this.loadGenesPage())
      )
      .subscribe();

    // Once a search event has been added, we load the table
    this.geneService.searchEventSubject.subscribe(value => {
      this.searchEvent = value
      if (value) {
        this.geneService.limitReached = false
        this.loadGenesPage()
      }
    })
  }

  getColumnToSort(columnName): string {
    switch (columnName) {
      case "numGenes":
        return "num_genes"
      case "numProteins":
        return "num_proteins"
      case "assembly":
        return "assembly_acc"
      case "id":
        return "unique_id"
      case "desc":
        return "description"
      default:
        return columnName
    }
  }

  loadGenesPage() {
    let columnNames = this.getColumnToSort(this.sort.active)
    // This will load our dataSource with updated data
    this.dataSource.loadGenes(
      this.sort.direction,
      columnNames,
      this.paginator.pageIndex,
      this.paginator.pageSize);
  }

  //called when the download button is clicked
  onDownloadButtonClicked(geneAssemblyAcc, geneUniqueId): void {

    var ssDownEvent = new SingleSequenceDownloadEvent();
    ssDownEvent.seqDB = geneAssemblyAcc + "_mylocigene";
    ssDownEvent.seqID = geneUniqueId;

    this.sbService.openSnackBar("Please wait while your sequences are being downloaded ...", "CLOSE", 3000)

    this.geneService.downloadSingleSequence(ssDownEvent)
      .subscribe(fileData => { FileSaver.saveAs(fileData, "sequences.txt"); });
  }

  //called when the download button is clicked
  onDownloadAllFilteredSeqsButtonClicked(): void {

    //if the num genes to be downloaded is greated than maximum allowed
    if (this.numGenes > this.maxGeneDownloadCount) {
      var message = "Can not download more than " + this.maxGeneDownloadCount + " genes in fasta format using Loci. ";
      message = message + "Please try changing your query or contact admin";
      this.sbService.openSnackBar(message, "CLOSE", 5000);
      return;
    }
    //if there are items in the chips or a search string to be searched
    if (this.searchEvent.searchItems.length > 0 || this.searchEvent.searchString != "") {
      this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000)
      this.geneService.createFilteredGenesFasta(this.searchEvent)
        .subscribe(data => {
          //the result will contain an error message if the num sequences requested
          //is greater than max allowable. This is still possible because of some 
          //quirks in the UI
          if (data.error_message != "") {
            this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
            return;
          }
          else {
            this.geneService.downloadFileStream(data.file_name, "gene_sequences.txt")
          }

        });
    }
    else {
      this.sbService.openSnackBar("Your query may have changed. Please click search button before download ..", "CLOSE", 3000);
    }

  }

  //called when the download selected sequences  is clicked
  onDownloadSelectedSeqsButtonClicked(): void {
    
        //getting the selected genes
        const selectedGenes = this.selection.selected;
    
        //if there are no selected items
        if (selectedGenes.length == 0) {
          this.sbService.openSnackBar("No items selected", "CLOSE", 5000);
        }
        else {
          const numSelected = selectedGenes.length;
          //object array to store the sequence id and the database name (assembly accession)
          var gene_obj_array = [];
          for (var i = 0; i < numSelected; i++) {
            gene_obj_array[i] = { unique_id: selectedGenes[i].unique_id, assembly_acc: selectedGenes[i].assembly_acc };
          }
    
          this.geneService.createSelectedGenesFasta(gene_obj_array)
            .subscribe(data => {
              //the result will contain an error message if the num sequences requested
              //is greater than max allowable. This is still possible because of some 
              //quirks in the UI
              if (data.error_message != "") {
                this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
                return;
              }
              else {
                this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000)
                this.geneService.downloadFileStream(data.file_name, "proteins.fasta")
              }
    
            });
    
        }
    
      }
    

  onDownloadCSVButtonClicked(downloadSelectedRows: boolean): void {

    //if the num genes to be downloaded is greated than maximum allowed
    if (this.numGenes > this.maxGeneDownloadCountCSV) {
      var message = "Can not download more than " + this.maxGeneDownloadCountCSV + " genes in CSV format using Loci. ";
      message = message + "Please try changing your query or contact admin";
      this.sbService.openSnackBar(message, "CLOSE", 5000);
      return;
    }

    if (downloadSelectedRows && this.selection.selected.length === 0) {
      this.sbService.openSnackBar("Please select Genes in the table before attempting to download selected Gene CSV", "CLOSE", 3000)
    }
    //if there are items in the chips or a search string to be searched
    else if (this.searchEvent.searchItems.length > 0 || this.searchEvent.searchString != "") {
      this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000)

      if (downloadSelectedRows) this.searchEvent.selectedItems = this.selection.selected.map(item => item.unique_id)
      else if (!downloadSelectedRows) this.searchEvent.selectedItems = []
      this.geneService.createFilteredGenesCSV(this.searchEvent)
        .subscribe(data => {
          //the result will contain an error message if the num sequences requested
          //is greater than max allowable. This is still possible because of some 
          //quirks in the UI
          if (data.error_message != "") {
            this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
            return;
          }
          else {
            this.geneService.downloadFileStream(data.file_name, "genes.csv")
          }

        });
    }
    else {
      this.sbService.openSnackBar("Your query may have changed. Please click search button before download ..", "CLOSE", 3000);
    }

  }

}

// DataSource - this is the class that the table reads from.
// In other words, if the dataSource needs a value, then that value
// must be located here
export class GenesDataSource implements DataSource<Gene> {

  public geneCount = 0
  private geneSubject = new BehaviorSubject<Gene[]>([]);
  private filteredData: Gene[] = [];
  private unFilteredData: Gene[] = [];

  constructor(private geneService: GenesService, private sbService: SnackbarService) { }

  // Filter through the unFilteredData array and check
  // if the value searched for is located in each item.
  // If it is, then add that to the filtered results - end by updating our subject with those results
  filter(value) {
    if (value.length) {
      this.filteredData = this.unFilteredData.slice().filter((item: Gene) => {
        let searchStr = (item.biotype + item.description + item.species + item.assembly_acc + item.collection + item.length).toLowerCase();
        return searchStr.indexOf(value.toLowerCase()) != -1;
      });
      this.geneSubject.next(this.filteredData)
    }
    else this.geneSubject.next(this.unFilteredData)
  }

  // Returns the subject as an observable
  connect(collectionViewer: CollectionViewer): Observable<Gene[]> {
    return this.geneSubject.asObservable();
  }

  // Close the observable
  disconnect(collectionViewer: CollectionViewer): void {
    this.geneSubject.complete();
    this.geneSubject.complete();
  }

  // This is called whenever the page is changed or a column is sorted. 
  // It makes a call to the server and updates our dataSource
  loadGenes(sortDirection: string,
    sortColumn: string,
    pageIndex: number,
    pageSize: number) {
    
    // Reset the results count to 0
    this.geneService.numGenes = 0

    this.geneService.getGenes(sortDirection, sortColumn,
      pageIndex, pageSize)
      .subscribe((genes: Gene[]) => {
        this.geneService.numGenes = genes["count"]
        this.geneCount = genes["count"]
        this.geneService.geneLimit = genes["limit_value"]

        if (!this.geneService.limitReached && genes["count"] == genes["limit_value"]) {
          this.sbService.openSnackBar(`Large number of results found. Displaying first ` + this.geneService.geneLimit, "CLOSE", 4000)
          this.geneService.limitReached = true
        }

        this.unFilteredData = genes["results"]
        this.geneSubject.next(genes["results"])
      });
  }
}