import { Component, OnInit, Output, EventEmitter, ElementRef } from '@angular/core';
import { Subject } from 'rxjs/Subject';

import { GeneSearchItem, GeneSearchEvent } from "../../models/gene-search-item"


import { LiveSearchGeneService } from '../../services/live-search-gene.service';
import { SnackbarService } from '../../services/snackbar.service';


@Component({
  selector: 'app-my-search-gene',
  templateUrl: './my-search-gene.component.html',
  styleUrls: ['./my-search-gene.component.css']
})
export class MySearchGeneComponent implements OnInit {

  //check out: https://alligator.io/angular/real-time-search-angular-rxjs/ for live search implmentation  
  //also check this : http://4dev.tech/2016/03/tutorial-creating-an-angular2-autocomplete/

  //bound to the text box input
  searchString: string;
  
    results: Array<GeneSearchItem>;
    searchTerm$ = new Subject<string>();
    //number of live search results to be displayed
    numResults = 5;
  
    //true when advanved button is clicked
    advanced = false;
    //true when the checkbox for all public collections checked
    publicChecked = true;
    //true when the checkbox for all private collections checked
    privateChecked = true;
  
    privateCollections = [];
    publicCollections = [];
  
    //arrays that are bound to individual check boxes in advanced settings
    publicCollectionsChecked = [];
    privateCollectionsChecked = [];
  
    public selected: Array<GeneSearchItem>;
  
  
    @Output() searchButtonClicked = new EventEmitter();
    @Output() resetButtonClicked = new EventEmitter();
  
    //element ref is used to handle click events to remove the suggestions when clicked outside
    //http://4dev.tech/2016/03/tutorial-creating-an-angular2-autocomplete/
  
    constructor(private searchService: LiveSearchGeneService, private myElement: ElementRef , private sbService: SnackbarService) { }
  
    ngOnInit() {
  
      //initializing
      this.searchString = "";
      this.selected = [];
      this.results = undefined;
  
      this.searchService.search(this.searchTerm$, this.numResults)
        .subscribe(results => {
          this.results = results.entries;
        });
  
      //getting the collections
      this.searchService.getCollections()
        .subscribe(results => {
          this.publicCollections = results.public;
          this.privateCollections = results.private;
  
          this.initializeCollectionStatus(this.publicCollections, this.publicCollectionsChecked);
          this.initializeCollectionStatus(this.privateCollections, this.privateCollectionsChecked);
        });
    }
  
    //initializes all the collections as selected
    initializeCollectionStatus(collectionsArray, checkArray): void {
  
      var i, n = collectionsArray.length;
      for (i = 0; i < n; ++i) {
        checkArray.push(true);
      }
    }
  
    onSearchButtonClicked(): void {
      //dont  emit anything if the search string is nothing
      if (this.selected.length > 0 || this.searchString != "") {
  
        if (this.searchString) {
          //trimming the leading and trailing whitespaces before sending
          this.searchString.replace(/^\s+|\s+$/g, '');
        }
  
        var myEvent = new GeneSearchEvent();
        myEvent.searchString = this.searchString;
        myEvent.searchItems = this.selected;
  
        //public collections to search
        var i, n = this.publicCollections.length;
        for (i = 0; i < n; ++i) {
          if (this.publicCollectionsChecked[i]) {
            myEvent.publicCollections.push(this.publicCollections[i]);
          }
        }
  
        //private collections to search
        var i, n = this.privateCollections.length;
        for (i = 0; i < n; ++i) {
          if (this.privateCollectionsChecked[i]) {
            myEvent.privateCollections.push(this.privateCollections[i]);
          }
        }
  
  
        this.results = undefined;
        console.log("emit");
        this.searchButtonClicked.emit(myEvent);
  
      }
      else
      {
        this.sbService.openSnackBar("Please enter a keyword to search", "CLOSE", 10000);
      }
      this.results = undefined;
  
    }
  
    onResetButtonClicked(): void {
      this.searchString = "";
      this.results = undefined;
      this.selected = [];
      this.resetButtonClicked.emit();
      this.advanced = false;
    }
  
    onAdvancedButtonClicked(): void {
      if (this.advanced) {
        this.advanced = false;
      }
      else {
        this.advanced = true;
      }
    }
  
    publicAllCheckboxClicked(): void {
      console.log(this.publicChecked);
      if (this.publicChecked) {
        this.setAll(this.publicCollectionsChecked, false)
      }
      else {
        this.setAll(this.publicCollectionsChecked, true)
      }
  
    }
  
    privateAllCheckboxClicked(): void {
      console.log(this.privateChecked);
      if (this.privateChecked) {
        this.setAll(this.privateCollectionsChecked, false)
      }
      else {
        this.setAll(this.privateCollectionsChecked, true)
      }
  
    }
  
    publicOneCheckboxClicked(): void {
      this.publicChecked = false;
    }
  
    privateOneCheckboxClicked(): void {
      this.privateChecked = false;
    }
  
    //sets all elemtns in an array a to value v
    setAll(a, v) {
      var i, n = a.length;
      for (i = 0; i < n; ++i) {
        a[i] = v;
      }
    }
  
    handleClick(event) {
      var clickedComponent = event.target;
      var inside = false;
      do {
        if (clickedComponent === this.myElement.nativeElement) {
          inside = true;
        }
        clickedComponent = clickedComponent.parentNode;
      } while (clickedComponent);
      if (!inside) {
        this.results = undefined;
      }
    }
  
    select(item) {
      this.selected.push(item);
      this.searchString = '';
      this.results = undefined;
    }
  
    remove(item) {
      this.selected.splice(this.selected.indexOf(item), 1);
    }

}
