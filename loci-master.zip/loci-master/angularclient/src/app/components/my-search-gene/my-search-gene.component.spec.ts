import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MySearchGeneComponent } from './my-search-gene.component';

describe('MySearchGeneComponent', () => {
  let component: MySearchGeneComponent;
  let fixture: ComponentFixture<MySearchGeneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MySearchGeneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MySearchGeneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
