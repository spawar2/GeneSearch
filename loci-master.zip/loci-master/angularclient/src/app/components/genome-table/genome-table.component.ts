import { Component, ViewChild, OnInit, ElementRef, AfterViewInit } from '@angular/core';
import { Genome } from '../../models/genome';
import { GenomeService } from '../../services/genomes.service';
import { SnackbarService } from '../../services/snackbar.service'
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { CollectionViewer, DataSource, SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import { debounceTime, distinctUntilChanged, catchError, finalize, tap } from "rxjs/operators";
import { merge } from "rxjs/observable/merge";
import { fromEvent } from 'rxjs/observable/fromEvent';
import { GenomeSearchEvent } from "../../models/genome-search-item"


@Component({
  selector: 'genome-table',
  templateUrl: './genome-table.component.html',
  styleUrls: ['./genome-table.component.css']
})
export class GenomeTableComponent implements OnInit, AfterViewInit {

  // Used to show the page result count
  pageIndex = 0;
  numGenomesPerPage = 10;

  // Column Headers
  displayedColumns = ['select', 'assembly', 'species', 'intraspecies_name', 'collection', 'size', 'numGenes', 'numProteins', 'gc', 'analyze'];

  //datasource for the table
  dataSource: GenomeDataSource | null;

  //maximum number of genomes that can be downloaded as CSV format
  maxGenomeDownloadCountCSV = 0;

  //selected search items (see my-search component) and the search string
  searchEvent: GenomeSearchEvent

  // Initial Values for Row Selection
  initialSelection = [];
  allowMultiSelect = true;
  selection = new SelectionModel<Genome>(this.allowMultiSelect, this.initialSelection);

  get numGenomes() {
    return this.genomeService.numGenomes
  }

  // Necessary for sorting, filtering, and pagination
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('input') input: ElementRef;

  constructor(private genomeService: GenomeService, private router: Router, public sbService: SnackbarService) { };

  ngOnInit(): void {
    this.dataSource = new GenomeDataSource(this.genomeService, this.sbService);
    this.paginator.pageIndex = 0;
    this.genomeService.getMaxDownloadCounts().subscribe(data => {
      this.maxGenomeDownloadCountCSV = data.max_genome_download_count_csv;
    });
    console.log(this.selection)
  }

  // Once the page has initialized
  // we set up the filter, sorting, and pagination
  ngAfterViewInit() {
    fromEvent(this.input.nativeElement, 'keyup')
      .pipe(
      debounceTime(150),
      distinctUntilChanged(),
      tap(() => {
        this.dataSource.filter(this.input.nativeElement.value)
      })
      )
      .subscribe();

    // reset the paginator after sorting
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    // on sort or paginate events, load a new page
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
      // If the sort changes or the page is changed, reload the table
      tap(() => this.loadGenomesPage())
      )
      .subscribe();

    // Once a search event has been added, we load the table
    this.genomeService.searchEventSubject.subscribe(value => {
      this.searchEvent = value
      if (value) {
        this.genomeService.limitReached = false
        this.loadGenomesPage()
      }
    })
  }

  getColumnToSort(columnName): string {
    switch (columnName) {
      case "numGenes":
        return "num_genes"
      case "numProteins":
        return "num_proteins"
      case "assembly":
        return "assembly_acc"
      default:
        return columnName
    }
  }

  loadGenomesPage() {
    let columnNames = this.getColumnToSort(this.sort.active)
    // This will load our dataSource with updated data
    this.dataSource.loadGenomes(
      this.sort.direction,
      columnNames,
      this.paginator.pageIndex,
      this.paginator.pageSize);
  }

  //called when the download button is clicked
  onDownloadButtonClicked(genomeAssemblyAcc, genomeUniqueId): void {
    this.sbService.openSnackBar("Please wait while your sequences are being downloaded ...", "CLOSE", 3000)
    this.genomeService.downloadGenomeFasta(genomeAssemblyAcc);
  }

  onDownloadCSVButtonClicked(downloadSelectedRows: boolean) {
    //if the num genes to be downloaded is greated than maximum allowed
    if (this.numGenomes > this.maxGenomeDownloadCountCSV) {
      var message = "Can not download more than " + this.maxGenomeDownloadCountCSV + " genomes in CSV format using Loci. ";
      message = message + "Please try changing your query or contact admin";
      this.sbService.openSnackBar(message, "CLOSE", 5000);
      return;
    }

    if (downloadSelectedRows && this.selection.selected.length === 0) {
      this.sbService.openSnackBar("Please select Genomes in the table before attempting to download selected Genome CSV", "CLOSE", 3000)
    }
    //if there are items in the chips or a search string to be searched
    else if (this.searchEvent.searchItems.length > 0 || this.searchEvent.searchString != "") {
      this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000)

      if (downloadSelectedRows) this.searchEvent.selectedItems = this.selection.selected.map(item => item.assembly_acc)
      else if (!downloadSelectedRows) this.searchEvent.selectedItems = []
      this.genomeService.createFilteredGenomeCSV(this.searchEvent)
        .subscribe(data => {
          //the result will contain an error message if the num sequences requested
          //is greater than max allowable. This is still possible because of some 
          //quirks in the UI
          if (data.error_message != "") {
            this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
            return;
          }
          else {
            this.genomeService.downloadFile(data.file_name)
          }

        });
    }
    else {
      this.sbService.openSnackBar("Your query may have changed. Please click search button before download ..", "CLOSE", 3000);
    }
  }

}

// DataSource - this is the class that the table reads from.
// In other words, if the dataSource needs a value, then that value
// must be located here
export class GenomeDataSource implements DataSource<Genome> {

  public genomeCount = 0
  private genomeSubject = new BehaviorSubject<Genome[]>([]);
  private filteredData: Genome[] = [];
  private unFilteredData: Genome[] = [];

  constructor(private genomeService: GenomeService, private sbService: SnackbarService) { }

  // Filter through the unFilteredData array and check
  // if the value searched for is located in each item.
  // If it is, then add that to the filtered results - end by updating our subject with those results
  filter(value) {
    if (value.length) {
      this.filteredData = this.unFilteredData.slice().filter((item: Genome) => {
        let searchStr = (item.intraspecies_name + item.size +
          item.species + item.assembly_acc +
          item.collection + item.num_genes + item.num_proteins + item.gc).toLowerCase();
        return searchStr.indexOf(value.toLowerCase()) != -1;
      });
      this.genomeSubject.next(this.filteredData)
    }
    else this.genomeSubject.next(this.unFilteredData)
  }

  // Returns the subject as an observable
  connect(collectionViewer: CollectionViewer): Observable<Genome[]> {
    return this.genomeSubject.asObservable();
  }

  // Close the observable
  disconnect(collectionViewer: CollectionViewer): void {
    this.genomeSubject.complete();
    this.genomeSubject.complete();
  }

  // This is called whenever the page is changed or a column is sorted. 
  // It makes a call to the server and updates our dataSource
  loadGenomes(sortDirection: string,
    sortColumn: string,
    pageIndex: number,
    pageSize: number) {

    // Reset the results count to 0
    this.genomeService.numGenomes = 0

    this.genomeService.getGenomes(sortDirection, sortColumn,
      pageIndex, pageSize)
      .subscribe((genomes: Genome[]) => {
        this.genomeService.numGenomes = genomes["count"]
        this.genomeCount = genomes["count"]
        this.genomeService.genomeLimit = genomes["limit_value"]
        
        if (!this.genomeService.limitReached && genomes["count"] == genomes["limit_value"]) {
          this.sbService.openSnackBar(`Large number of results found. Displaying first ` + this.genomeService.genomeLimit, "CLOSE", 4000)
          this.genomeService.limitReached = true
        }

        this.unFilteredData = genomes["results"]
        this.genomeSubject.next(genomes["results"])
      });
  }
}