import { Component, OnInit,ElementRef, ChangeDetectorRef} from '@angular/core';
import { GenomeSearchItem } from "../../models/genome-search-item"
import { Subject } from 'rxjs/Subject';

import { LiveSearchService } from '../../services/live-search.service';

@Component({
  selector: 'app-live-search',
  host: {
    '(document:click)': 'handleClick($event)',
  },
  templateUrl: './live-search.component.html',
  styleUrls: ['./live-search.component.css']
})
export class LiveSearchComponent implements OnInit {

  //check out: https://alligator.io/angular/real-time-search-angular-rxjs/ for live search implmentation  
  //also check this : http://4dev.tech/2016/03/tutorial-creating-an-angular2-autocomplete/

  //bound to the text box input
  searchString: string;
  
    results: Array<GenomeSearchItem>;
    searchTerm$ = new Subject<string>();
    //number of live search results to be displayed
    numResults = 5;

    public selected: Array<GenomeSearchItem>;
  

  constructor(private searchService: LiveSearchService, private myElement: ElementRef,private cdref: ChangeDetectorRef) { }

  ngOnInit() {
        //initializing
        this.searchString = "";
        this.results = undefined;
    
        this.searchService.search(this.searchTerm$, this.numResults)
          .subscribe(results => {
            this.results = results.entries;
          });
  }

  handleClick(event) {
    var clickedComponent = event.target;
    var inside = false;
    do {
      if (clickedComponent === this.myElement.nativeElement) {
        inside = true;
      }
      clickedComponent = clickedComponent.parentNode;
    } while (clickedComponent);
    if (!inside) {
      this.results = undefined;
    }
  }

  select(item) {
    if(!this.selected){
      this.selected = [];
    }
    this.selected.push(item);
    this.searchString = '';
    this.results = undefined;
  }

  remove(item) {
    this.selected.splice(this.selected.indexOf(item), 1);
    if(this.selected.length == 0){
      this.selected = null;
    }
  }

  getSelected(){
    return this.selected;
  }

    //sets the selected items in the live search component 
    setSelected(gsi: Array<GenomeSearchItem>): void{
      this.selected = gsi;
      //https://stackoverflow.com/questions/35105374/how-to-force-a-components-re-rendering-in-angular-2
      this.cdref.detectChanges();
    }

}
