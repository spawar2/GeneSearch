import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskConfirmationComponent } from './task-confirmation.component';

describe('TaskConfirmationComponent', () => {
  let component: TaskConfirmationComponent;
  let fixture: ComponentFixture<TaskConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
