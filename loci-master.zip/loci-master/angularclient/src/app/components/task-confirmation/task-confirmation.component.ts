import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-confirmation',
  templateUrl: './task-confirmation.component.html',
  styleUrls: ['./task-confirmation.component.css']
})
export class TaskConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
