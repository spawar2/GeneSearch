'use strict';
import { Component, ViewChild, OnInit, ElementRef, AfterViewInit } from '@angular/core';
import { Genome } from '../../models/genome';
import { GenomeService } from '../../services/genomes.service';
import { Router } from '@angular/router';
import { MySearchComponent } from '../my-search/my-search.component';
import { GenomeSearchItem, GenomeSearchEvent } from "../../models/genome-search-item"
import { Subject } from 'rxjs/Subject';
import { MatSnackBar } from '@angular/material';
import { GenomeTableComponent} from '../genome-table/genome-table.component'


@Component({
  selector: 'my-genomes',
  templateUrl: './genomes.component.html',
  styleUrls: ['./genomes.component.css']
})

export class GenomesComponent {

  @ViewChild(GenomeTableComponent)
  private genomeTable: GenomeTableComponent;

  //toggle displaying the table
  showTable = false;


  constructor(private genomeService: GenomeService, private router: Router, public snackBar: MatSnackBar) { };


  //gets the total number of genomes in the collection
  get numGenomes() {
    return this.genomeService.numGenomes == this.genomeService.genomeLimit? `>${this.genomeService.genomeLimit}`: this.genomeService.numGenomes
  }

  onDownloadCSVButtonClicked() {
    let downloadSelectedRows = false
    this.genomeTable.onDownloadCSVButtonClicked(downloadSelectedRows)
  }

  onDownloadSelectedCSVButtonClicked() {
    let downloadSelectedRows = true
    this.genomeTable.onDownloadCSVButtonClicked(downloadSelectedRows)
  }

  //called when the search button is clicked
  onSearchButtonClicked(myEvent: GenomeSearchEvent): void {

    // Here we're adding the search event to the service, so it can be 
    // used in the service and in the table component
    this.genomeService.addSearchEvent(myEvent)

    // Once the table is shown, the table component will initialize with
    // the correct data
    this.showTable = true;

  }

  //called when the reset button is clicked
  onResetButtonClicked(): void {
    this.genomeService.addSearchEvent(undefined);
    this.showTable = false;
  }

}