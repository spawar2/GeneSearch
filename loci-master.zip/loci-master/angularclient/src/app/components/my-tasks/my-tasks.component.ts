import { Component, OnInit, ViewChild, ElementRef, AfterViewInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Subject} from 'rxjs/Subject';
import 'rxjs/add/observable/merge';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';
import { Router,ActivatedRoute } from '@angular/router';
import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import {debounceTime, distinctUntilChanged, catchError, finalize, tap} from "rxjs/operators";
import {merge} from "rxjs/observable/merge";
import {fromEvent} from 'rxjs/observable/fromEvent';


import { MyTask } from '../../models/my-task';

import { MyTasksService } from '../../services/my-tasks.service';


@Component({
  selector: 'app-my-tasks',
  templateUrl: './my-tasks.component.html',
  styleUrls: ['./my-tasks.component.css']
})


export class MyTasksComponent implements OnInit, AfterViewInit {

  //subject that can be triggered to emit new mytask array
  myTaskSubject: Subject<MyTask[]>;
  
  //an observer that can be used in multiple places. It calls the myTaskSubject.next
  myPageObserver: any;

  pageIndex = 0;
  numTasks = 0;
  numTasksPerPage = 10;

  displayedColumns = ['taskName', 'taskType', 'time','taskStatus','taskResults'];
  //datasource for the table
  dataSource: TasksDataSource | null;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('input') input: ElementRef;

  constructor(private tasksService: MyTasksService, private router: Router) { }

  ngOnInit() {
    this.myTaskSubject = new Subject<MyTask[]>();
    this.dataSource = new TasksDataSource(this.tasksService);
    this.paginator.pageIndex = 0;
    this.loadMyTasks()
  }

  ngAfterViewInit() {
    fromEvent(this.input.nativeElement,'keyup')
        .pipe(
            debounceTime(150),
            distinctUntilChanged(),
            tap(() => {
                this.dataSource.filter(this.input.nativeElement.value)
            })
        )
        .subscribe();

    // reset the paginator after sorting
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    // on sort or paginate events, load a new page
    merge(this.sort.sortChange, this.paginator.page)
    .pipe(
        tap(() => this.loadMyTasks())
    )
    .subscribe();
  }

  getColumnToSort(columnName): string {
    switch (columnName) {
      case "taskName":
        return "task_name" 
      case "taskResults":
        return "task_results"
      case "time":
        return "enqueue_date"
      case "taskStatus":
        return "status"
      case "taskType":
        return "task_type"
      default:
        return columnName
    }
  }

  loadMyTasks() {
    let columnNames = this.getColumnToSort(this.sort.active)
    this.dataSource.loadMyTasks(
        this.sort.direction,
        columnNames,
        this.paginator.pageIndex,
        this.paginator.pageSize);
  }

  onRefreshButtonClicked(): void {
    this.loadMyTasks();
  }

}

export class TasksDataSource extends DataSource<MyTask> {

  public taskCount = 0
  private myTaskSubject = new BehaviorSubject<MyTask[]>([]);
  private filteredData: MyTask[] = [];
  private unFilteredData: MyTask[] = [];

  constructor(private myTaskService: MyTasksService) {super();}

  filter(value) {
    if (value.length) {
      this.filteredData = this.unFilteredData.slice().filter((item: MyTask) => {
        let searchStr = (item.status + item.task_id + 
                        item.task_name + item.task_type).toLowerCase();
        return searchStr.indexOf(value.toLowerCase()) != -1;
      });
      this.myTaskSubject.next(this.filteredData)
    }
    else this.myTaskSubject.next(this.unFilteredData)
  }

  connect(collectionViewer: CollectionViewer): Observable<MyTask[]> {
    return this.myTaskSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.myTaskSubject.complete();
    this.myTaskSubject.complete();
  }

  loadMyTasks(sortDirection: string, 
            sortColumn: string, 
            pageIndex: number, 
            pageSize: number) {

    this.myTaskService.getTasks(sortDirection, sortColumn,
                                  pageIndex, pageSize)
    .subscribe((myTasks: MyTask[]) => {
      this.myTaskService.numTasks = myTasks["count"]
      this.taskCount = myTasks["count"]
      this.unFilteredData = myTasks["tasks"]
      let tasks = myTasks["tasks"]
      for (let i = 0; i < tasks.length; i++){
        let enqDate = tasks[i].enqueue_date;
        // replaces all occurances of "-" with "/". need to be done to work with firefox
        //https://stackoverflow.com/questions/21984406/error-while-converting-date-string-to-date-object-in-firefox/21984717#21984717
        enqDate = enqDate.replace(/-/g,'/');  
        let myDate =  new Date(enqDate);
        tasks[i].enqueue_date = myDate.toLocaleString();
      }
      this.myTaskSubject.next(tasks)
    });
  } 
}
