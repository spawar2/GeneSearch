import { Component, ViewChild } from '@angular/core';
import { GenesService } from '../../services/genes.service';
import { SnackbarService } from '../../services/snackbar.service'
import { Router } from '@angular/router';
import { GeneSearchEvent } from "../../models/gene-search-item"
import { GeneTableComponent} from '../gene-table/gene-table.component'


@Component({
  selector: 'app-genes',
  templateUrl: './genes.component.html',
  styleUrls: ['./genes.component.css']
})
export class GenesComponent {

  @ViewChild(GeneTableComponent)
  private geneTable: GeneTableComponent;

  //toggle displaying the table
  showTable = false;

  get numGenes() {
    return this.geneService.numGenes == this.geneService.geneLimit? `>${this.geneService.geneLimit}`: this.geneService.numGenes
  }

  constructor(private geneService: GenesService, private router: Router, public sbService: SnackbarService) { };

  onDownloadAllFilteredSeqsButtonClicked() {
    this.geneTable.onDownloadAllFilteredSeqsButtonClicked()
  }

  onDownloadSelectedSeqsButtonClicked() {
    this.geneTable.onDownloadSelectedSeqsButtonClicked();
  }

  onDownloadSelectedCSVButtonClicked() {
    let downloadSelectedRows = true
    this.geneTable.onDownloadCSVButtonClicked(downloadSelectedRows)
  }

  onDownloadCSVButtonClicked() {
    let downloadSelectedRows = false
    this.geneTable.onDownloadCSVButtonClicked(downloadSelectedRows)
  }
  
  //called when the search button is clicked
  onSearchButtonClicked(myEvent: GeneSearchEvent): void {

    // Here we're adding the search event to the service, so it can be 
    // used in the service and in the table component
    this.geneService.addSearchEvent(myEvent)

    // Once the table is shown, the table component will initialize with
    // the correct data
    this.showTable = true;

  }

  //called when the reset button is clicked
  onResetButtonClicked(): void {
    this.geneService.addSearchEvent(undefined);
    this.showTable = false;
  }


}