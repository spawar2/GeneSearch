import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomBlastDbComponent } from './custom-blast-db.component';

describe('CustomBlastDbComponent', () => {
  let component: CustomBlastDbComponent;
  let fixture: ComponentFixture<CustomBlastDbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomBlastDbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomBlastDbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
