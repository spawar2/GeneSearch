import { Component, OnInit, ViewChild } from '@angular/core';
import {LiveSearchComponent} from '../live-search/live-search.component';
import {GenomeSearchItem} from '../../models/genome-search-item'

@Component({
  selector: 'app-custom-blast-db',
  templateUrl: './custom-blast-db.component.html',
  styleUrls: ['./custom-blast-db.component.css']
})

export class CustomBlastDbComponent implements OnInit {
  
  //to talk to the live search component
  //https://angular.io/guide/component-interaction#parent-calls-an-viewchild
  @ViewChild(LiveSearchComponent)
  private liveSearchComponent: LiveSearchComponent;

  constructor() { }

  ngOnInit() {
  }

  //returns the selected genomes
  getSelected(){
    return this.liveSearchComponent.getSelected();
  }

  //sets the selected items in the live search component 
  setSelected(gsi: GenomeSearchItem[]): void{
    this.liveSearchComponent.setSelected(gsi);
  }

}
