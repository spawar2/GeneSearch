import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, ParamMap, Router, NavigationEnd } from '@angular/router';
import { BlastResultService } from '../../services/blast-result.service';
import { BlastHit } from '../../models/blast-hit';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { CollectionViewer, DataSource, SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatSelect } from '@angular/material';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/mergeMap';
import { SafeHTML } from '../../pipes/safehtml.pipe'
import { SingleSequenceDownloadEvent } from "../../models/download"
import * as FileSaver from 'file-saver';
import { SnackbarService } from '../../services/snackbar.service'
import { debounceTime, distinctUntilChanged, catchError, finalize, tap } from "rxjs/operators";
import { merge } from "rxjs/observable/merge";
import { fromEvent } from 'rxjs/observable/fromEvent';


export interface Query {
  name: string;
  num: number;
}


@Component({
  selector: 'app-blast-result',
  templateUrl: './blast-result.component.html',
  styleUrls: ['./blast-result.component.css']
})
export class BlastResultComponent implements OnInit, AfterViewInit {

  //subject that can be triggered to emit new BlastHIt array
  myHitSubject: Subject<BlastHit[]>;

  //this is the full array. A subset is emitted by themyHitSubject
  hits: BlastHit[];

  displayedColumns = ['select', 'seqid', 'desc', 'maxscore', 'evalue', 'querycov', 'percid', 'download'];
  //datasource for the table
  dataSource: HitDataSource | null;

  task_id: string;

  //for graph overview
  hsp_data: any;
  queryName = "N/A";
  queryDisplay = "Loading..."
  queryLen = 0;

  html_results = "Loading...";
  //id cannot contain ":" character
  //https://stackoverflow.com/questions/37270787/uncaught-syntaxerror-failed-to-execute-queryselector-on-document

  queries: Query[] = [
    { name: 'query_0', num: 0 },
  ];

  get numHits() {
    return this.blastResultService.numHits
  }

  //getting access to elements in html
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('input') input: ElementRef;
  @ViewChild(MatSelect) querySelector: MatSelect;

  pageIndex = 0;
  numHitsPerPage = 10;

  //initializing maximum number of hits that can be downloaded. This number is got from server
  maxHitDownloadCount = 0;
  //max downloadable hits in csv format
  maxHitDownloadCountCSV = 0;

  //query number in multi sequennce blast
  query_num = 0;
  //this is the default query number selected when page loads. see html file
  defaultQueryNum = 0;

  // Initial Values for Row Selection
  selectedItems = []
  initialSelection = [];
  allowMultiSelect = true;
  selection = new SelectionModel<BlastHit>(this.allowMultiSelect, this.initialSelection);

  constructor(private router: Router, private route: ActivatedRoute,
    private blastResultService: BlastResultService,
    private cd: ChangeDetectorRef,
    public sbService: SnackbarService) { }

  ngOnInit() {

    this.myHitSubject = new Subject<BlastHit[]>();
    // this.dataSource = new HitDataSource(this.myHitSubject);
    this.dataSource = new HitDataSource(this.blastResultService);

    //maximum number of hits that can be downloaded
    this.blastResultService.getMaxDownloadCounts().subscribe(data => {
      this.maxHitDownloadCount = data.max_hit_download_count;
      this.maxHitDownloadCountCSV = data.max_hit_download_count_csv;
    });

    this.router.events.subscribe(s => {
      if (s instanceof NavigationEnd) {
        const tree = this.router.parseUrl(this.router.url);
        if (tree.fragment) {
          const element = document.querySelector("#" + tree.fragment);
          if (element) { element.scrollIntoView(); }
        }
      }
    });

    //getting task id from params
    this.route.params
      .map(params => params['task_id'])
      .switchMap(task_id => {
        this.task_id = task_id;

        //getting hsp info from task id
        return this.blastResultService.getBlastHTMLResults(this.task_id, this.query_num);
      })
      .switchMap(data => {

        this.handleHTMLData(data);
        //getting hsp info from task id
        return this.blastResultService.getBlastHspInfo(this.task_id, this.query_num);
      }).switchMap(data => {
        //doing stuff with hsp data obtained
        this.handleHSPData(data);

        return this.blastResultService.getBlastQueryInfo(this.task_id);
      })
      .switchMap(data => {

        //handle query names
        this.handleQueriesData(data);

        //getting hit info from task id
        return this.blastResultService.getBlastHitInfo(this.task_id, this.query_num);
      }).subscribe(() => {
        return this.loadBlastTableResults()
      })


  }

  ngAfterViewInit() {
    //setting focus on the query selector 
    //https://stackoverflow.com/questions/44479457/angular-2-4-set-focus-on-input-element
    //https://blog.angularindepth.com/everything-you-need-to-know-about-the-expressionchangedafterithasbeencheckederror-error-e3fd9ce7dbb4
    this.querySelector.focus();
    this.cd.detectChanges();
    fromEvent(this.input.nativeElement, 'keyup')
      .pipe(
      debounceTime(150),
      distinctUntilChanged(),
      tap(() => {
        this.dataSource.filter(this.input.nativeElement.value)
      })
      )
      .subscribe();

    // reset the paginator after sorting
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    // on sort or paginate events, load a new page
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
      tap(() => this.loadBlastTableResults())
      )
      .subscribe();
  }

  getColumnToSort(columnName): string {
    switch (columnName) {
      case "seqid":
        return "id"
      case "percid":
        return "percent_id"
      case "querycov":
        return "query_coverage"
      case "maxscore":
        return "max_score"
      default:
        return columnName
    }
  }

  loadBlastTableResults() {
    let columnNames = this.getColumnToSort(this.sort.active)
    this.dataSource.loadResultTableData(
      this.task_id,
      this.query_num,
      this.sort.direction,
      columnNames,
      this.paginator.pageIndex,
      this.paginator.pageSize
    )
  }

  //https://stackoverflow.com/questions/36101756/angular2-routing-with-hashtag-to-page-anchor
  //look at answer by ali bari
  onAnchorClick() {
    this.route.fragment.subscribe(f => {
      const element = document.querySelector("#" + f)
      if (element) element.scrollIntoView()
    });
  }


  //called when the download button is clicked
  onDownloadButtonClicked(hitID, hitDB, hitDBtype): void {

    var ssDownEvent = new SingleSequenceDownloadEvent();
    ssDownEvent.seqDB = hitDB;
    ssDownEvent.seqID = hitID;

    this.sbService.openSnackBar("Please wait while your sequences are being downloaded ...", "CLOSE", 3000)

    this.blastResultService.downloadSingleSequence(ssDownEvent)
      .subscribe(fileData => { FileSaver.saveAs(fileData, "hit_sequences.txt"); });
  }

  onDownloadFastaAllHitsClicked(): void {

    if (this.numHits > this.maxHitDownloadCount) {
      var message = "Can not download more than " + this.maxHitDownloadCount + " hits in fasta format using Loci. ";
      message = message + "Please contact admin for more help";
      this.sbService.openSnackBar(message, "CLOSE", 5000);
      return;
    }
    this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000);
    this.blastResultService.createBlastHitFasta(this.task_id, this.query_num)
      .subscribe(data => {
        //the result will contain an error message if the num sequences requested
        //is greater than max allowable
        if (data.error_message != "") {
          this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
          return;
        }
        else {
          this.blastResultService.downloadFileStream(data.file_name, "hit_sequences.txt")
        }

      });

  }

  onDownloadCSVButtonClicked(downloadSelectedRows: boolean): void {

    //if the num genes to be downloaded is greated than maximum allowed
    if (this.numHits > this.maxHitDownloadCountCSV) {
      var message = "Can not download more than " + this.maxHitDownloadCountCSV + " hits in csv format using Loci. ";
      message = message + "Please try changing your query or contact admin";
      this.sbService.openSnackBar(message, "CLOSE", 5000);
      return;
    }

    if (downloadSelectedRows && this.selection.selected.length === 0) {
      this.sbService.openSnackBar("Please select Blast Hits in the table before attempting to download selected Blast Hit CSV", "CLOSE", 3000)
    } else {
      this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000)

      if (downloadSelectedRows) this.selectedItems = this.selection.selected.map(item => item.id)
      else if (!downloadSelectedRows) this.selectedItems = []
      this.blastResultService.createBlastHitCSV(this.task_id, this.query_num, this.selectedItems)
        .subscribe(data => {
          //the result will contain an error message if the num sequences requested
          //is greater than max allowable. This is still possible because of some 
          //quirks in the UI
          if (data.error_message != "") {
            this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
            return;
          }
          else {
            this.blastResultService.downloadFileStream(data.file_name, "hits.csv")
          }

        });
    }
  }

  //called when a new query is selected in multi sequence blast
  onQuerySelected(query_num): void {
    this.query_num = query_num;

    //getting new data
    this.blastResultService.getBlastHTMLResults(this.task_id, this.query_num)
      .subscribe(data => { this.handleHTMLData(data); });

    this.blastResultService.getBlastHspInfo(this.task_id, this.query_num)
      .subscribe(data => { this.handleHSPData(data); });

    //resetting paginator
    this.paginator.pageIndex = 0;
    this.paginator.pageSize = 10;
    this.pageIndex = 0;
    this.numHitsPerPage = 10;

    //resetting selections
    this.selectedItems = []
    this.initialSelection = [];
    this.selection.clear();

    // LOOK HERE TODO!!!!!!

    // this.blastResultService.getBlastHitInfo(this.task_id, this.query_num)
    //   .subscribe(data => { this.handleHitsData(data); });


  }

  handleHTMLData(data) {
    this.html_results = data['html_results']
  }

  handleHSPData(data) {
    this.hsp_data = data;
    if (this.hsp_data) {
      this.queryLen = this.hsp_data.query_len;
      this.queryName = this.hsp_data.query;
      this.queryDisplay = "Query: " + this.shortenQueryName(this.queryName) + "  (Length: " + this.queryLen + ")"
    }
  }

  handleHitsData(data) {
    this.hits = data.hits_data;
    // this.numHits = this.hits.length;

    const copy = this.hits.slice();
    const startIndex = this.pageIndex * this.numHitsPerPage;
    const subset = copy.splice(startIndex, this.numHitsPerPage);
    this.myHitSubject.next(subset);

  }

  handleQueriesData(data) {
    const my_queries = data.queries_data;
    const num_queries = my_queries.length;

    //resetting the queries array
    this.queries = [];

    var i;
    for (i = 0; i < num_queries; i++) {
      var short_name = this.shortenQueryName(my_queries[i]);
      var obj = { name: short_name, num: i };
      this.queries[i] = obj;
    }
  }

  handlePageData(pageData) {
    this.pageIndex = pageData.pageIndex;
    this.numHitsPerPage = pageData.pageSize;

    const copy = this.hits.slice();
    const startIndex = this.pageIndex * this.numHitsPerPage;
    const subset = copy.splice(startIndex, this.numHitsPerPage);
    this.myHitSubject.next(subset);
  }

  //shrortens query name to first fifty characters
  shortenQueryName(query_name: string) {

    if (query_name.length > 50) {
      return query_name.substring(0, 50) + "...";
    }
    else {
      return query_name;
    }
  }

  onDownloadSelectedSeqsButtonClicked() {
    //getting the selected proteins
    const selectedHits = this.selection.selected;

    //if there are no selected items
    if (selectedHits.length == 0) {
      this.sbService.openSnackBar("No items selected", "CLOSE", 5000);
    }
    else {
      const numSelected = selectedHits.length;
      //object array to store the sequence id and the database name (assembly accession)
      var hit_obj_array = [];
      for (var i = 0; i < numSelected; i++) {
        hit_obj_array[i] = { unique_id: selectedHits[i].id, locidb: selectedHits[i].locidb };
      }

      this.blastResultService.createSelectedHitsFasta(hit_obj_array)
        .subscribe(data => {
          //the result will contain an error message if the num sequences requested
          //is greater than max allowable. This is still possible because of some 
          //quirks in the UI
          if (data.error_message != "") {
            this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
            return;
          }
          else {
            this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000)
            this.blastResultService.downloadFileStream(data.file_name, "hit_sequences.fasta")
          }

        });

    }

  }



}

//datasource for the table
export class HitDataSource extends DataSource<BlastHit> {

  public hitCount = 0
  private blastHitsSubject = new BehaviorSubject<BlastHit[]>([]);
  private filteredData: BlastHit[] = [];
  private unFilteredData: BlastHit[] = [];

  constructor(private blastResultService: BlastResultService) { super(); }

  filter(value) {
    if (value.length) {
      this.filteredData = this.unFilteredData.slice().filter((item: BlastHit) => {
        let searchStr = (item.desc + item.evalue +
          item.internal_hit_name + item.max_score +
          item.percent_id + item.query_coverage).toLowerCase();
        return searchStr.indexOf(value.toLowerCase()) != -1;
      });
      this.blastHitsSubject.next(this.filteredData)
    }
    else this.blastHitsSubject.next(this.unFilteredData)
  }

  connect(collectionViewer: CollectionViewer): Observable<BlastHit[]> {
    return this.blastHitsSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.blastHitsSubject.complete();
    this.blastHitsSubject.complete();
  }

  loadResultTableData(task_id: string,
    query_num: number,
    sortDirection: string,
    sortColumn: string,
    pageIndex: number,
    pageSize: number) {

    // LOOK HERE TODO!!!!!!!
    this.blastResultService.getBlastHitInfo(task_id, query_num, sortDirection, sortColumn,
      pageIndex, pageSize)
      .subscribe((blastHits: BlastHit[]) => {
        this.blastResultService.numHits = blastHits["count"]
        this.hitCount = blastHits["count"]
        this.unFilteredData = blastHits["hits_data"]
        this.blastHitsSubject.next(blastHits["hits_data"])
      });
  }
}

