import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlastResultComponent } from './blast-result.component';

describe('BlastResultComponent', () => {
  let component: BlastResultComponent;
  let fixture: ComponentFixture<BlastResultComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlastResultComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlastResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
