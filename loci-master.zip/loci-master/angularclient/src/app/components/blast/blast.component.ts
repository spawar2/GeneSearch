import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { BlastService } from '../../services/blast.service';
import {SnackbarService} from '../../services/snackbar.service'
import { BlastJob } from '../../models/blast-job'
import { MatSnackBar } from '@angular/material';
import { CustomBlastDbComponent } from '../custom-blast-db/custom-blast-db.component';
import { GenomeSearchItem } from '../../models/genome-search-item'

@Component({
  selector: 'app-blast',
  templateUrl: './blast.component.html',
  styleUrls: ['./blast.component.css']
})
export class BlastComponent implements OnInit {

  //this is bound to the text box. can be a fasta sequence or sequence ID
  inputData = "";
  blastJob: BlastJob;

  task_name = "";
  program = "";

  //is custom protein db checkbox checked
  customProtein = false;
  //is custom gene db checkbox checked
  customGene = false;

  //is custom gene db checkbox checked
  customContig = false;

  //predefined nucleotide blast database
  preNuclDbLabels = [];
  preProtDbLabels = [];

  //predefined nucleotide blast database
  preNuclDbs = [];
  preProtDbs = [];

  //this is an array of objects. In case of preformatted databases it will have the form
  //[{db:"all_public_proteins"},{db:"ncbi_nr"}]
  blast_dbs = [];

  //this will eitther be custom or preformatted
  blast_db_type = "";

  //index of the selected Tab
  selectedTab = 0;


  //toggles for checkboxes
  preNuclDbsToggle = [false, false, false, false, false];
  preProtDbsToggle = [false, false, false];

  //blastp and blastx disabled
  pxDisabled = true;
  //tblastn and blastn disabled
  tnDisabled = true;


  //these variables are used when a sequence id is used as blast query
  assembly_acc: string;
  query_type: string;
  query_id: string;

  //maximum number of queries that can be blasted
  maxQueryCount = 0;

  //placeholder text for the text box
  plHolder = "Enter query sequences in FASTA format ...";


  //to talk to the custom-blast0db component
  //https://angular.io/guide/component-interaction#parent-calls-an-viewchild
  @ViewChild(CustomBlastDbComponent)
  private customComponent: CustomBlastDbComponent;


  constructor(private blastService: BlastService,
    private router: Router,
    private route: ActivatedRoute,
    public sbService: SnackbarService
  ) { }

  ngOnInit() {

    //getting preformatted blast databases and their labels
    this.blastService.getBlastDatabases().subscribe(data => {

      this.preNuclDbs = data.nt_dbs;
      this.preProtDbs = data.prot_dbs;

      this.preNuclDbLabels = data.nt_labels;
      this.preProtDbLabels = data.prot_labels;

    });

    this.route.params.subscribe(param => {
      this.assembly_acc = param['assembly_acc'];
      this.query_id = param['query_id'];
      this.query_type = param['query_type'];

      //either a protien or gene blast
      if (this.query_id) {
        if (this.query_id.includes("&")) {

        }
        this.inputData = "QUERY=" + this.query_id;
      }
      else {
        //if blast_db parameter is not null
        if (this.assembly_acc) {
          console.log(this.assembly_acc);
          let obj = new GenomeSearchItem();
          obj["name"] = this.assembly_acc;
          obj["type"] = 'assembly_acc';
          obj["tax_id"] = "";
          this.setSelected([obj]);

          this.selectedTab = 1;
        }

      }
    });

    //getting the maximum number queries that can be blasted 
    this.blastService.getMaxQueryCount().subscribe(data => {
      this.maxQueryCount = data.max_query_count;
      this.plHolder = "Enter query sequences (Max. " + this.maxQueryCount + ") in FASTA format ...";
    });

  }

  //sets the selected items in the live search component through custom-db component
  setSelected(gsi: GenomeSearchItem[]): void {
    this.customComponent.setSelected(gsi);
  }

  onResetButtonClicked(): void {
    this.resetAll();
  }

  resetAll(): void {

    this.inputData = "";
    this.blastJob = undefined;

    this.task_name = "";
    this.program = "";

    this.customProtein = false;
    this.customGene = false;
    this.customContig = false;

    this.blast_dbs = [];
    this.blast_db_type = "";

    this.selectedTab = 0;


    this.preNuclDbsToggle = [false, false, false, false, false];
    this.preProtDbsToggle = [false, false, false];


    this.pxDisabled = true;
    this.tnDisabled = true;

    this.assembly_acc = undefined;
    this.query_type = undefined;
    this.query_id = undefined;

  }

  //called when the blast button is clicked
  onBlastButtonClicked(): void {

    this.blastJob = new BlastJob();

    //building the blast job object

    this.blastJob.input = this.inputData;
    if (this.inputData) {
      if (this.inputData.substring(0, 6).toUpperCase().startsWith("QUERY=")) {
        this.blastJob.inputType = "seq_id";

        this.blastJob.assembly_acc = this.assembly_acc ? this.assembly_acc : "";
        this.blastJob.seq_type = this.query_type ? this.query_type : "";
      }
      else {
        //checking the number of sequences
        var seqCount = this.getSeqCount(this.inputData);

        if(seqCount > this.maxQueryCount){
          this.sbService.openSnackBar("You can blast a maximum of " + this.maxQueryCount +  " sequences","CLOSE",5000);
          return;
        }

        this.blastJob.inputType = 'seq';
        this.blastJob.assembly_acc = "";
        this.blastJob.seq_type = "";
      }
    }

    this.blastJob.program = this.program;
    this.blastJob.task_name = this.task_name;

    //re initializing
    this.blast_dbs = [];

    //if not a custom database. i.e it is  a preformatted db
    if (!this.customProtein && !this.customGene && !this.customContig) {

      this.blast_db_type = "preformatted";

      //at any point either protein or nucleotide databases are selected so the following logic should work

      //creating a list of nucleotide dbs
      var i, n = this.preNuclDbs.length;
      for (i = 0; i < n; ++i) {
        if (this.preNuclDbsToggle[i]) {
          this.blast_dbs.push({ db: this.preNuclDbs[i] });
        }
      }

      //creating a list of protein dbs
      var i, n = this.preProtDbs.length;
      for (i = 0; i < n; ++i) {
        if (this.preProtDbsToggle[i]) {
          this.blast_dbs.push({ db: this.preProtDbs[i] });
        }
      }


    }
    else {
      //code for custom db
      this.blast_db_type = "custom";

      //this is set only in case of custom databases. For preformatted databases, the seq type can br
      //inferred using the blast program selected.
      //for customdb, this is set to "protien", "gene", "genome", "gene+genome"
      var blast_seq_type = "";

      if (this.customContig && this.customGene) {
        blast_seq_type = "gene+genome";
      } else {
        if (this.customContig) {
          blast_seq_type = "genome";
        } else {
          if (this.customGene) {
            blast_seq_type = "gene"
          } else {
            if (this.customProtein) {
              blast_seq_type = "protein"
            }
          }
        }
      }

      var selected_items = this.customComponent.getSelected();
      if (selected_items) {
        var i, n = selected_items.length;
        for (i = 0; i < n; ++i) {
          this.blast_dbs.push(selected_items[i]);
        }
      }


    }

    this.blastJob.blast_dbs = this.blast_dbs;
    this.blastJob.blast_db_type = this.blast_db_type;
    this.blastJob.blast_seq_type = blast_seq_type;

    if (!this.isFormValid()) {
      this.sbService.openSnackBar("Please make sure you have entered a query sequence, a database,  and a program.", "CLOSE", 10000);
      return;
    }

    this.blastService.runBlast(this.blastJob).subscribe(
      task_index => {
        this.router.navigateByUrl('/taskconfirmation');
      }
    );

  }

  //called when custom prot db clicked
  onProteinCustomClicked(): void {
    if (!this.customProtein) {

      //deselecting all nucleotide databases
      this.setAll(this.preNuclDbsToggle, false);

      //deselecting all protein databases
      this.setAll(this.preProtDbsToggle, false);

      //deselecting custom gene database
      this.customGene = false;

      //deselecting custom gene database
      this.customContig = false;

      //togging program radio buttons
      this.pxDisabled = false;
      this.tnDisabled = true;

      //updating the selected radio button
      this.updateProgram("prot");


    }
    else {
      //togging program radio buttons
      this.pxDisabled = true;
      this.tnDisabled = true;
    }
  }

  //called when custom gene db clicked
  onGeneCustomClicked(): void {
    if (!this.customGene) {
      //deselecting all protein databases
      this.setAll(this.preProtDbsToggle, false);

      //deselecting all nucleotide databases
      this.setAll(this.preNuclDbsToggle, false);

      //deselecting custom protein database
      this.customProtein = false;


      //togging program radio buttons
      this.pxDisabled = true;
      this.tnDisabled = false;

      //updating the selected radio button
      this.updateProgram("nucl");

    }
    else {
      if (!this.customContig) {
        //togging program radio buttons
        this.pxDisabled = true;
        this.tnDisabled = true;
      }

    }
  }

  //called when custom nucleotide db clicked
  onContigCustomClicked(): void {
    if (!this.customContig) {
      //deselecting all protein databases
      this.setAll(this.preProtDbsToggle, false);

      //deselecting all nucleotide databases
      this.setAll(this.preNuclDbsToggle, false);

      //deselecting custom protein database
      this.customProtein = false;


      //togging program radio buttons
      this.pxDisabled = true;
      this.tnDisabled = false;

      //updating the selected radio button
      this.updateProgram("nucl");

    }
    else {
      //if the gene check box is also unchecked, disable the buttons
      if (!this.customGene) {
        //togging program radio buttons
        this.pxDisabled = true;
        this.tnDisabled = true;
      }

    }
  }

  //called when a predefined nucl database clicked
  onNuclDbClicked(): void {

    //deselecting all protein databases
    this.setAll(this.preProtDbsToggle, false);

    //deselecting custom protein database
    this.customProtein = false;

    //deselecting custom nucleotde database
    this.customGene = false;

    //deselecting custom nucleotde database
    this.customContig = false;


    //togging program radio buttons
    this.pxDisabled = true;
    this.tnDisabled = false;

    //updating the selected radio button
    this.updateProgram("nucl");

  }

  //called when a predefined prot database clicked
  onProtDbClicked(): void {

    //deselecting all nucl databases
    this.setAll(this.preNuclDbsToggle, false);

    //deselecting custom protein database
    this.customProtein = false;

    //deselecting custom gene database
    this.customGene = false;

    //deselecting custom gene database
    this.customContig = false;

    //togging program radio buttons
    this.pxDisabled = false;
    this.tnDisabled = true;

    //updating the selected radio button
    this.updateProgram("prot");

  }

  //sets all elemtns in an array a to value v
  setAll(a, v) {
    var i, n = a.length;
    for (i = 0; i < n; ++i) {
      a[i] = v;
    }
  }

  //logic to update program. This will control which radio button is selected
  updateProgram(dbtype): void {
    if (dbtype === "prot") {
      if (!(this.program === "blastp" || this.program === "blastx")) {
        this.program = "";
      }
    }
    if (dbtype === "nucl") {
      if (!(this.program === "blastn" || this.program === "blastn")) {
        this.program = "";
      }
    }

  }

  //returns true if all the information required for submitting a blast job is available
  //we need a sequence, a database, and a program
  isFormValid(): boolean {

    //if the query sequence is null return false
    if (this.inputData == "") {
      return false;
    }
    //if program is null return false
    if (this.program == "") {
      return false;
    }

    //blast db type shoudl be preformatted or custom
    if (this.blast_db_type == "") {
      return false;
    }

    //at least one database selected
    if (this.blast_dbs.length == 0) {
      return false;
    }

    return true;

  }



  //getting the number of fasta sequences in the text box
  getSeqCount(seq: string): number {
    var array = seq.split("\n");
    var i =0;
    var count = 0;
    for (i =0; i< array.length; i++){
      if(array[i].startsWith(">")){
        count = count + 1;
      }
    }
    return count;

  }


}
