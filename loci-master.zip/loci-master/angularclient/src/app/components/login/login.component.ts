import { Component, OnInit } from '@angular/core';
import {MatSnackBar} from '@angular/material';
import {Router} from '@angular/router'; 
import {Observable} from "rxjs";
import {AuthenticationService} from '../../services/authentication.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email: string = ''
  password: string = ''
  checkEmailRegex = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/

  constructor(private auth: AuthenticationService,
              private router: Router,
              private snackBar: MatSnackBar){}

  ngOnInit() {
    /* 
      Refs Github Issue 15 - https://github.com/Karyosoft/loci/issues/15
      We want users to be prevented from going to the dashboard if they hit the back
      button and it took them back to the login screen. In order to do this, we need to log the
      user out so they are not granted access to the dashboard. 
      We log the user out when the page loads (onInit).
    */
    this.auth.logUserOut()
  }

  enterKeyLogin(e) {
    if (e.keyCode === 13) {
      this.login()
    }
  }

  login() {
    if (this.email && this.password) {
      let emailPassesTest = this.checkEmailRegex.test(this.email)

      if (emailPassesTest) {

        // User data to be sent to the 
        // service
        let userInfo = {
          email: this.email,
          password: this.password
        }

        this.auth.loginUser(userInfo)
            .catch(e => {
              if (e.status === 401) {
                // If the user enters the wrong email or password
                this.snackBar.open('Incorrect Email or Password', 'Close',{duration:5000});
                  return Observable.throw('Unauthorized');
              }
            })
            .subscribe(
              res => {
                // If everything went well, set userIsLoggedIn to true in authentication.service
                // and redirect the user to the dashboard, which is now activated.
                if (res.success === "true") {
                  // When the user is successfully logged in, we'll want to 
                  // make a call to get their name to display in the navbar
                  this.auth.getUser()
                }

              }
            )

      } else {
        // If user enters an inproper email
        this.snackBar.open('Emails must contain an @ and .', 'Close',{duration:5000});
      }

    }
    else {
      // If user fails to enter an email and password
      this.snackBar.open('Please enter an email and password', 'Close');
    }
  }

}