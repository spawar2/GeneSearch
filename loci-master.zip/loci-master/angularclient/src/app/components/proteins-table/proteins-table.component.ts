import { Component, ViewChild, OnInit, ElementRef, AfterViewInit } from '@angular/core';
import { Protein } from '../../models/protein';
import { ProteinsService } from '../../services/proteins.service';
import { SnackbarService } from '../../services/snackbar.service'
import { Router } from '@angular/router';
import { ProteinSearchEvent } from "../../models/protein-search-item"
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { CollectionViewer, DataSource, SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import { debounceTime, distinctUntilChanged, catchError, finalize, tap } from "rxjs/operators";
import { merge } from "rxjs/observable/merge";
import { fromEvent } from 'rxjs/observable/fromEvent';
import * as FileSaver from 'file-saver';
import { SingleSequenceDownloadEvent } from "../../models/download"


@Component({
  selector: 'protein-table',
  templateUrl: './proteins-table.component.html',
  styleUrls: ['./proteins-table.component.css']
})
export class ProteinTableComponent implements OnInit, AfterViewInit {

  // Used to show the page result count
  pageIndex = 0;
  numProteinsPerPage = 10;

  displayedColumns = ['select', 'id', 'desc', 'species', 'assembly', 'collection', 'length', 'analyze'];

  //datasource for the table
  dataSource: ProteinDataSource | null;

  // Necessary for sorting, filtering, and pagination
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('input') input: ElementRef;

  //selected search items (see my-search component) and the search string
  searchEvent: ProteinSearchEvent

  // Initial Values for Row Selection
  initialSelection = [];
  allowMultiSelect = true;
  selection = new SelectionModel<Protein>(this.allowMultiSelect, this.initialSelection);

  //maximum number of proteins that can be downloaded as fasta format
  maxProteinDownloadCount = 0;

  //maximum number of proteins that can be downloaded as CSV format
  maxProteinDownloadCountCSV = 0;

  get numProteins() {
    return this.proteinService.numProteins
  }

  constructor(private proteinService: ProteinsService, private router: Router, public sbService: SnackbarService) { };

  ngOnInit(): void {
    this.dataSource = new ProteinDataSource(this.proteinService, this.sbService);
    this.paginator.pageIndex = 0;

    //getting the maximum number of genes that can be downloaded from the server
    this.proteinService.getMaxDownloadCounts().subscribe(data => {
      this.maxProteinDownloadCount = data.max_protein_download_count;
      this.maxProteinDownloadCountCSV = data.max_protein_download_count_csv;
    });
  }

  // Once the page has initialized
  // we set up the filter, sorting, and pagination
  ngAfterViewInit() {
    fromEvent(this.input.nativeElement, 'keyup')
      .pipe(
      debounceTime(150),
      distinctUntilChanged(),
      tap(() => {
        this.dataSource.filter(this.input.nativeElement.value)
      })
      )
      .subscribe();

    // reset the paginator after sorting
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    // on sort or paginate events, load a new page
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
      // If the sort changes or the page is changed, reload the table
      tap(() => this.loadProteinsPage())
      )
      .subscribe();

    // Once a search event has been added, we load the table
    this.proteinService.searchEventSubject.subscribe(value => {
      this.searchEvent = value
      if (value) {
        this.proteinService.limitReached = false
        this.loadProteinsPage()
      }
    })
  }

  getColumnToSort(columnName): string {
    switch (columnName) {
      case "id":
        return "unique_id"
      case "desc":
        return "description"
      default:
        return columnName
    }
  }

  loadProteinsPage() {
    let columnNames = this.getColumnToSort(this.sort.active)
    // This will load our dataSource with updated data
    this.dataSource.loadProteins(
      this.sort.direction,
      columnNames,
      this.paginator.pageIndex,
      this.paginator.pageSize);
  }

  //called when the download button is clicked
  onDownloadButtonClicked(proteinAssemblyAcc, proteinUniqueId): void {

    var ssDownEvent = new SingleSequenceDownloadEvent();
    ssDownEvent.seqDB = proteinAssemblyAcc + "_mylociprotein";
    ssDownEvent.seqID = proteinUniqueId;

    this.sbService.openSnackBar("Please wait while your sequences are being downloaded ...", "CLOSE", 3000)

    this.proteinService.downloadSingleSequence(ssDownEvent)
      .subscribe(fileData => { FileSaver.saveAs(fileData, "sequences.txt"); });

  }

  //called when the download button is clicked
  onDownloadAllFilteredSeqsButtonClicked(): void {

    //if the num proteins to be downloaded is greated than maximum allowed
    if (this.numProteins > this.maxProteinDownloadCount) {
      var message = "Can not download more than " + this.maxProteinDownloadCount + " proteins in fasta format using Loci. ";
      message = message + "Please try changing your query or contact admin";
      this.sbService.openSnackBar(message, "CLOSE", 5000);
      return;
    }

    //if there are items in the chips or a search string to be searched
    if (this.searchEvent.searchItems.length > 0 || this.searchEvent.searchString != "") {
      this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000);

      this.proteinService.createFilteredProteinsFasta(this.searchEvent)
        .subscribe(data => {
          //the result will contain an error message if the num sequences requested
          //is greater than max allowable. This is still possible because of some 
          //quirks in the UI
          if (data.error_message != "") {
            this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
            return;
          }

          else {
            this.proteinService.downloadFileStream(data.file_name, "protein_sequences.txt");
          }

        });
    }
    else {
      this.sbService.openSnackBar("Your query may have changed. Please click search button before download ..", "CLOSE", 3000);
    }



  }

  //called when the download selected sequences  is clicked
  onDownloadSelectedSeqsButtonClicked(): void {

    //getting the selected proteins
    const selectedProteins = this.selection.selected;

    //if there are no selected items
    if (selectedProteins.length == 0) {
      this.sbService.openSnackBar("No items selected", "CLOSE", 5000);
    }
    else {
      const numSelected = selectedProteins.length;
      //object array to store the sequence id and the database name (assembly accession)
      var protein_obj_array = [];
      for (var i = 0; i < numSelected; i++) {
        protein_obj_array[i] = { unique_id: selectedProteins[i].unique_id, assembly_acc: selectedProteins[i].assembly_acc };
      }

      this.proteinService.createSelectedProteinsFasta(protein_obj_array)
        .subscribe(data => {
          //the result will contain an error message if the num sequences requested
          //is greater than max allowable. This is still possible because of some 
          //quirks in the UI
          if (data.error_message != "") {
            this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
            return;
          }
          else {
            this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000)
            this.proteinService.downloadFileStream(data.file_name, "proteins.fasta")
          }

        });

    }

  }

  onDownloadCSVButtonClicked(downloadSelectedRows: boolean) {
    //if the num genes to be downloaded is greated than maximum allowed
    if (this.numProteins > this.maxProteinDownloadCountCSV) {
      var message = "Can not download more than " + this.maxProteinDownloadCountCSV + " proteins in CSV format using Loci. ";
      message = message + "Please try changing your query or contact admin";
      this.sbService.openSnackBar(message, "CLOSE", 5000);
      return;
    }

    if (downloadSelectedRows && this.selection.selected.length === 0) {
      this.sbService.openSnackBar("Please select Proteins in the table before attempting to download selected Protein CSV", "CLOSE", 3000)
    }
    //if there are items in the chips or a search string to be searched
    else if (this.searchEvent.searchItems.length > 0 || this.searchEvent.searchString != "") {
      this.sbService.openSnackBar("Trying to download. Please wait ...", "CLOSE", 3000)

      if (downloadSelectedRows) this.searchEvent.selectedItems = this.selection.selected.map(item => item.unique_id)
      else if (!downloadSelectedRows) this.searchEvent.selectedItems = []
      this.proteinService.createFilteredProteinCSV(this.searchEvent)
        .subscribe(data => {
          //the result will contain an error message if the num sequences requested
          //is greater than max allowable. This is still possible because of some 
          //quirks in the UI
          if (data.error_message != "") {
            this.sbService.openSnackBar(data.error_message, "CLOSE", 5000);
            return;
          }
          else {
            this.proteinService.downloadFileStream(data.file_name, "proteins.csv")
          }

        });
    }
    else {
      this.sbService.openSnackBar("Your query may have changed. Please click search button before download ..", "CLOSE", 3000);
    }
  }

}

// DataSource - this is the class that the table reads from.
// In other words, if the dataSource needs a value, then that value
// must be located here
export class ProteinDataSource implements DataSource<Protein> {

  public proteinCount = 0
  private proteinSubject = new BehaviorSubject<Protein[]>([]);
  private filteredData: Protein[] = [];
  private unFilteredData: Protein[] = [];

  constructor(private proteinService: ProteinsService, private sbService: SnackbarService) { }

  // Filter through the unFilteredData array and check
  // if the value searched for is located in each item.
  // If it is, then add that to the filtered results - end by updating our subject with those results
  filter(value) {
    if (value.length) {
      this.filteredData = this.unFilteredData.slice().filter((item: Protein) => {
        let searchStr = (item.species + item.assembly_acc +
          item.collection + item.length + item.description).toLowerCase();
        return searchStr.indexOf(value.toLowerCase()) != -1;
      });
      this.proteinSubject.next(this.filteredData)
    }
    else this.proteinSubject.next(this.unFilteredData)
  }

  // Returns the subject as an observable
  connect(collectionViewer: CollectionViewer): Observable<Protein[]> {
    return this.proteinSubject.asObservable();
  }

  // Close the observable
  disconnect(collectionViewer: CollectionViewer): void {
    this.proteinSubject.complete();
    this.proteinSubject.complete();
  }

  // This is called whenever the page is changed or a column is sorted. 
  // It makes a call to the server and updates our dataSource
  loadProteins(sortDirection: string,
    sortColumn: string,
    pageIndex: number,
    pageSize: number) {

    // Reset the results count to 0
    this.proteinService.numProteins = 0

    this.proteinService.getProteins(sortDirection, sortColumn,
      pageIndex, pageSize)
      .subscribe((proteins: Protein[]) => {
        this.proteinService.numProteins = proteins["count"]
        this.proteinCount = proteins["count"]
        this.proteinService.proteinLimit = proteins["limit_value"]
        
        if (!this.proteinService.limitReached && proteins["count"] == proteins["limit_value"]) {
          this.sbService.openSnackBar(`Large number of results found. Displaying first ` + this.proteinService.proteinLimit, "CLOSE", 4000)
          this.proteinService.limitReached = true
        }

        this.unFilteredData = proteins["results"]
        this.proteinSubject.next(proteins["results"])
      });
  }
}