import { Component, OnInit, Input } from '@angular/core';
import { Genome } from '../../models/genome'
import { ActivatedRoute, Params } from '@angular/router';
import 'rxjs/add/operator/switchMap';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-genome-browser',
  templateUrl: './genome-browser.component.html',
  styleUrls: ['./genome-browser.component.css']
})
export class GenomeBrowserComponent implements OnInit {

  @Input() genome: string;

  //location 
  @Input() loc: string;
  my_src: string;
  private jbrowseURL = environment.jBrowseURL;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
      this.route.params.subscribe(param => {
      this.genome = param['genome'];
      this.my_src = this.jbrowseURL + this.genome + '/data/';
      this.loc = param['loc']
      if(this.loc)
      {
        this.my_src = this.my_src +  '&loc=' + this.loc;
      }
    });
  }
  
}
