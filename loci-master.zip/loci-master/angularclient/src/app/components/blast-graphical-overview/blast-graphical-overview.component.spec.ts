import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlastGraphicalOverviewComponent } from './blast-graphical-overview.component';

describe('BlastGraphicalOverviewComponent', () => {
  let component: BlastGraphicalOverviewComponent;
  let fixture: ComponentFixture<BlastGraphicalOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlastGraphicalOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlastGraphicalOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
