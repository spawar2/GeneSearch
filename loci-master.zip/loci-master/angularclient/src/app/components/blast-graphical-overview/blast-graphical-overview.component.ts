//based on https://keathmilligan.net/create-reusable-chart-components-with-angular-2-and-d3-js-version-4/
//https://github.com/keathmilligan/angular2-d3-v4/blob/master/src/app/shared/barchart/barchart.component.ts
//TODO: need to implement onchanges properly

import { Component, OnInit, ViewEncapsulation, ViewChild, ElementRef, Input, OnChanges } from '@angular/core';
import * as d3 from 'd3';
import {GraphData} from '../../models/graph-data'

@Component({
  selector: 'app-blast-graphical-overview',
  templateUrl: './blast-graphical-overview.component.html',
  styleUrls: ['./blast-graphical-overview.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BlastGraphicalOverviewComponent implements OnInit, OnChanges {
  @ViewChild('blastgraphoverview') private chartContainer: ElementRef;
  @Input() private graphdata: GraphData;

  constructor() { }

  //input variables got from graph_data
  private hsps = [];
  private queryLen;
  private names = [];
  //private hsps = [{ hit: "hit1", start: 40, end: 100, score: 10 }, { hit: "hit1", start: 120, end: 300, score: 100 }, { hit: "hit2", start: 80, end: 250, score: 200 }, { hit: "hit3", start: 150, end: 200, score: 200 }, { hit: "hit4", start: 160, end: 230, score: 10 }, { hit: "hit5", start: 230, end: 300, score: 30 }, { hit: "hit6", start: 40, end: 50, score: 50 }, { hit: "hit6", start: 400, end: 500, score: 35 }];

  //if you change this you have to change the legend location as well because it is hardcoded
  private chartWidth = 1000;
  private margin = { top: 30, right: 20, bottom: 30, left: 20 };
  private barHeight = 8;
  private distBetweenBars = 7;
  private legendHeight = 40;
  private totalBarHeight = this.barHeight + this.distBetweenBars;


  private width = this.chartWidth - this.margin.left - this.margin.right;


//even though hsps is an input data, it is sometimes not initialized when this component is formed
//so I have go implement the onchanges function
//https://stackoverflow.com/questions/38020950/angular-2-in-which-lifecycle-hook-is-input-data-available-to-the-component
  ngOnInit() {

    if (this.graphdata) {
      this.initializeData();
      this.createGraphicalOverview();
    }
  }

  ngOnChanges() {
    if (this.graphdata) {
      this.initializeData();
      this.createGraphicalOverview();
    }

  }

  initializeData()
  {
      this.queryLen = this.graphdata.query_len;
      this.names = this.graphdata.hit_names;
      this.hsps = this.graphdata.hsp_data;
  }

  createGraphicalOverview() {
    let element = this.chartContainer.nativeElement;


    var chartHeight = (this.totalBarHeight * this.names.length) + this.margin.top + this.margin.bottom + this.legendHeight;
    var height = chartHeight - this.margin.top - this.margin.bottom - this.legendHeight;
    var color = d3.scaleLinear().domain([0, 200]).range(<any[]>['red', 'blue']);

    var y = d3.scaleBand()
      .domain(this.names)
      .range([0, height]);

    var x = d3.scaleLinear()
      .domain([0, this.queryLen])
      .range([0, this.width]);

    var xAxis = d3.axisTop(x);

    var chart = d3.select(element)
      .attr("width", this.chartWidth)
      .attr("height", chartHeight);

    //border
    chart.append("rect")
       			.attr("x", 0)
       			.attr("y", 0)
       			.attr("height", chartHeight)
       			.attr("width", this.chartWidth)
       			.style("stroke", "none")
       			.style("fill", "#F7F7F7")
       			.style("stroke-width", "1px");

    var legend = chart.append("g")
      .attr("transform", "translate(0," + this.margin.top + ")");

    //text is written at the starting at x,y but above it. https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/text-anchor
    //so adding 8 to align it with the rect
    legend.append("text")
      .text("Weaker hits")
      .attr("x", 700)
      .attr("y", 8)
      .attr("font-family", "sans-serif")
      .attr("font-size", "10px");

    for (var i = 0; i <= 10; i++) {
      legend.append("rect")
        .attr("class", "bar")
        .attr("x", 760 + (i * 10))
        .attr("y", 0)
        .attr("height", this.barHeight)
        .attr("width", 10)
        .style("fill", color(i * 20))
    };


    legend.append("text")
      .text("Stronger hits")
      .attr("x", 875)
      .attr("y", 8)
      .attr("font-family", "sans-serif")
      .attr("font-size", "10px");


    chart = chart.append("g")
      .attr("transform", "translate(" + this.margin.left + "," + (this.margin.top + this.legendHeight) + ")");

    //the following g will be at the same level as the above g
    //if you append in the previous statement itself, it will be a child of the previous g
    chart.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0,0)")
      .call(xAxis);

    chart.selectAll(".bar")
      .data(this.hsps)
      .enter().append("rect")
      .attr("class", "bar")
      .attr("x", function (d) { return x(d.start); })
      .attr("y", function (d) { return y(d.hit_name) + 5; })
      .attr("height", this.barHeight)
      .attr("width", function (d) { return x(d.end) - x(d.start); })
      .style("fill", function (d) { return color(d.score); })
      .on("mouseover", function (d) { d3.select(this).style("fill", "steelblue"); })
      .on("mouseout", function (d) { d3.select(this).style("fill", color(d.score)); })
      .on("click", function (d) { console.log("clicked"); })
      .append("svg:title").text(function (d) { return d.hit_name; });

  } //end of createGraphicalOverview function

} // end of class
