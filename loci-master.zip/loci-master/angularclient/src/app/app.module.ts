'use strict';
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms'; // <-- NgModel lives here
import { RouterModule }   from '@angular/router';
import { HttpModule }    from '@angular/http';
import 'hammerjs';
import {MatDialogModule,MatSelectModule,MatMenuModule,MatTooltipModule,MatTabsModule,MatSnackBarModule, MatRadioModule, MatCheckboxModule,MatListModule,MatChipsModule,MatInputModule, MatToolbarModule,MatButtonModule,MatIconModule,MatPaginatorModule,MatTableModule,MatCardModule,MatSortModule} from '@angular/material';
import { CdkTableModule } from '@angular/cdk/table';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RouteReuseStrategy } from '@angular/router';


import { AppComponent }  from './app.component';
import { GenomeDetailsComponent }  from './components/genome-details/genome-details.component';
import { GenomesComponent }  from './components/genomes/genomes.component';
import {GenomeService} from './services/genomes.service'; 
import {DashboardComponent} from './components/dashboard/dashboard.component'
import {AppRoutingModule} from './app-routing.module';
import { MySearchComponent } from './components/my-search/my-search.component';
import { GenomeBrowserComponent } from './components/genome-browser/genome-browser.component';
import { SafePipe } from './pipes/safe.pipe';
import { SafeHTML } from './pipes/safehtml.pipe';
import { BlastComponent } from './components/blast/blast.component';
import {BlastService} from './services/blast.service';
import { MyTasksComponent } from './components/my-tasks/my-tasks.component'; 
import {MyTasksService} from './services/my-tasks.service';
import { TaskConfirmationComponent } from './components/task-confirmation/task-confirmation.component';
import { BlastResultComponent } from './components/blast-result/blast-result.component';
import { BlastGraphicalOverviewComponent } from './components/blast-graphical-overview/blast-graphical-overview.component';
import {BlastResultService} from './services/blast-result.service';
import {LiveSearchService} from './services/live-search.service';
import {CustomReuseStrategy} from './custom-reuse-strategy';
import { LiveSearchComponent } from './components/live-search/live-search.component';
import { CustomBlastDbComponent } from './components/custom-blast-db/custom-blast-db.component';
import { ProteinsComponent } from './components/proteins/proteins.component';
import {ProteinsService} from './services/proteins.service';
import { MySearchProteinComponent } from './components/my-search-protein/my-search-protein.component';
import {LiveSearchProteinService} from './services/live-search-protein.service';
import { GenesComponent } from './components/genes/genes.component';
import { MySearchGeneComponent } from './components/my-search-gene/my-search-gene.component';
import {GenesService} from './services/genes.service';
import {LiveSearchGeneService} from './services/live-search-gene.service';
import {SnackbarService} from './services/snackbar.service';
import {GeneTableComponent} from './components/gene-table/gene-table.component';
import {GenomeTableComponent} from './components/genome-table/genome-table.component';
import { ProteinTableComponent } from './components/proteins-table/proteins-table.component';
import {LoginComponent} from './components/login/login.component';
import {ChangePasswordComponent} from './components/change-password/change-password.component';
import {AuthenticationService} from './services/authentication.service';
import {HelpService} from './services/help.service';
import {SummaryComponent} from './components/summary/summary.component'
import {SummaryService} from './services/summary.service'
import {DashboardService} from './services/dashboard.service';
import {AuthGuard} from './services/auth-guard.service';
import { MyDialogComponent } from './components/my-dialog/my-dialog.component'




@NgModule({
  imports:      [ 
    BrowserModule, //Angular Material Component Modules need to be added AFTER this module
    FormsModule,
    AppRoutingModule,
    HttpModule,


    //Angular Material related
    BrowserAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatPaginatorModule,
    CdkTableModule,
    MatCardModule,
    MatInputModule,
    MatChipsModule,
    MatListModule,
    MatCheckboxModule,
    MatRadioModule,
    MatSnackBarModule,
    MatTabsModule,
    MatTooltipModule,
    MatMenuModule,
    MatSelectModule,
    MatSortModule,
    MatDialogModule,


  ],
  declarations: [ AppComponent, GenomesComponent,DashboardComponent, GenomeDetailsComponent, MySearchComponent, GenomeBrowserComponent,SafePipe, SafeHTML, BlastComponent, MyTasksComponent,TaskConfirmationComponent, BlastResultComponent, BlastGraphicalOverviewComponent, LiveSearchComponent, CustomBlastDbComponent, ProteinsComponent, MySearchProteinComponent, GenesComponent, MySearchGeneComponent,LoginComponent, ChangePasswordComponent, GeneTableComponent, GenomeTableComponent, ProteinTableComponent, MyDialogComponent, SummaryComponent],
  providers: [HelpService,SnackbarService,GenesService, LiveSearchGeneService, LiveSearchProteinService,ProteinsService, GenomeService, BlastService, MyTasksService, BlastResultService, LiveSearchService,{provide: RouteReuseStrategy, useClass: CustomReuseStrategy},DashboardService, AuthenticationService, AuthGuard, SummaryService],
  bootstrap:    [ AppComponent],
  entryComponents: [
    MyDialogComponent,
],
})


export class AppModule { }
