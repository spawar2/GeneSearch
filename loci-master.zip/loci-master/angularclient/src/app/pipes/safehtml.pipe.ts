
//https://stackoverflow.com/questions/31548311/angular-2-html-binding
//if this pipe is not used, when i set an innter html to a html file, the attributes like name and id are stripped from <a> tags
import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer} from '@angular/platform-browser';


@Pipe({name: 'safeHtml'})
export class SafeHTML {
  constructor(private sanitizer:DomSanitizer){}

  transform(style) {
    return this.sanitizer.bypassSecurityTrustHtml(style);
    //return this.sanitizer.bypassSecurityTrustStyle(style);
    // return this.sanitizer.bypassSecurityTrustXxx(style); - see docs
  }
}