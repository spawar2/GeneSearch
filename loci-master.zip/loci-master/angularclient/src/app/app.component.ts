//this is the main component
import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from './services/authentication.service';
import { HelpService } from './services/help.service';
import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {MyDialogComponent} from './components/my-dialog/my-dialog.component';
import { SnackbarService } from './services/snackbar.service';
import * as FileSaver from 'file-saver';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

  title = 'LOCI';
  admin_email = "info@karyosoft.com";

  //icons: https://alligator.io/angular/custom-svg-icons-angular-material/
  //fill color of icon: https://stackoverflow.com/questions/29022756/how-do-i-change-the-color-of-an-md-icon-in-angular-material

  constructor(public sbService: SnackbarService, private helpService: HelpService, public dialog: MatDialog, private authService: AuthenticationService, private matIconRegistry: MatIconRegistry,private domSanitizer: DomSanitizer){
    this.matIconRegistry.addSvgIcon(
      "loci",
      this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/loci.svg")
    );
  }

  ngOnInit() {
    this.helpService.getAminEmail().subscribe(data=>{this.admin_email = data;});
  }

  setActiveLink(link) {
    this.authService.activeLink = link
  }

  get userIsLoggedIn() {
    return this.authService.userIsLoggedIn
  }

  get activeLink() {
    return this.authService.activeLink
  }

  get username() {
    // This is a getter that will retrieve the user's name when
    // it's set in the service. It'll act as a prop in 
    // the html
    return this.authService.userName
  }

  logout() {
    this.authService.logUserOut()
  }

  openDialog(message: string, email: string): void {
    const dialogRef = this.dialog.open(MyDialogComponent, {
      height: '200px',
      width: '400px',
      data: {message: message, email:email}
    });

    dialogRef.afterClosed().subscribe(result => {
      //console.log('The dialog was closed');
    });
  }
  
  contactAdmin() : void{
    this.openDialog("Thanks for using Loci. You can contact your admin at",this.admin_email);
  }

  contactKaryosoft(): void{
    this.openDialog("Thanks for using Loci.You can contact Karyosoft at ", "info@karyosoft.com");
  }

  downloadManual(): void{
    this.sbService.openSnackBar("Please wait while the manual is being downloaded ...", "CLOSE", 3000)
    
        this.helpService.downloadManual()
          .subscribe(fileData => { FileSaver.saveAs(fileData, "loci_manual.pdf"); });
  }

}
