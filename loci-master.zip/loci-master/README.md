### General server setup

#### Python
The server app requires python2 >= 2.7.12

#### Mongodb
Mongodb 3.x that is started using the `database/loci_mongo.config` file
> sudo mongod --config ./loci_mongo.config

This will run mongod on port 1401 and use the directory specified
in the config file for its db collections.

#### Add users collection
For creation of users for logins, create a *users* collection.
> db.createCollection("users")

using the `mongo` cli (`mongo localhost:1401`)

#### Install requirements
> pip install -r requirements.txt

#### Starting the server
To start the server in a terminal:
> FLASK_APP=server.py flask run

#### Install node/js dependencies
This works with node lts which is currently 8.x, but probably works
with older versions too. Either `npm` or `yarn`:
> yarn

#### Staring the Angular app in dev mode
> yarn start

#### To add a user
> http://localhost:4200/add-user

Currently this is not protected. Before deploying on the internet,
some *admin* implementation is needed, e.g. an `/admin` panel, and
an `admin` property for each user to differentiate admins from
regular users.

This would also require seeding the users with at least one initial
admin account.